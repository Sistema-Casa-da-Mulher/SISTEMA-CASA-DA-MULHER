# Plano: Agenda e Calendário no Sistema Casa da Mulher

**Versão 3, 07/11/2026.** Inclui a revisão da v2 feita pelo Allan e pela segunda opinião (seção 0). A v2 foi aprovada como proposta; a v3 corrige os 7 comportamentos e os 4 detalhes apontados, para servir de referência da implementação. O protótipo fictício está em `CasaDaMulher-Prototipos-03-Agenda-Calendario-2026-11-07.zip` (pasta 03 do ZIP geral). Continua sendo só plano + protótipo: nada foi implementado no sistema real nem enviado ao Render.
Os nomes de tabelas, telas e campos citados precisam ser conferidos no código antes da implementação.

---

## 0. Fechamento do protótipo (revisão da v3)

A v3 foi aprovada como proposta. Antes de fechar o protótipo, foram corrigidos estes 4 pontos, que também valem para a implementação:
1. **Detalhe na Recepção monta a situação pelo estado atual**: "Esperada" sem horário, "Chegou às hh:mm" só com a chegada, "Recebida pela equipe às hh:mm" só com o recebimento. Um horário que ainda não existe nunca é formatado.
2. **Pendências conferem a autorização atual na origem** antes de serem montadas (chegada, retorno da rede, revisão, reavaliação, resultado) e de novo antes de executar a ação. Quem perdeu o caso não recebe nome, identificação nem botão, e chamar a ação direto não altera nada.
3. **Horário remarcado sai das esperadas da Recepção** e não aceita nova marcação de chegada. Fica só no histórico do agendamento (para quem tem permissão); a nova data aparece no dia dela. Detalhe de item oculto não abre para ninguém.
4. **Reavaliação de risco grava um registro** (data, profissional, classificação, próxima ação). No protótipo fica em memória e pode ser reaberto em Pendências > "Reavaliações registradas"; no sistema fica no prontuário.

Testes: `testes-regras.js` (38 verificações, sem navegador) e `testes-tela.js` (16 verificações no navegador, com Playwright), cobrindo os 4 testes pedidos e o registro de reavaliação, que não abre sem acesso atual ao prontuário, nem chamando a ação direto.

## 0.1 O que mudou da versão 2

**Comportamento (prioridade alta)**
1. **Ausência de dia inteiro ocupa a agenda.** "Dia inteiro" e "não ocupa horário" agora são coisas separadas: uma ausência ou reunião de dia inteiro ocupa o dia todo e entra no conflito; feriado e prazo continuam como marcos (não ocupam).
2. **Recorrência conferida data a data.** Antes de salvar uma série, o sistema confere cada ocorrência e mostra numa tabela quais datas têm conflito ou unidade fechada. Justificativa e autorização valem só para a data em que foram dadas; datas bloqueadas não são criadas.
3. **Exceção da ADM ligada a um compromisso.** Em dia de unidade fechada, a ADM autoriza a exceção no próprio compromisso (intervalo, pessoas e motivo gravados nele). Os demais continuam bloqueados. "Reabrir a unidade para todos" virou uma ação separada e explícita em Configuração.
4. **Disponibilidade técnica só ao agendar.** O filtro "Pessoas" do Calendário mostra só o que a pessoa já poderia ver (reuniões, avisos, casos autorizados). Atendimentos técnicos não aparecem nem como "Ocupado". A professora não vê nada da agenda técnica. Disponibilidade só em "Ver disponibilidade" ou na conferência ao salvar.
5. **Item manual com caso vinculado confere a origem primeiro.** Ter criado o item ou ser a dona não mantém o acesso: quem perde a permissão no caso vê só "Compromisso de um caso que você não acessa mais", com o horário.

**Comportamento (prioridade média)**
6. **Ausência só informada não tira horário livre.** No modo de escolha ela aparece em amarelo, com aviso, e o horário pode ser escolhido.
7. **"Avisar a Recepção" desligado é respeitado em qualquer caso**, não só nos restritos.

**Detalhes**
8. **Participantes ≠ Quem pode ver.** Participante entra na conferência de disponibilidade e fica ocupada. Quem só pode ver não fica ocupada e vê o item em "Compartilhados comigo (só ver)". Saiu o "mostrar como Ocupado".
9. **Leitura do calendário:** cada card mostra hora, título curto e identificação autorizada, com o número de linhas que cabe na altura (nada cortado no meio). Avisos de colegas ficam numa faixa própria no topo ("Aviso · Nome 12:00–15:00"), fora da sua coluna.
10. **Cancelar aulas futuras não encerra a turma.** "Esta e as próximas" vale só para ocorrências futuras; aula passada ou com chamada nunca muda. Encerrar turma é outra ação, em Cursos.
11. **Passar responsabilidades:** a sucessora recebe o acesso e uma lista de compromissos futuros **para revisar** ("Assumir na minha agenda", com conferência de disponibilidade, ou "Remarcar"). Nada vai sozinho para a agenda dela. Registros passados mantêm a autora original.
12. **Descarte consistente:** X, Esc, clique no fundo e Voltar do navegador perguntam "Descartar o que foi digitado?" quando há edição não salva dentro do Calendário, e fecham só a edição.

## 0.2 O que mudou da versão 1

1. **Recepção vê quem é esperada no dia**: nome de identificação + identificador interno, horário e "Atendimento com a equipe técnica". Só atendimentos presenciais na unidade. Novo fluxo **Esperada → Chegou → Recebida pela equipe**.
2. **Matriz de sigilo refeita**: acesso ao cadastro não é acesso ao atendimento. Vale a permissão da origem (caso jurídico, prontuário psicológico, registro social). "Mesma área" não dá mais nome e horário automaticamente. "Completo" = detalhes operacionais autorizados, nunca relatos ou evoluções.
3. **Oculto não é livre**: todo compromisso conta na conferência de conflito no servidor, mesmo invisível. Quem não pode ver recebe só "Há uma indisponibilidade nesse horário". Consultar disponibilidade exige contexto de agendamento. Cores e contagens do mini calendário também seguem o sigilo (cor neutra para itens não revelados).
4. **"Em nome de" = aviso informado**, não ausência confirmada. Aparece e gera atenção, mas não cancela nada nem bloqueia até a própria pessoa (ou quem tem a atribuição) confirmar.
5. **Aviso de falta não preenche chamada.** Horário passado sem registro = "resultado pendente de registro", nunca "faltou".
6. **Reavaliação de risco separada da classificação**: some quando a profissional registra a reavaliação e a próxima ação, mesmo que o risco continue igual.
7. **Agendamento com histórico próprio** (agendado, realizado, cancelado, remarcado, falta registrada), em vez de um campo "próxima sessão" sobrescrito. Sem duplicidade entre fontes.
8. **Acolhimento vira marcos** (entrada, saída prevista, retornos), sem deixar ninguém "ocupado" por dias. **Recorrência** com "só esta ocorrência", "esta e as próximas" e "cancelar ocorrência" desde o início.
9. **Promessa de "voltar ao mesmo lugar" ficou precisa**: vale para X, Esc e Voltar; não cobre sessão expirada nem navegador fechado. Clicar no fundo com edição aberta pede confirmação. Mini calendário funciona por clique e teclado; passar o mouse é atalho.
10. **Conflitos**: sobreposição exige confirmação **e justificativa curta**; "Casa fechada" bloqueia com exceção autorizada; **feriado sozinho não fecha a Casa**; limite diário conta duração, não só quantidade; intervalo entre atendimentos e deslocamento de visita.
11. As 11 perguntas viraram **decisões propostas** (seção 12), para confirmar na reunião.

---

## 1. Resumo

1. **Agenda** é um bloco na tela inicial de cada perfil (Recepção, Jurídico, Psicologia, Serviço Social, Professora, Coordenação/ADM; EQP fica de fora), com abas **Hoje**, **Próximos 7 dias**, **Pendências** e o botão **+ Novo compromisso**.
2. Dois tipos de item: **automáticos** (vêm de agendamentos, aulas, marcos e pendências que o sistema já registra) e **manuais** (lembrete, prazo, visita, reunião, aviso de ausência/atraso).
3. Cada manual tem **participantes** (ficam ocupadas e entram na conferência) e **quem pode ver** (só quem participa, pessoas escolhidas, minha área, toda a equipe). Só ver não ocupa a agenda de ninguém.
4. **O sigilo manda**: cada item é montado no servidor para quem está olhando, conforme a permissão da origem.
5. **Calendário** no menu do usuário (nome, ID, logout automático): mini calendário por clique, teclado ou passar o mouse; calendário completo em sobreposição, fechando com X/Esc/Voltar sem perder o formulário.
6. **"Ver disponibilidade"** nos formulários de agendamento, com conferência de conflitos no servidor, incluindo compromissos que a pessoa não pode ver.
7. **Custo zero**: só o banco e a API que já existem. Sem e-mail, SMS, push ou Google Agenda.

---

## 2. Conceitos

| Termo | O que é |
|---|---|
| **Compromisso** | Item com data e, se tiver, hora de início e fim. Automático ou manual. |
| **Agendamento** | Registro próprio de um atendimento marcado (Jurídico, Psicologia, Serviço Social), com histórico de situação. É a origem dos compromissos de atendimento. |
| **Marco** | Data importante que **não ocupa horário** (entrada em acolhimento, saída prevista, início de turma, prazo, feriado). |
| **Ocupa horário** | Sessão, atendimento, visita, aula, reunião, ausência. Só esses contam em conflito e no limite diário. **Dia inteiro** é só a duração: uma ausência ou reunião de dia inteiro ocupa o dia todo. |
| **Participante** | Pessoa que vai estar no compromisso: fica ocupada e entra na conferência de disponibilidade. |
| **Pode ver** | Pessoa com quem o item foi compartilhado só para leitura: não fica ocupada. |
| **Dono / responsável** | Quem vai estar ocupada. |
| **Registrado por** | Quem digitou. Diferente do dono quando é "em nome de". |
| **Pendência** | Algo que já passou e precisa de registro: "resultado pendente de registro", "chamada pendente", "reavaliação pendente", "retorno da rede pendente". |
| **Indisponibilidade** | Como aparece, para quem não pode ver, um horário ocupado por algo sigiloso. |

---

## 3. Agenda: o que cada perfil vê

Layout padrão das telas por perfil. Cada linha: hora, ícone do tipo, título e identificação da assistida **quando a pessoa tem permissão na origem**. Clicar abre o detalhe com "Ir para a origem".

### Recepção
- **Esperadas hoje** (somente atendimentos **presenciais na unidade**, somente no dia): nome de identificação adotado pela Casa + identificador interno curto (ex.: `AS-0042`), horário e **"Atendimento com a equipe técnica"**. Nunca a área, o motivo, o local protegido, visitas domiciliares ou acolhimento. Só aparece quem a responsável marcou **"Avisar a Recepção"** no agendamento: vem ligado em casos comuns e desligado em casos restritos, e **desligado é respeitado em qualquer caso**.
- **Fluxo de chegada**: **Esperada → Chegou → Recebida pela equipe**. A Recepção marca "Chegou" (com hora). A responsável vê "Chegou às 13h52" na Agenda dela e marca "Recebida". Se ninguém receber em 15 min, a Recepção vê "aguardando há 15 min" (sem dizer com quem).
- Status do encaminhamento ao Jurídico que a Recepção já vê (Aguardando, Agendado, Primeiro atendimento realizado, Cancelado).
- Início e término de turmas; avisos da equipe compartilhados com todos.
- Pode **registrar comunicação de falta ou atraso** de aluna (seção 4).

### Jurídico
- **Agendamentos** (com histórico: agendado, realizado, cancelado, remarcado, falta registrada), primeiros atendimentos e retornos.
- **Prazos** (marco) e **audiências** (ocupa horário), ligados ao caso CJ.
- Encaminhamentos recebidos sem agendamento (pendência).
- Caso com **Acesso restrito** ou visibilidade "somente responsáveis": só as responsáveis veem. Para o resto, nada na Agenda; no Calendário e no conflito, "Indisponibilidade" se for da agenda de uma colega e a pessoa estiver tentando agendar com ela.
- Filtro "Cursos" mostra só dia e horário das turmas, sem alunas.

### Psicologia
- **Sessões agendadas** (agendamento com histórico), primeiro atendimento com lembrete do consentimento.
- **Reavaliação pendente**: aberta quando uma sessão registra risco alto ou iminente; **resolvida quando a profissional registra a reavaliação e define a próxima ação**, mesmo que o risco continue alto. A situação de risco continua visível para quem tem autorização, como hoje. O lembrete diz "Situações urgentes seguem o fluxo de atendimento da Casa (CAPS, SAMU 192, CVV 188)".
- Sessão passada sem registro: **"resultado pendente de registro"**.
- Outra psicóloga **não** vê nome nem horário das sessões da colega por padrão, nem como "Ocupado" no filtro Pessoas; vê só disponibilidade quando estiver agendando com ela. A responsável pode autorizar colegas (ex.: substituta), e o acesso de emergência continua só na ficha.
- Nunca: anotações, evolução, motivo.

### Serviço Social (`as_social`)
- **Visitas domiciliares e institucionais** (ocupam horário, incluindo **deslocamento** antes e depois).
- **Acolhimento como marcos**: entrada, saída prevista, retornos. Não bloqueia a agenda da profissional nem deixa a assistida "ocupada". Os atendimentos ligados a ele ocupam seus próprios horários.
- **Metas do plano** com data-limite (marco) e **retorno esperado de encaminhamento à rede** (pendência quando passa).
- **Direcionamento** como pendência quando passar para o Serviço Social (hoje só protótipo).
- Pode registrar comunicação de falta/atraso de aluna.

### Professora
- **Aulas** das próprias turmas, geradas pelo horário da turma (recorrência semanal).
- **Chamada pendente** em aula passada sem chamada. **Aula cancelada não gera chamada pendente.**
- **Comunicações de falta/atraso**: "Joana Lima (AS-0042) avisou que vai faltar à aula de 11/11 — registrado pela Recepção". Sem motivo. **Não marca nada na chamada**: a professora confirma presença, falta ou falta justificada como hoje; o aviso aparece ao lado do nome na chamada como lembrete.
- Por padrão só as próprias turmas; filtro "Outras turmas" mostra dia, horário e professora, sem alunas nem observações.

### Coordenação / ADM
- Ausências informadas e confirmadas, reuniões, eventos da Casa, feriados e **unidade fechada**.
- Cursos: início, término, turmas sem professora, aulas canceladas.
- Pontos de atenção dos Relatórios, em forma de data.
- Atendimentos técnicos **só como número por dia e área**, sem nome. Risco da Psicologia fora.
- Pode criar compromissos para a equipe toda e confirmar ausências.

---

## 4. Compromissos manuais

### Tipos
| Tipo | Ocupa horário | Exemplo |
|---|---|---|
| Lembrete | não | "Ligar para a Defensoria" |
| Prazo | não | "Prazo de contestação, CJ-2026-000041" |
| Atendimento extra | sim | Atendimento fora do fluxo |
| Visita / saída externa | sim (+ deslocamento) | Visita domiciliar, fórum |
| Reunião interna | sim | Reunião de equipe |
| Ausência / atraso | sim (dia inteiro ocupa o dia todo) | "Volto às 15h", "Folga (banco de horas)" |
| Comunicação de falta/atraso de aluna | não | "Joana avisou que chega 30 min atrasada" |
| Evento da Casa | conforme | Mutirão, plantão |
| Feriado / Unidade fechada (só ADM) | ver seção 7 | — |

Menu filtrado por perfil (Audiência só no Jurídico, Visita domiciliar só no Serviço Social etc.).

### Campos
Título, tipo, data, dia inteiro ou início/fim, local (opcional, com o aviso **"Informar a sala não reserva a sala"**), assistida vinculada (só origens a que a pessoa tem acesso), observação curta, **participantes** (com botão "Ver disponibilidade" deles), **quem pode ver** (separado dos participantes), lembrete na tela (com o texto **"Os lembretes aparecem enquanto o sistema estiver aberto"**), repetir semanalmente até uma data.

### Em nome de outra pessoa
- **Qualquer integrante** pode registrar um **aviso operacional** em nome de colega: "Ausência informada para Ana, 9h–12h — registrado por Bruna".
- Situação **Informada**: aparece imediatamente para quem pode ver a agenda da Ana e **gera alerta ao agendar** com ela. **Não cancela compromissos existentes e não bloqueia.**
- Vira **Confirmada** quando a Ana (ou a ADM) confirma. A Ana pode corrigir ou recusar ("não procede"); tudo fica na auditoria.
- "Em nome de" **não** pode: alterar ou cancelar atendimentos, vincular assistida, criar bloqueio institucional.

### Recorrência
- **Ao criar**, cada ocorrência é conferida separadamente e o resultado aparece numa tabela (data, conflitos, "sem conflito"). Data com sobreposição pede justificativa **daquela data**; data bloqueada (unidade fechada) não é criada, a não ser que a ADM autorize exceção **para aquela data e aquele compromisso**. Nada do que foi decidido para a primeira data vale para as outras.
- **Ao editar ou cancelar**, sempre pergunta: **"Somente esta ocorrência"**, **"Esta e as próximas"** ou **"Todas as que ainda não aconteceram"**. Ocorrências passadas nunca mudam.
- **Aulas:** cancelar uma ocorrência marca a aula como cancelada (motivo curto, ex.: "feriado"), avisa as alunas pela lista da Recepção/Serviço Social e **não gera chamada pendente**. "Esta e as próximas" cancela só as ocorrências futuras: **não encerra a turma** (turma e matrículas continuam; encerrar é outra ação, em Cursos), e aula já realizada ou com chamada não muda.

### Ciclo de vida
Ativo → Concluído / Cancelado. Cancelados ficam riscados, consultáveis no histórico. **Tempo de exibição não define quando apagar**: retenção segue a política da Casa (a definir com a LGPD), não a tela.

---

## 5. Visibilidade e sigilo

### Regra geral
> A responsável e as profissionais **autorizadas na origem** veem os detalhes operacionais necessários. As demais, no máximo, consultam **disponibilidade**, e só quando estão agendando.

"Detalhes operacionais" = tipo, data, hora, local, responsável, identificação da assistida, situação. **Nunca** relatos, evoluções, anotações, motivos, documentos.

### Três perguntas, nesta ordem, no servidor
1. **A pessoa tem permissão na origem?** (o caso jurídico, o prontuário PSI, o prontuário SOC, a turma). Ter acesso à ficha cadastral da assistida **não basta**.
2. **A visibilidade escolhida inclui a pessoa?** (manuais)
3. Se não: **nada** na Agenda e nos filtros do Calendário. Na conferência e em "Ver disponibilidade", só "Indisponível" / "Há uma indisponibilidade nesse horário". O item **continua contando no conflito**.

A pergunta 1 vem **antes** de qualquer outra também nos itens manuais: se o item tem caso vinculado e a pessoa não tem mais permissão nesse caso, ela não vê o detalhe, **mesmo sendo autora, dona ou participante**. Ela vê só o horário e "Compromisso de um caso que você não acessa mais".

Nada que a pessoa não possa ver vai ao navegador (sem esconder só com CSS).

### Cores, pontinhos e contagens
- Item revelado: cor do tipo.
- Item não revelado ("Indisponível", só no modo de escolha e na conferência): **cinza neutro igual para todas as áreas**. Nenhuma cor exclusiva de Psicologia/Jurídico/Social aparece para quem não pode ver.
- Item totalmente oculto: **não entra** nos pontinhos nem nas contagens do mini calendário da pessoa.
- Mensagens de conflito: só "Há uma indisponibilidade nesse horário" quando a pessoa não pode ver o motivo.

### Matriz (itens automáticos)

| Origem → / Quem vê ↓ | Sessão Psicologia | Atendimento Jurídico | Caso Jurídico restrito | Visita / acolhimento Serviço Social | Aula |
|---|---|---|---|---|---|
| Responsável | detalhes operacionais | detalhes operacionais | detalhes operacionais | detalhes operacionais | completo |
| Autorizada na origem (ex.: co-responsável, substituta) | detalhes operacionais | detalhes operacionais | detalhes operacionais | detalhes operacionais | completo (turma dela) |
| Mesmo perfil, sem autorização | nada (só "Indisponível" ao agendar com ela) | detalhes se visibilidade do caso for "equipe"; senão nada (só "Indisponível" ao agendar) | nada (indisponibilidade só no conflito) | nada (só "Indisponível" ao agendar) | dia e horário (filtro) |
| Outra área técnica com acesso à ficha | "Em acompanhamento na Psicologia" (já existe), sem data/hora | situação do encaminhamento que já vê | nada | "Em acompanhamento no Serviço Social", sem data/hora | dia, horário e situação na turma |
| Recepção | se presencial, no dia e com "Avisar a Recepção": "Atendimento com a equipe técnica" + identificação + hora | idem + status que já vê | só se a responsável autorizar | visita/acolhimento: nada; atendimento presencial: igual à Psicologia | dia e horário |
| Professora | nada (nem no filtro Pessoas) | nada | nada | nada | completo nas turmas dela; outras turmas sem alunas |
| Coordenação/ADM | número por dia | número por dia | número por dia (sem distinguir restrito) | número por dia | completo |

Itens manuais: participantes e quem pode ver têm detalhe (respeitando a origem, acima). **Só poder ver não ocupa a agenda**: o item não entra na conferência dela.

### Consulta de disponibilidade
- O filtro "Pessoas" do Calendário **não** é consulta de disponibilidade: mostra só o que a pessoa já veria de cada colega.
- **Ausência só informada** aparece como aviso (amarelo) e **não tira o horário livre**; ausência confirmada aparece como indisponível.
- O endpoint só responde com um **contexto de agendamento** (formulário de sessão, atendimento, visita, reunião, novo compromisso com participantes) e para pessoas/assistidas que fazem sentido nele: a própria profissional, colegas convidadas, a assistida vinculada ao caso que ela atende.
- Devolve **faixas livres e ocupadas**, sem título nem área, para quem não pode ver.
- Limite de consultas por minuto e auditoria das consultas sobre assistidas, para que "ver disponibilidade" não vire forma de mapear a rotina de alguém.

### Emergência e auditoria
- O acesso de emergência continua só na ficha. A Agenda nunca abre detalhe sigiloso.
- Auditoria: criar, editar, cancelar, remarcar, "em nome de", confirmar/recusar ausência, confirmar por cima de conflito (com a justificativa), marcar Chegou/Recebida, consulta de disponibilidade de assistida.

---

## 6. Calendário

### Onde fica
No menu do usuário, uma linha **"Calendário"**.

### Mini calendário
- Abre por **clique**, por **teclado** (Enter/Espaço no item do menu) ou, como atalho, **passando o mouse** (~300 ms).
- Mês com setas, hoje destacado, até 3 pontinhos por dia (cores conforme seção 5) e "+N".
- Dica do dia ao passar o mouse **ou** ao focar/tocar no dia: lista com hora e título já filtrados.
- Teclado: setas andam entre os dias, Enter abre o dia no Calendário completo, Esc fecha.
- Celular: não há espaço nem "passar o mouse"; tocar em "Calendário" abre direto o Calendário completo na visão Dia.

### Calendário completo (sobreposição)
- Camada por cima da página, sem trocar de URL nem recarregar. A página de baixo continua montada.
- Visões **Mês, Semana (padrão), Dia, Lista**. A Lista abre nos **últimos 90 dias + próximos**, com filtro para períodos anteriores.
- Filtros com padrão por perfil (seção 3), incluindo "Pessoas" lado a lado: só mostra o que a pessoa já pode ver de cada colega (reuniões, avisos, casos autorizados). Atendimentos técnicos não aparecem nem como "Ocupado". "Compartilhados comigo (só ver)" é um filtro próprio.
- **Leitura:** cada card mostra hora, título curto e identificação autorizada (assistida, colega ou local), com o número de linhas que cabe na altura; o resto aparece ao passar o mouse e no detalhe. **Avisos de colegas** (ausências, atrasos) ficam numa faixa própria no topo ("Aviso · Paula 12:00–15:00"), fora da sua coluna.
- Legenda fixa: "Os lembretes aparecem enquanto o sistema estiver aberto" e "Informar a sala não reserva a sala".

### Fechar e voltar ao mesmo lugar (promessa exata)
- **X, Esc e Voltar do navegador** fecham e a página de baixo continua **exatamente** como estava (formulário preenchido, rolagem, aba). O foco volta ao elemento que abriu.
- **Edição dentro do Calendário** (ex.: "+ Novo compromisso"): X, Esc, clique no fundo e Voltar do navegador têm o mesmo tratamento: se houver algo digitado, perguntam "Descartar o que foi digitado?" ("Continuar editando" / "Descartar") e fecham só a edição; o Calendário continua aberto.
- **"Ver disponibilidade" por cima de um formulário** (ex.: participantes de um novo compromisso): fechar ou escolher um horário volta para o formulário, e para o Calendário se ele já estava aberto.
- **Não cobre**: sessão expirada (token de 30 min) ou navegador/aba fechados. Nesses casos o que não foi salvo se perde, como já acontece hoje. *(Opcional futuro: rascunho local do formulário, só sem dados sigilosos.)*

---

## 7. Integração com os formulários e conflitos

### "Ver disponibilidade"
Nos formulários de: sessão/primeiro atendimento (Psicologia), agendamento/retorno/audiência (Jurídico), visita/atendimento (Serviço Social), horário de turma (ADM/Professora), novo compromisso com participantes (todos), e no Direcionamento (mostra se as turmas escolhidas batem com compromissos da assistida, sem dizer quais).

Abre o Calendário em **modo de escolha** (Semana, a profissional + a assistida + participantes), com horários livres no expediente, ocupados em cinza, ausência só informada em amarelo (pode ser escolhida, com aviso) e duração sugerida. Clicar preenche data/hora e fecha. Nada é salvo sozinho. Quem só pode ver o compromisso não entra nessa conferência.

### Durações e intervalos (valores iniciais, ajustáveis, não obrigatórios)
Sessão 50 min + 10 min de intervalo; atendimento jurídico 1 h; visita 2 h + deslocamento (padrão 30 min antes e depois, editável).

### Tabela de conflitos (verificada no servidor ao consultar e de novo ao salvar)

| Situação | Nível | Mensagem |
|---|---|---|
| Profissional já tem algo que ocupa horário | **Confirmação + justificativa curta** | "Você já tem Visita domiciliar 14h–16h." / para colegas sem permissão: "Há uma indisponibilidade nesse horário." |
| Assistida já tem compromisso (qualquer área) | Confirmação + justificativa | "Há uma indisponibilidade da assistida nesse horário." (nunca diz com quem) |
| Assistida tem aula | Confirmação + justificativa | "A assistida tem aula de Informática nesse horário." (só para quem já vê curso e situação) |
| Ausência **confirmada** da pessoa (inclusive de dia inteiro) | Confirmação + justificativa | "Ana está ausente nesse horário." / "Paula está ausente o dia inteiro." |
| Ausência **informada** (em nome de) | Aviso | "Há uma ausência informada para Ana, ainda não confirmada." |
| Carga do dia passou do limite | Aviso | "Seu dia já tem 5h40 ocupadas (limite de aviso: 6 compromissos / 6h)." |
| Sem intervalo entre atendimentos | Aviso | "Sem intervalo depois da sessão das 10h." |
| Fora do expediente | Aviso | "Fora do seu expediente (8h–17h)." |
| **Unidade fechada** | **Bloqueio**; exceção só por ADM, **ligada a um compromisso** (intervalo, pessoas, motivo) | "Unidade fechada. Só a ADM pode autorizar uma exceção, ligada a este compromisso." |
| **Feriado** sem fechamento | Aviso | "Feriado (plantão previsto)." |

Em série, a tabela vale **por data** (seção 4, Recorrência). O limite diário conta **só o que ocupa horário** (lembretes e prazos fora) e considera **quantidade e horas**; o valor (6) é configurável por profissional ou área.

---

## 8. Como implementar (técnico)

### Origem dos dados
1. **Agendamentos com histórico** (tabela nova por área ou uma comum `Agendamentos` com `Area`): Id, Area (Juridico/Psicologia/Social), OrigemRef (CJ/PSI/SOC), AssistidaId, ResponsavelId, InicioUtc, FimUtc, Presencial, AvisarRecepcao, Situacao (Agendado, Realizado, Cancelado, Remarcado, FaltaRegistrada), RemarcadoDeId, AtendimentoRegistradoId, Chegada (EsperadaEm, ChegouEm, RecebidaEm, MarcadoPor). Cada mudança de situação gera linha de histórico; nada é sobrescrito. O texto antigo "próxima sessão" continua visível como texto.
2. **Turmas com horário + ocorrências**: o horário semanal da turma gera ocorrências; exceções gravadas em `AulaOcorrencias` (Data, Situacao: Prevista/Cancelada/Remarcada, Motivo, NovaData). Chamada pendente só para ocorrência Prevista e passada.
3. **Marcos** (prazos, metas, acolhimento, retornos da rede) lidos das próprias tabelas de origem com campo de data.
4. **Manuais**: `AgendaCompromissos` (como na v1, mais `DiaInteiro` e `OcupaHorario` como campos separados, `SituacaoAusencia`: Informada/Confirmada/Recusada, `ConfirmadoPorId`, `SerieId` e `OcorrenciaOriginalUtc` para recorrência, `Justificativa` por ocorrência), `AgendaParticipantes` (ocupa) e `AgendaCompartilhamentos` (só ver), em tabelas separadas.
5. **Configuração** (ADM): feriados, unidade fechada, `ReaberturaUnidade` (ação separada, com motivo), limites, durações, deslocamento.
6. **Exceções de unidade fechada**: `AgendaExcecoes` (CompromissoId, Data, InicioUtc, FimUtc, Pessoas, Motivo, AutorizadoPorId). A conferência de qualquer outro compromisso continua bloqueando.
7. **Revisão após Passar responsabilidades**: `AgendaRevisoes` (OrigemRef, De, Para, AgendamentoId, Situacao: Pendente/Assumido/Remarcado). Assumir confere a disponibilidade da sucessora antes de trocar a responsável.

### Montagem
Cada área tem uma **fonte** (`IAgendaFonte`) que devolve itens já com o nível de revelação para o usuário (Detalhe / Ocupado / Oculto-mas-conta). O `AgendaService` junta, **remove duplicados pela chave de origem** (ex.: `Agendamento:123` aparece uma vez, mesmo que Recepção e Jurídico o enxerguem), e devolve:
- para exibição: só Detalhe e Ocupado;
- para conflito: todos, inclusive Oculto, reduzidos a faixas de horário.

**Passar responsabilidades:** a permissão na origem muda na hora (a anterior perde o detalhe, inclusive dos manuais que ela criou com o caso vinculado). Os agendamentos **futuros** viram itens de revisão para a sucessora; só passam para a agenda dela quando ela assume (com conferência) ou remarca. Agendamentos passados e registros mantêm a autora original.

### Fuso
UTC no banco, horário de Brasília na tela, com teste de virada de dia (para não repetir o erro de +3h).

### Endpoints
- `GET /api/agenda?de=&ate=&filtros=`
- `GET /api/agenda/resumo?mes=` (pontinhos e contagens já filtrados)
- `POST /api/agenda/disponibilidade` (corpo com o **contexto de agendamento** e as pessoas/assistida dele; recusa sem contexto)
- `POST /api/agenda/conferir` (lista de ocorrências; devolve os conflitos **por data**; a gravação confere de novo)
- `POST /api/agenda/excecoes` (ADM, ligada a um compromisso) e `POST /api/agenda/unidade/{data}/reabrir` (ADM, ação separada)
- `POST /api/agenda/revisoes/{id}/assumir|remarcar`
- `POST/PUT/DELETE /api/agenda/compromissos` (+ `escopo=ocorrencia|seguintes|todas`)
- `POST /api/agenda/ausencias/{id}/confirmar|recusar`
- `POST /api/agendamentos/{id}/chegou|recebida|remarcar|cancelar`
- `POST /api/cursos/{id}/ocorrencias/{data}/cancelar`

### Front-end
`agenda.js` + `calendario.js` em todas as páginas de perfil, HTML/CSS próprios, sem biblioteca paga. Lembretes só com o sistema aberto.

### Testes
Cada célula da matriz; cada linha da tabela de conflitos; ausência de dia inteiro ocupa; série com conflito só na 2ª ou 3ª semana; exceção não libera outros compromissos; professora sem agenda técnica no filtro Pessoas; autora perde detalhe ao perder a origem; ausência informada não tira horário livre; compartilhar não ocupa; "Avisar a Recepção" desligado em caso comum; cancelar "esta e as próximas" sem mexer em aula passada ou com chamada; assumir após Passar responsabilidades confere disponibilidade; "oculto conta no conflito"; cor neutra e contagem sem itens ocultos; disponibilidade recusada sem contexto; deduplicação; ausência informada não bloqueia e confirmada sim; aula cancelada sem chamada pendente; "esta e as próximas"; reavaliação resolvida com risco igual; histórico de remarcação; fuso; E2E de X/Esc/Voltar mantendo formulário e de clique no fundo com edição aberta.

---

## 9. Dados novos

| Dado | Onde |
|---|---|
| Agendamentos com histórico e fluxo de chegada | Jurídico, Psicologia, Serviço Social |
| Horário semanal da turma + ocorrências/cancelamentos | Cursos |
| Reavaliação de risco registrada (data + próxima ação) | Psicologia |
| Data-limite por meta, retorno esperado de encaminhamento à rede, entrada/saída prevista de acolhimento | Serviço Social |
| Comunicação de falta/atraso de aluna | Recepção, Serviço Social, Professora |
| Expediente de cada pessoa | Conta |
| Identificador interno curto da assistida (se ainda não houver um usável) | Cadastro |
| Feriados (nacional, estadual, municipal), unidade fechada, reabertura e exceções por compromisso | ADM |
| Participantes separados de "pode ver"; dia inteiro separado de "ocupa horário" | Compromissos manuais |
| Revisão de compromissos após Passar responsabilidades | Todas as áreas técnicas |

Nada apaga dado antigo.

---

## 10. Protótipo fictício: pasta 03 do ZIP geral

`03-Agenda-Calendario` dentro de `revisao\CasaDaMulher-Prototipos-2026-11-07.zip`.
- `index.html` navegável **sem login e sem servidor**, seletor **"Ver como"** (9 pessoas fictícias, de todos os perfis). A mesma semana aparece filtrada pelas regras da seção 5.
- `dados-ficticios.js`: semana de 09 a 13/11/2026 + mês de novembro, 8 assistidas fictícias (uma com caso restrito, uma com reavaliação pendente, uma em acolhimento, duas alunas), 3 cursos com horário, feriado de 15/11 e de 20/11 com plantão.
- Demonstrações interativas, além das telas normais:
  1. **Chegada na Recepção**: Esperada → Chegou → (troca para a psicóloga) Recebida.
  2. **Ausência registrada por colega**: Bruna registra para Ana; ao agendar com Ana aparece o aviso; Ana confirma.
  3. **Conflito com compromisso sigiloso**: a advogada tenta agendar no horário de uma sessão da assistida e recebe só "Há uma indisponibilidade".
  4. **Cancelar uma aula recorrente** (só esta ocorrência, feriado), sem chamada pendente.
  5. Comunicação de falta que **não** preenche a chamada.
  6. Reavaliação de risco resolvida com risco igual.
  7. Calendário aberto no meio de um formulário, fechado com X/Esc/Voltar, formulário intacto; edição não salva dentro do Calendário pergunta antes de descartar.
  8. Ausência confirmada de dia inteiro gera conflito.
  9. Compromisso semanal: conflito só na 2ª semana, decidido data a data.
  10. Exceção em dia de unidade fechada libera só o compromisso autorizado.
  11. Professora não vê a agenda técnica fora do agendamento.
  12. Autora perde o detalhe ao perder o caso; sucessora recebe para revisar e assume com conferência.
  13. Ausência informada não tira horário livre.
  14. Compartilhar não ocupa a agenda de quem só vê.
- `testes-regras.js`: teste automático das regras (rodar com `node testes-regras.js`; 38 verificações).
- `testes-tela.js`: testes no navegador dos 4 pontos de fechamento (precisa de Playwright; 16 verificações).
- `prints/` (68 a 117) e `LEIA-ME.txt` com roteiro e pontos para confirmar.

---

## 11. Ordem de trabalho

1. Protótipo (pasta 03) para o grupo validar.
2. Base: agendamentos com histórico, compromissos manuais, regra de revelação e conflito, testes da matriz.
3. Agenda na tela inicial (manuais + agendamentos).
4. Turmas com ocorrências, marcos do Serviço Social, reavaliação da Psicologia, fluxo de chegada.
5. Calendário no menu (mini + completo + fechar).
6. "Ver disponibilidade" e conflitos nos formulários.
7. Testes + E2E, ZIP de revisão, e envio ao Render só com o ok do Allan.

---

## 12. Decisões propostas (para confirmar na reunião)

| # | Tema | Decisão proposta |
|---|---|---|
| 1 | Recepção vê atendimento técnico? | Sim: identificação + hora + "Atendimento com a equipe técnica", só presencial na unidade e no dia; nada de visita, acolhimento, local protegido ou motivo; caso restrito só com autorização da responsável. Com fluxo Esperada → Chegou → Recebida. |
| 2 | Conflito bloqueia? | Sobreposição pede confirmação + justificativa (por data, em série); dia cheio e fora do expediente avisam; unidade fechada bloqueia (exceção ADM só para o compromisso autorizado; reabrir para todos é ação separada); feriado só avisa. |
| 3 | Limite diário | 6 como aviso provisório, configurável por pessoa/área, contando só o que ocupa horário e considerando horas. |
| 4 | Durações | 50 min / 1 h / 2 h como sugestão, com intervalo e deslocamento; não obrigatórias. |
| 5 | Salas | Depois. Agora só local opcional, avisando que não reserva. |
| 6 | Em nome de | Qualquer integrante registra aviso operacional; fica "informada" até confirmação; não altera atendimentos nem bloqueia (e não tira horário livre na escolha). |
| 7 | Professoras | Só as próprias turmas por padrão; filtro para outras turmas sem alunas. |
| 8 | Falta/atraso comunicado | Recepção, Serviço Social e professora registram; professora vê quem, qual aula e o fato; sem motivo; não preenche a chamada. |
| 9 | Lembretes externos | Fora desta fase, com o aviso na tela. |
| 10 | Feriados | Nacionais, estaduais e municipais da unidade + fechamentos da Casa; feriado ≠ unidade fechada. |
| 11 | Histórico | Calendário consulta qualquer data; Lista abre em 90 dias; pendências antigas ficam até resolver; exibição não define retenção. |

**Ainda em aberto:** qual é o "nome de identificação" que a Casa usa (nome social? primeiro nome + sobrenome abreviado?) e se já existe um identificador interno curto; cidade/estado da unidade (para feriados); política de retenção dos registros (LGPD).

---

## 13. Fora desta fase
Sincronizar com Google Agenda/Outlook ou `.ics`; e-mail/SMS/WhatsApp/push; autoagendamento pela assistida; reserva de salas e equipamentos; grupos de apoio da Psicologia.
