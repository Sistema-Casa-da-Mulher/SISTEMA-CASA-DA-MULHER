/* DADOS FICTÍCIOS do protótipo de Agenda e Calendário.
   Nenhum nome, código ou horário é real. A "hora atual" é simulada: terça, 10/11/2026, 13:40. */
(function () {
    "use strict";
    const d = (dia, hm, mes) => { const [h, m] = (hm || "00:00").split(":").map(Number); return new Date(2026, (mes || 11) - 1, dia, h, m); };

    const PESSOAS = [
        { id: "rec",   nome: "Carla Mendes",          curto: "Carla",     perfil: "recepcao",   area: "Recepção",        codigo: "REC-000002" },
        { id: "jur1",  nome: "Dra. Fernanda Rocha",   curto: "Fernanda",  perfil: "juridico",   area: "Jurídico",        codigo: "JUR-000003" },
        { id: "jur2",  nome: "Dra. Paula Nogueira",   curto: "Paula",     perfil: "juridico",   area: "Jurídico",        codigo: "JUR-000005" },
        { id: "psi1",  nome: "Ana Beatriz Lima",      curto: "Ana",       perfil: "psicologia", area: "Psicologia",      codigo: "PSI-000001", limiteDia: 4 },
        { id: "psi2",  nome: "Bruna Teixeira",        curto: "Bruna",     perfil: "psicologia", area: "Psicologia",      codigo: "PSI-000004" },
        { id: "soc",   nome: "Renata Alves",          curto: "Renata",    perfil: "as_social",  area: "Serviço Social",  codigo: "SOC-000003" },
        { id: "prof1", nome: "Prof.ª Luciana Prado",  curto: "Luciana",   perfil: "professora", area: "Professora",      codigo: "PROF-000002" },
        { id: "prof2", nome: "Prof.ª Marta Diniz",    curto: "Marta",     perfil: "professora", area: "Professora",      codigo: "PROF-000006" },
        { id: "adm",   nome: "Sônia Ribeiro",         curto: "Sônia",     perfil: "adm",        area: "Coordenação / ADM", codigo: "ADM-000001" }
    ];

    // Nome de identificação + identificador interno curto (sem CPF). Duas "Maria S." de propósito.
    const ASSISTIDAS = [
        { id: "a1", nome: "Joana Lima",       codigo: "AS-0042" },
        { id: "a2", nome: "Maria Souza",      codigo: "AS-0057" },
        { id: "a3", nome: "Maria Santos",     codigo: "AS-0063" },
        { id: "a4", nome: "Cláudia Ferreira", codigo: "AS-0071" },
        { id: "a5", nome: "Patrícia Gomes",   codigo: "AS-0080" },
        { id: "a6", nome: "Rosana Dias",      codigo: "AS-0088" },
        { id: "a7", nome: "Elaine Costa",     codigo: "AS-0091" },
        { id: "a8", nome: "Simone Araújo",    codigo: "AS-0095" }
    ];

    // Origens: quem tem permissão em cada caso/prontuário. Ter a ficha cadastral NÃO basta.
    const ORIGENS = {
        "PSI-2026-000012": { area: "psi", assistida: "a1", responsaveis: ["psi1"], autorizados: [] },
        "PSI-2026-000015": { area: "psi", assistida: "a2", responsaveis: ["psi1"], autorizados: [] },
        "PSI-2026-000009": { area: "psi", assistida: "a4", responsaveis: ["psi1"], autorizados: [], risco: "alto", riscoEm: d(5, "10:00") },
        "PSI-2026-000018": { area: "psi", assistida: "a7", responsaveis: ["psi2"], autorizados: [] },
        "PSI-2026-000020": { area: "psi", assistida: "a5", responsaveis: ["psi1"], autorizados: [] },
        "CJ-2026-000031":  { area: "jur", assistida: "a1", responsaveis: ["jur1"], autorizados: [], visibilidade: "equipe" },
        "CJ-2026-000041":  { area: "jur", assistida: "a2", responsaveis: ["jur1"], autorizados: [], visibilidade: "responsaveis", restrito: true },
        "CJ-2026-000044":  { area: "jur", assistida: "a6", responsaveis: ["jur2"], autorizados: [], visibilidade: "equipe" },
        "CJ-2026-000047":  { area: "jur", assistida: "a8", responsaveis: [], autorizados: [], visibilidade: "equipe", aguardandoAgendamento: true, recebidoEm: d(4, "11:00") },
        "SOC-2026-000007": { area: "soc", assistida: "a3", responsaveis: ["soc"], autorizados: [] },
        "SOC-2026-000010": { area: "soc", assistida: "a5", responsaveis: ["soc"], autorizados: [] },
        "SOC-2026-000011": { area: "soc", assistida: "a1", responsaveis: ["soc"], autorizados: [] }
    };

    const CURSOS = [
        { id: "inf", nome: "Informática Básica", prof: "prof1", dias: [1, 3], ini: "09:00", fim: "11:00", local: "Sala de informática", alunas: ["a1", "a8"] },
        { id: "cos", nome: "Costura",            prof: "prof1", dias: [2, 4], ini: "14:00", fim: "16:00", local: "Sala 3",              alunas: ["a5", "a8"] },
        { id: "emp", nome: "Empreendedorismo",   prof: "prof2", dias: [5],    ini: "09:00", fim: "12:00", local: "Sala 1",              alunas: ["a6", "a7"] }
    ];
    // Chamadas que JÁ foram feitas (curso|dia). Empreendedorismo 06/11 ficou sem chamada (pendência).
    const CHAMADAS_FEITAS = ["inf|2", "inf|4", "cos|3", "cos|5", "inf|9"];

    const CASA = [
        { id: "c1", tipo: "feriado", titulo: "Feriado: Proclamação da República", ini: d(15), diaInteiro: true, fechada: false, nota: "Domingo" },
        { id: "c2", tipo: "feriado", titulo: "Feriado nacional: Dia da Consciência Negra", ini: d(20), diaInteiro: true, fechada: false, nota: "Plantão previsto. A Casa abre só para atendimentos agendados." },
        { id: "c3", tipo: "fechada", titulo: "Unidade fechada: dedetização", ini: d(27), diaInteiro: true, fechada: true, nota: "Definido pela Coordenação. Exceção só com autorização da ADM." },
        { id: "c4", tipo: "evento",  titulo: "Mutirão de documentos (aberto ao público)", ini: d(19, "09:00"), fim: d(19, "13:00"), nota: "Evento da Casa" }
    ];

    // Agendamentos (com histórico de situação) e marcos que vêm das áreas
    const ITENS = [
        // ---- Psicologia (Ana) ----
        { id: "p1", fonte: "psi", tipo: "sessao", titulo: "Sessão nº 3", ref: "PSI-2026-000015", assistida: "a2", dono: "psi1", ini: d(3, "10:00"), fim: d(3, "10:50"), presencial: true, situacao: "agendado" },
        { id: "p2", fonte: "psi", tipo: "sessao", titulo: "Sessão nº 4", ref: "PSI-2026-000012", assistida: "a1", dono: "psi1", ini: d(3, "14:00"), fim: d(3, "14:50"), presencial: true, situacao: "realizado" },
        { id: "p3", fonte: "psi", tipo: "sessao", titulo: "Sessão nº 7", ref: "PSI-2026-000009", assistida: "a4", dono: "psi1", ini: d(5, "10:00"), fim: d(5, "10:50"), presencial: true, situacao: "realizado" },
        { id: "p4", fonte: "psi", tipo: "sessao", titulo: "Sessão nº 4", ref: "PSI-2026-000015", assistida: "a2", dono: "psi1", ini: d(10, "10:00"), fim: d(10, "10:50"), presencial: true, situacao: "realizado", historico: ["Agendada em 03/11 para 09/11 10:00", "Remarcada para 10/11 10:00 (pedido da assistida)", "Realizada em 10/11"] },
        { id: "p5", fonte: "psi", tipo: "sessao", titulo: "Sessão nº 5", ref: "PSI-2026-000012", assistida: "a1", dono: "psi1", ini: d(10, "14:00"), fim: d(10, "14:50"), presencial: true, situacao: "agendado", chegada: { estado: "esperada" } },
        { id: "p6", fonte: "psi", tipo: "sessao", titulo: "Sessão nº 8", ref: "PSI-2026-000009", assistida: "a4", dono: "psi1", ini: d(11, "10:00"), fim: d(11, "10:50"), presencial: true, situacao: "agendado" },
        { id: "p7", fonte: "psi", tipo: "sessao", titulo: "Sessão nº 5", ref: "PSI-2026-000015", assistida: "a2", dono: "psi1", ini: d(12, "09:00"), fim: d(12, "09:50"), presencial: true, situacao: "agendado" },
        { id: "p8", fonte: "psi", tipo: "primeiro", titulo: "Primeiro atendimento (colher consentimento)", ref: "PSI-2026-000020", assistida: "a5", dono: "psi1", ini: d(12, "11:00"), fim: d(12, "11:50"), presencial: true, situacao: "agendado" },
        { id: "p9", fonte: "psi", tipo: "sessao", titulo: "Sessão nº 6", ref: "PSI-2026-000012", assistida: "a1", dono: "psi1", ini: d(17, "14:00"), fim: d(17, "14:50"), presencial: true, situacao: "agendado" },
        { id: "p12", fonte: "psi", tipo: "sessao", titulo: "Sessão nº 6", ref: "PSI-2026-000015", assistida: "a2", dono: "psi1", ini: d(24, "16:00"), fim: d(24, "16:50"), presencial: true, situacao: "agendado" },
        // ---- Psicologia (Bruna) ----
        { id: "p10", fonte: "psi", tipo: "sessao", titulo: "Sessão nº 2", ref: "PSI-2026-000018", assistida: "a7", dono: "psi2", ini: d(10, "09:00"), fim: d(10, "09:50"), presencial: true, situacao: "realizado", avisarRecepcao: false, obs: "A assistida pediu para não ser chamada pela Recepção." },
        { id: "p11", fonte: "psi", tipo: "sessao", titulo: "Sessão nº 3", ref: "PSI-2026-000018", assistida: "a7", dono: "psi2", ini: d(11, "14:00"), fim: d(11, "14:50"), presencial: true, situacao: "agendado" },

        // ---- Jurídico ----
        { id: "j1", fonte: "jur", tipo: "atendimento", titulo: "Atendimento jurídico", ref: "CJ-2026-000041", assistida: "a2", dono: "jur1", ini: d(10, "15:00"), fim: d(10, "16:00"), presencial: true, avisarRecepcao: false, situacao: "agendado", chegada: { estado: "esperada" } },
        { id: "j2", fonte: "jur", tipo: "retorno", titulo: "Retorno jurídico", ref: "CJ-2026-000031", assistida: "a1", dono: "jur1", ini: d(11, "14:00"), fim: d(11, "15:00"), presencial: true, avisarRecepcao: true, situacao: "agendado" },
        { id: "j3", fonte: "jur", tipo: "audiencia", titulo: "Audiência", ref: "CJ-2026-000041", assistida: "a2", dono: "jur1", ini: d(12, "13:00"), fim: d(12, "15:00"), local: "Fórum de Itaquaquecetuba", presencial: false, situacao: "agendado" },
        { id: "j4", fonte: "jur", tipo: "prazo", titulo: "Prazo de manifestação", ref: "CJ-2026-000041", assistida: "a2", dono: "jur1", ini: d(13), diaInteiro: true, ocupa: false },
        { id: "j5", fonte: "jur", tipo: "atendimento", titulo: "Atendimento jurídico", ref: "CJ-2026-000044", assistida: "a6", dono: "jur2", ini: d(10, "16:30"), fim: d(10, "17:30"), presencial: true, avisarRecepcao: true, situacao: "agendado", chegada: { estado: "esperada" } },
        { id: "j6", fonte: "jur", tipo: "retorno", titulo: "Retorno jurídico", ref: "CJ-2026-000044", assistida: "a6", dono: "jur2", ini: d(13, "10:00"), fim: d(13, "11:00"), presencial: true, avisarRecepcao: true, situacao: "agendado" },
        { id: "j7", fonte: "jur", tipo: "atendimento", titulo: "Atendimento jurídico", ref: "CJ-2026-000044", assistida: "a6", dono: "jur2", ini: d(12, "13:30"), fim: d(12, "14:30"), presencial: true, avisarRecepcao: true, situacao: "agendado" },

        // ---- Serviço Social (Renata) ----
        { id: "s1", fonte: "soc", tipo: "marco", titulo: "Entrada em acolhimento", ref: "SOC-2026-000007", assistida: "a3", dono: "soc", ini: d(9), diaInteiro: true, ocupa: false, local: "Local protegido (não exibido)" },
        { id: "s2", fonte: "soc", tipo: "atendimento_soc", titulo: "Atendimento social", ref: "SOC-2026-000007", assistida: "a3", dono: "soc", ini: d(10, "16:00"), fim: d(10, "16:50"), presencial: true, avisarRecepcao: true, situacao: "agendado", chegada: { estado: "esperada" } },
        { id: "s3", fonte: "soc", tipo: "visita", titulo: "Visita domiciliar", ref: "SOC-2026-000010", assistida: "a5", dono: "soc", ini: d(11, "13:30"), fim: d(11, "15:30"), deslocamento: 30, presencial: false, situacao: "agendado" },
        { id: "s4", fonte: "soc", tipo: "marco", titulo: "Meta do plano: matrícula da filha na escola", ref: "SOC-2026-000010", assistida: "a5", dono: "soc", ini: d(12), diaInteiro: true, ocupa: false },
        { id: "s5", fonte: "soc", tipo: "retornoRede", titulo: "Retorno esperado do CRAS", ref: "SOC-2026-000007", assistida: "a3", dono: "soc", ini: d(6), diaInteiro: true, ocupa: false, pendente: true },
        { id: "s6", fonte: "soc", tipo: "marco", titulo: "Saída prevista do acolhimento", ref: "SOC-2026-000007", assistida: "a3", dono: "soc", ini: d(23), diaInteiro: true, ocupa: false, local: "Local protegido (não exibido)" },

        // ---- Compromissos manuais ----
        { id: "m1", fonte: "manual", tipo: "ausencia", titulo: "Ausência informada", dono: "psi1", registradoPor: "psi2", ini: d(11, "09:00"), fim: d(11, "12:00"), vis: "equipe", ausencia: "informada", obs: "Ana ligou avisando. Registrado por Bruna em nome dela." },
        { id: "m2", fonte: "manual", tipo: "ausencia", titulo: "Volto às 15h (vou ao Fórum antes)", dono: "jur2", registradoPor: "jur2", ini: d(10, "12:00"), fim: d(10, "15:00"), vis: "equipe", ausencia: "confirmada" },
        { id: "m3", fonte: "manual", tipo: "reuniao", titulo: "Reunião de equipe", dono: "adm", registradoPor: "adm", ini: d(12, "16:00"), fim: d(12, "17:00"), vis: "equipe", local: "Sala 1", participantesTodos: true },
        { id: "m4", fonte: "manual", tipo: "lembrete", titulo: "Ligar para a Defensoria sobre o caso", dono: "jur1", registradoPor: "jur1", ini: d(11, "10:00"), vis: "eu", ocupa: false, ref: "CJ-2026-000041", assistida: "a2" },
        { id: "m5", fonte: "manual", tipo: "lembrete", titulo: "Levar pen drives para a aula", dono: "prof1", registradoPor: "prof1", ini: d(16, "08:30"), vis: "eu", ocupa: false },
        { id: "m6", fonte: "manual", tipo: "comunicacao", titulo: "Avisou que vai faltar", dono: "prof1", registradoPor: "rec", assistida: "a1", curso: "inf", ini: d(11, "09:00"), vis: "pessoas", verPessoas: ["prof1"], ocupa: false, comunicacao: "falta" },
        { id: "m7", fonte: "manual", tipo: "comunicacao", titulo: "Avisou que chega 30 min atrasada", dono: "prof1", registradoPor: "soc", assistida: "a5", curso: "cos", ini: d(12, "14:00"), vis: "pessoas", verPessoas: ["prof1"], ocupa: false, comunicacao: "atraso" },
        { id: "m8", fonte: "manual", tipo: "ausencia", titulo: "Capacitação externa (CREAS)", dono: "soc", registradoPor: "soc", ini: d(13, "13:00"), fim: d(13, "17:00"), vis: "equipe", ausencia: "confirmada" },
        { id: "m9", fonte: "manual", tipo: "reuniao", titulo: "Planejamento do grupo de apoio", dono: "psi1", registradoPor: "psi1", ini: d(12, "14:00"), fim: d(12, "15:30"), vis: "area" },
        { id: "m11", fonte: "manual", tipo: "ausencia", titulo: "Folga (banco de horas)", dono: "jur2", registradoPor: "jur2", ini: d(19), diaInteiro: true, vis: "equipe", ausencia: "confirmada" },
        { id: "m10", fonte: "manual", tipo: "lembrete", titulo: "Revisar plano de acompanhamento", dono: "soc", registradoPor: "soc", ini: d(12, "08:30"), vis: "eu", ocupa: false, ref: "SOC-2026-000010", assistida: "a5" }
    ];
    // Supervisão semanal (recorrente) da Psicologia: quartas 16h, até 16/12
    ["4", "11", "18", "25"].forEach((dia, i) => ITENS.push({ id: "sup" + dia, fonte: "manual", tipo: "reuniao", titulo: "Supervisão clínica (semanal)", dono: "psi1", registradoPor: "psi1", participantes: ["psi2"], ini: d(+dia, "16:00"), fim: d(+dia, "17:00"), vis: "pessoas", serie: "sup" }));

    window.AG_DADOS = {
        AGORA: d(10, "13:40"),
        PESSOAS, ASSISTIDAS, ORIGENS, CURSOS, CHAMADAS_FEITAS, CASA, ITENS,
        CONFIG: { limiteCompromissos: 6, limiteHoras: 6, expediente: ["08:00", "17:00"], duracoes: { sessao: 50, intervaloSessao: 10, atendimento: 60, visita: 120, deslocamento: 30 } }
    };
})();
