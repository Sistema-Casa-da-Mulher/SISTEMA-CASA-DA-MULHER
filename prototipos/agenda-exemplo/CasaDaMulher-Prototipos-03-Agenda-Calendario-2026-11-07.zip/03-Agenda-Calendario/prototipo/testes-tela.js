/* Testes de tela da rodada 4 (opcional: precisa de Node.js e Playwright).
   Como rodar:  node testes-tela.js   (na pasta prototipo) */
"use strict";
const { chromium } = require("playwright");
const path = require("path");
let ok = 0, falhas = 0;
const t = (nome, cond) => { if (cond) { ok++; console.log("  ok    " + nome); } else { falhas++; console.log("  FALHA " + nome); } };
(async () => {
    const b = await chromium.launch({ args: ["--lang=pt-BR"] });
    const p = await (await b.newContext({ locale: "pt-BR", timezoneId: "America/Sao_Paulo", viewport: { width: 1400, height: 900 } })).newPage();
    p.setDefaultTimeout(5000);
    const erros = []; p.on("pageerror", e => erros.push(e.message));
    const abrir = async () => { await p.goto("file://" + path.join(__dirname, "index.html")); await p.waitForTimeout(200); };
    const ver = id => p.evaluate(v => AG_UI.setViewer(v), id);
    const modalTxt = async () => { const m = await p.$(".ag-modal:last-of-type .ag-modal-c"); return m ? m.innerText() : ""; };
    const fecharModais = async () => { while (await p.$(".ag-modal")) { await p.keyboard.press("Escape"); await p.waitForTimeout(60); } };
    console.log("Testes de tela (rodada 4)\n");

    // 1. Detalhe na Recepção nos três estados
    await abrir(); await ver("rec");
    const recebida = await p.evaluate(() => { const it = AG.todos().find(i => AG.revelar(i, AG.pessoa("rec")) === "recepcao" && i.chegada.estado === "recebida"); return it && it.id; });
    await p.evaluate(() => AG_UI.abrirDetalhe("p5")); let tx = await modalTxt();
    t("Recepção: detalhe 'Esperada' abre sem erro", /Esperada/.test(tx) && !erros.length); await fecharModais();
    await p.click('[data-chegou="p5"]');
    await p.evaluate(() => AG_UI.abrirDetalhe("p5")); tx = await modalTxt();
    t("Recepção: detalhe 'Chegou' mostra só a hora da chegada", /Chegou às 13:40/.test(tx) && !/Recebida/.test(tx) && !erros.length); await fecharModais();
    if (recebida) { await p.evaluate(id => AG_UI.abrirDetalhe(id), recebida); tx = await modalTxt(); }
    t("Recepção: detalhe 'Recebida' abre sem erro", !!recebida && /Recebida pela equipe às/.test(tx) && !erros.length); await fecharModais();

    // 2. Chegada marcada, caso transferido: a antiga responsável perde identificação e ações
    await abrir();
    await p.evaluate(() => { const it = AG.todos().find(i => i.id === "j1"); it.chegada = { estado: "chegou", chegouEm: new Date(2026, 10, 10, 14, 52) }; });
    await ver("jur1"); await p.click('#cardAgenda [data-aba="pend"]');
    t("Antes: Fernanda vê a pendência de chegada", (await p.innerText("#cardAgenda")).includes("Maria Souza (AS-0057) chegou"));
    await ver("adm"); await p.click("[data-passar]");
    await ver("jur1"); await p.click('#cardAgenda [data-aba="pend"]');
    const pendF = await p.innerText("#cardAgenda");
    t("Depois: nenhuma pendência dela mostra a assistida do caso", !pendF.includes("AS-0057"));
    t("Depois: não há botão 'Marcar como recebida' para ela", !(await p.$('[data-pend="recebida"][data-id="j1"]')));
    await p.evaluate(() => AG_UI.acaoPendencia("recebida", "j1"));
    t("Mesmo chamando a ação direto, nada muda", (await p.evaluate(() => AG.todos().find(i => i.id === "j1").chegada.estado)) === "chegou");

    // 3. Remarcar: o horário antigo sai das esperadas e fica no histórico
    await abrir(); await ver("rec");
    t("Antes: Recepção espera a Rosana às 16:30", !!(await p.$('[data-esperada="j5"]')));
    await ver("jur2");
    await p.evaluate(() => AG_UI.abrirDetalhe("j5")); await p.click('.ag-modal [data-acao="remarcar"]');
    await p.fill("#fData", "2026-11-17"); await p.fill("#fHora", "16:30");
    await p.click("#formAg button[type=submit]"); await p.waitForTimeout(150);
    for (const j of await p.$$("[data-just]")) await j.fill("Remarcação combinada com a assistida");
    if (await p.$("#cfOk")) await p.click("#cfOk");
    await p.waitForTimeout(150);
    t("Remarcação salva", (await p.evaluate(() => AG.todos().find(i => i.id === "j5").situacao)) === "remarcado");
    await ver("rec");
    t("Depois: o horário antigo não está nas esperadas", !(await p.$('[data-esperada="j5"]')));
    await p.evaluate(() => AG_UI.abrirDetalhe("j5")); tx = await modalTxt();
    t("Recepção não abre o horário antigo nem marca chegada", !/Chegou/.test(tx) && !(await p.$('.ag-modal [data-acao="chegou"]'))); await fecharModais();
    await ver("jur2"); await p.evaluate(() => AG_UI.abrirDetalhe("j5")); tx = await modalTxt();
    t("Para a responsável, o antigo fica no histórico como remarcado", /remarcado/i.test(tx) && /Remarcado por Paula para 17\/11 16:30/.test(tx)); await fecharModais();

    // 4. Reavaliação: a próxima ação fica guardada e pode ser consultada
    await abrir(); await ver("psi1"); await p.click('#cardAgenda [data-aba="pend"]');
    const acao = "Manter sessão semanal; contato com o CAPS combinado para 13/11 às 9h.";
    await p.click('[data-pend="reavaliar"]'); await p.fill("#rvA", acao); await p.click("#rvOk"); await p.waitForTimeout(100);
    await p.click('#cardAgenda [data-aba="pend"]');
    await p.click('[data-pend="verReav"]'); tx = await modalTxt();
    t("Registro reaberto mostra a próxima ação exatamente como escrita", tx.includes(acao) && /alto/.test(tx) && /Ana Beatriz Lima/.test(tx) && /10\/11/.test(tx));

    // 5. Registro de reavaliação não abre para quem perdeu o acesso ao prontuário
    await fecharModais();
    await p.evaluate(() => { const o = AG.origem("PSI-2026-000009"); o.responsaveis = ["psi2"]; o.autorizados = []; });
    await ver("psi1");
    await p.evaluate(() => AG_UI.acaoPendencia("verReav", "PSI-2026-000009")); await p.waitForTimeout(100);
    const corpo = await p.innerText("body");
    t("Sem acesso: chamar verReav direto não abre o registro", !(await p.$(".ag-modal")) && !corpo.includes(acao) && !corpo.includes("Reavaliações de risco"));
    t("Sem acesso: a lista 'Reavaliações registradas' some", !(await p.$('[data-pend="verReav"]')));

    t("Nenhum erro de JavaScript durante os testes", !erros.length);
    if (erros.length) console.log(erros);
    await b.close();
    console.log(`\n${ok} de ${ok + falhas} verificações passaram.`);
    process.exitCode = falhas ? 1 : 0;
})();
