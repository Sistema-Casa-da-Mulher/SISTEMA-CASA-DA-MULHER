/* Protótipo de Agenda e Calendário — telas. Dados fictícios, sem servidor. */
(function () {
    "use strict";
    const D = window.AG_DADOS, esc = AG.esc;
    const $ = (s, r) => (r || document).querySelector(s);
    const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
    const HOJE = AG.inicioDia(D.AGORA);
    let V = AG.pessoa("psi1");
    const UI = {
        aba: "hoje", demo: null,
        cal: { aberto: false, visao: "semana", ref: HOJE, filtros: null, pessoas: new Set(), escolha: null, opener: null, lista: { de: AG.somaDias(HOJE, -90), ate: AG.somaDias(HOJE, 30) } },
        mini: { ref: new Date(2026, 10, 1), fixo: false, timer: null, foco: null }
    };

    // ---------------- textos e cores ----------------
    function classe(it, nivel) {
        if (nivel === "ocupado" || nivel === "contagem" || nivel === "semacesso") return "k-neu";
        if (nivel === "recepcao") return "k-equipe";
        if (it.fonte === "casa") return it.tipo === "fechada" ? "k-fec" : it.tipo === "feriado" ? "k-fer" : "k-man";
        if (it.fonte === "curso") return "k-aula";
        if (it.fonte === "manual") return it.tipo === "ausencia" ? "k-aus" : it.tipo === "comunicacao" ? "k-aula" : "k-man";
        return { psi: "k-psi", jur: "k-jur", soc: "k-soc" }[it.fonte];
    }
    function textos(it, nivel) {
        const p = AG.pessoa(it.dono);
        if (nivel === "ocupado") return { t: "Indisponível", s: p ? p.curto : "", c: p ? p.curto : "" };
        if (nivel === "semacesso") return { t: "Compromisso de um caso que você não acessa mais", s: "Só o horário continua visível para você", c: "sem acesso ao caso" };
        if (nivel === "recepcao") return { t: AG.identAssistida(it.assistida), s: "Atendimento com a equipe técnica", c: "Atendimento com a equipe técnica" };
        if (it.fonte === "casa") return { t: it.titulo, s: it.nota || "" };
        if (it.fonte === "curso") {
            const c = AG.curso(it.curso);
            if (it.cancelada) return { t: it.titulo, s: "Cancelada: " + it.cancelada.motivo };
            if (nivel === "curso") return { t: it.titulo, s: `${AG.pessoa(c.prof).nome} · ${c.local}` };
            const com = comunicacoesDaAula(it).length;
            return { t: it.titulo, s: `${c.local} · ${c.alunas.length} alunas${com ? " · " + com + " comunicação(ões)" : ""}${it.fim < D.AGORA && !it.chamada ? " · chamada pendente" : ""}` };
        }
        if (it.tipo === "comunicacao") return { t: `${AG.identAssistida(it.assistida)}: ${it.titulo.toLowerCase()}`, s: `${AG.curso(it.curso).nome} · registrado por ${AG.pessoa(it.registradoPor).curto}` };
        let s = [];
        if (it.dono !== V.id) s.push(p.curto);
        if (it.assistida) s.push(AG.identAssistida(it.assistida));
        if (it.ref && it.fonte !== "manual") s.push(it.ref);
        if (it.local) s.push(it.local);
        if (it.tipo === "ausencia" && it.registradoPor !== it.dono) s.push(`registrado por ${AG.pessoa(it.registradoPor).curto} em nome de ${p.curto}`);
        if (it.tipo === "ausencia") s.push(it.ausencia === "informada" ? "INFORMADA, aguardando confirmação" : it.ausencia === "recusada" ? "não procede" : "confirmada");
        if (it.chegada && it.chegada.estado === "chegou") s.push("chegou às " + AG.hm(it.chegada.chegouEm));
        if (it.chegada && it.chegada.estado === "recebida") s.push("recebida às " + AG.hm(it.chegada.recebidaEm));
        if (it.situacao && it.situacao !== "agendado") s.push(it.situacao);
        if ((it.verPessoas || []).includes(V.id) && !AG.envolve(it, V.id)) s.push("compartilhado com você (não participa)");
        const curto = it.assistida ? AG.identAssistida(it.assistida) : (it.dono !== V.id ? p.curto : (it.local || ""));
        return { t: it.titulo, s: s.join(" · "), c: curto };
    }
    // Texto da chegada conforme o estado atual: só formata os horários que existem.
    function textoChegada(c, maiuscula) {
        if (!c) return "";
        let t = "esperada";
        if (c.estado === "chegou") t = c.chegouEm ? "chegou às " + AG.hm(c.chegouEm) : "chegou";
        if (c.estado === "recebida") t = c.recebidaEm ? "recebida pela equipe às " + AG.hm(c.recebidaEm) : "recebida pela equipe";
        return maiuscula ? t.charAt(0).toUpperCase() + t.slice(1) : t;
    }
    function comunicacoesDaAula(aula) {
        return AG.estado.itens.filter(x => x.tipo === "comunicacao" && x.curso === aula.curso && AG.mesmoDia(x.ini, aula.ini));
    }
    const horaTxt = it => it.diaInteiro ? "dia todo" : AG.hm(it.ini);
    const equipeAlheio = x => x.g === "equipe" && x.it.dono !== V.id;

    // ---------------- utilidades de UI ----------------
    function toast(msg) {
        const t = document.createElement("div");
        t.className = "ag-toast"; t.textContent = msg; document.body.appendChild(t);
        setTimeout(() => t.remove(), 3200);
    }
    function modal(html, opts) {
        opts = opts || {};
        const m = document.createElement("div");
        m.className = "ag-modal";
        m.innerHTML = `<div class="ag-modal-c" role="dialog" aria-modal="true">${html}</div>`;
        const anterior = document.activeElement;
        const fechar = () => { m.remove(); if (anterior && anterior.focus && document.contains(anterior)) anterior.focus(); };
        // Mesmo tratamento para X, Esc, clique fora e Voltar do navegador: se houver texto não salvo, pergunta.
        const tentarFechar = depois => { if (opts.sujo && opts.sujo()) perguntarDescartar(() => { fechar(); if (depois) depois(); }); else { fechar(); if (depois) depois(); } };
        m.tentarFechar = tentarFechar;
        m.addEventListener("mousedown", e => { if (e.target === m) tentarFechar(); });
        m.addEventListener("click", e => { if (e.target.closest("[data-fechar]")) tentarFechar(); });
        m.addEventListener("keydown", e => { if (e.key === "Escape") { e.stopPropagation(); tentarFechar(); } });
        if (opts.sujo) m.dataset.temEdicao = "1";
        if (opts.acima) m.style.zIndex = 1700;
        document.body.appendChild(m);
        const f = m.querySelector("input, select, textarea, button:not([data-fechar])") || m.querySelector(".ag-modal-c"); if (f.classList.contains("ag-modal-c")) f.tabIndex = -1; f.focus();
        return { m, fechar, tentarFechar };
    }
    function perguntarDescartar(sim) {
        const p = document.createElement("div");
        p.className = "ag-modal"; p.style.zIndex = 1900;
        p.innerHTML = `<div class="ag-modal-c" role="alertdialog" aria-modal="true" style="max-width:420px"><h3>Descartar o que foi digitado?</h3><p>O compromisso que você estava preenchendo ainda não foi salvo.</p><div class="ag-acoes"><button type="button" class="soft-btn soft-btn-primary" data-continuar>Continuar editando</button><button type="button" class="soft-btn soft-btn-danger" data-descartar>Descartar</button></div></div>`;
        document.body.appendChild(p);
        $("[data-continuar]", p).focus();
        p.addEventListener("keydown", e => { if (e.key === "Escape") { e.stopPropagation(); p.remove(); } });
        p.addEventListener("click", e => { if (e.target.closest("[data-continuar]") || e.target === p) p.remove(); if (e.target.closest("[data-descartar]")) { p.remove(); sim(); } });
    }
    const ymd = dt => `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
    const lerData = (dStr, hStr) => { const [y, mo, da] = dStr.split("-").map(Number); const [h, mi] = (hStr || "00:00").split(":").map(Number); return new Date(y, mo - 1, da, h, mi); };
    const nomeTab = { recepcao: ["Mulheres atendidas", "Cadastro", "Direcionamento"], juridico: ["Fila de encaminhadas", "Assistidas", "Cadastrar assistida", "Indicadores", "Relatórios"], psicologia: ["Fila", "Prontuários", "Relatórios"], as_social: ["Fila", "Prontuários sociais", "Relatórios"], professora: ["Alunas do curso", "Plano de aula", "Chamada", "Relatórios"], adm: ["Funcionários", "Cursos", "Convites", "Auditoria", "Relatórios"] };

    // ---------------- página ----------------
    function render() {
        if (UI.cal.aberto) { UI.cal.aberto = false; if (history.state && history.state.calendario) history.replaceState(null, "", location.pathname); }
        document.body.innerHTML = `
        <div class="ag-barra" role="region" aria-label="Controles do protótipo">
            <span><b>Protótipo</b> · dados fictícios</span>
            <label>Ver como: <select id="verComo">${D.PESSOAS.map(p => `<option value="${p.id}" ${p.id === V.id ? "selected" : ""}>${esc(p.nome)} (${esc(p.area)})</option>`).join("")}</select></label>
            <label>Demonstração: <select id="demoSel"><option value="">escolha…</option>${DEMOS.map((d, i) => `<option value="${i}" ${UI.demo === i ? "selected" : ""}>${i + 1}. ${esc(d.nome)}</option>`).join("")}</select></label>
            <button type="button" id="btnReiniciar">Reiniciar dados</button>
            <span class="ag-hora">Hora simulada: terça, 10/11/2026, 13:40</span>
        </div>
        <main style="max-width: 1400px; margin: 0 auto; padding: 24px 20px;">
            <header class="soft-header">
                <div><h1 class="soft-header-title">Casa da Mulher de Itaquaquecetuba</h1><p class="soft-header-subtitle">${esc(V.area)}</p></div>
                ${sessaoHtml()}
            </header>
            ${UI.demo != null ? demoHtml(DEMOS[UI.demo]) : ""}
            <span class="ag-prototipo">Protótipo com dados fictícios. Nada desta tela está no sistema ainda.</span>
            <div class="soft-tabs ag-tabs"><button type="button" class="soft-tab active">Início</button>${nomeTab[V.perfil].map(t => `<button type="button" class="soft-tab" title="Aba que já existe no sistema" tabindex="-1">${t}</button>`).join("")}</div>
            <div class="ag-home">
                <div><section class="soft-card" id="cardAgenda"></section></div>
                <div id="colTrabalho">${trabalhoHtml()}</div>
            </div>
        </main>`;
        ligarPagina();
        atualizar();
    }
    function sessaoHtml() {
        return `<div class="soft-session-card" id="sessionCard">
            <div class="soft-clock session-trigger" tabindex="0" role="button" aria-haspopup="true" id="sessionTrigger"><div id="currentDate">ter., 10/11/2026</div><div id="currentTime">13:40</div></div>
            <div class="session-dropdown" id="sessionDropdown">
                <div class="session-user-name">${esc(V.nome)}</div>
                <div class="session-user-role">${esc(V.area)}</div>
                <div class="session-user-meta">ID: ${esc(V.codigo)}</div>
                <div class="session-user-meta">Sessão expira às 14:10 (30 min após o login)</div>
                <div class="ag-menu-linha"><span>Logout automático</span><select aria-label="Logout automático"><option>Desligado</option><option>12:00</option><option selected>18:00</option></select></div>
                <div class="ag-cal-item" id="calItem">
                    <button type="button" class="ag-cal-btn" id="btnCal" aria-haspopup="dialog" aria-expanded="false">📅 Calendário <span class="seta">mês ▸</span></button>
                    <div class="ag-mini hidden" id="mini" role="dialog" aria-label="Mini calendário"></div>
                </div>
                <div class="session-actions">
                    <button type="button" class="soft-btn soft-btn-warning" style="flex:1" data-toast="No sistema: volta ao painel.">Voltar</button>
                    <button type="button" class="soft-btn soft-btn-danger" style="flex:1" data-toast="No sistema: sai da conta.">Sair</button>
                </div>
            </div>
        </div>`;
    }
    function demoHtml(d) {
        return `<div class="ag-demo" id="demoBox"><button class="x" type="button" id="demoX" aria-label="Fechar roteiro">×</button><b>Demonstração ${UI.demo + 1}: ${esc(d.nome)}</b><ol>${d.passos.map(p => `<li>${p}</li>`).join("")}</ol></div>`;
    }

    // ---------------- Agenda (tela inicial) ----------------
    function linhaHtml(x) {
        const { it, nivel } = x, tx = textos(it, nivel);
        const riscado = it.cancelada || it.situacao === "cancelado" || it.ausencia === "recusada";
        let tag = "";
        if (x.g === "equipe" && it.dono !== V.id) tag = `<span class="ag-tag k-aus">aviso da equipe${it.ausencia === "informada" ? " · informada" : ""}</span>`;
        else if (it.tipo === "ausencia" && it.ausencia === "informada") tag = `<span class="ag-tag" style="--bg:#FFF4D1;--cor:#6B4F17">informada</span>`;
        else if (nivel === "semacesso") tag = `<span class="ag-tag k-neu">sem acesso</span>`;
        else if (it.chegada && it.chegada.estado === "chegou" && (nivel === "detalhe" || nivel === "recepcao")) tag = `<span class="ag-tag" style="--bg:#E3EBF1;--cor:#4D6577">chegou</span>`;
        else if (it.fonte === "curso" && !it.cancelada && it.fim < D.AGORA && !it.chamada && nivel === "detalhe") tag = `<span class="ag-tag" style="--bg:#FFF4D1;--cor:#6B4F17">chamada pendente</span>`;
        else if (it.diaInteiro || !it.fim) tag = `<span class="ag-tag">${it.ocupa === false || it.diaInteiro ? "marco" : ""}</span>`;
        return `<li><button type="button" class="ag-linha ${classe(it, nivel)} ${riscado ? "riscado" : ""}" data-item="${it.id}" data-nivel="${nivel}"><span class="h">${horaTxt(it)}</span><span><span class="t">${esc(tx.t)}</span><span class="s" style="display:block">${esc(tx.s)}</span></span>${tag}</button></li>`;
    }
    function renderAgenda() {
        const card = $("#cardAgenda"); if (!card) return;
        const filtros = new Set(AG.filtrosPadrao(V));
        const hoje = AG.visiveis(V, HOJE, AG.somaDias(HOJE, 1), filtros).filter(x => x.nivel !== "contagem");
        const prox = AG.visiveis(V, AG.somaDias(HOJE, 1), AG.somaDias(HOJE, 8), filtros).filter(x => x.nivel !== "contagem");
        const pend = AG.pendencias(V);
        let corpo = "";
        if (UI.aba === "hoje") {
            let cnt = "";
            if (V.perfil === "adm") { const c = AG.contagens(V, HOJE); cnt = `<div class="ag-cnt" style="margin-bottom:10px"><span>Jurídico: ${c.jur} atendimento(s)</span><span>Psicologia: ${c.psi}</span><span>Serviço Social: ${c.soc}</span></div><p class="ag-nota" style="margin:-4px 0 10px">Atendimentos técnicos aparecem só em número, sem nomes.</p>`; }
            corpo = cnt + (hoje.length ? `<ul class="ag-lista">${hoje.map(linhaHtml).join("")}</ul>` : `<div class="ag-vazio">Nada para hoje.</div>`);
        } else if (UI.aba === "prox") {
            const porDia = {};
            prox.forEach(x => { const k = ymd(x.it.ini); (porDia[k] = porDia[k] || []).push(x); });
            corpo = Object.keys(porDia).sort().map(k => { const dt = lerData(k); return `<div class="ag-dia-titulo">${AG.diaLongo(dt)}, ${AG.dm(dt)}</div><ul class="ag-lista">${porDia[k].map(linhaHtml).join("")}</ul>`; }).join("") || `<div class="ag-vazio">Nada nos próximos 7 dias.</div>`;
        } else {
            corpo = pend.length ? `<div style="display:flex;flex-direction:column;gap:8px">${pend.map(pendHtml).join("")}</div>` : `<div class="ag-vazio">Nenhuma pendência.</div>`;
            const regs = Object.keys(AG.estado.reavaliacao).filter(ref => (AG.estado.reavaliacao[ref].registros || []).length && AG.acessoOrigem(V, ref));
            if (regs.length) corpo += `<div class="ag-dia-titulo">Reavaliações registradas</div><div style="display:flex;flex-direction:column;gap:8px">${regs.map(ref => { const r = AG.estado.reavaliacao[ref], g = r.registros[r.registros.length - 1]; return `<div class="ag-pend" style="--cor:#24805F">${esc(AG.identAssistida(AG.origem(ref).assistida))} · ${ref}: ${esc(g.classificacao)} em ${AG.dm(g.em)} ${AG.hm(g.em)} por ${esc(AG.pessoa(g.por).curto)}<div class="nota">Próxima ação: ${esc(g.proximaAcao)}</div><div class="acoes"><button type="button" class="soft-btn soft-btn-secondary ag-btn-sm" data-pend="verReav" data-id="${ref}">Ver registro</button></div></div>`; }).join("")}</div>`;
        }
        card.innerHTML = `<div class="ag-card-top"><h2 class="soft-card-title">Agenda</h2><button type="button" class="soft-btn soft-btn-primary" id="btnNovo">+ Novo compromisso</button></div>
            <div class="ag-subtabs" role="tablist">
                <button type="button" class="ag-subtab ${UI.aba === "hoje" ? "active" : ""}" data-aba="hoje">Hoje <span class="n">${hoje.length}</span></button>
                <button type="button" class="ag-subtab ${UI.aba === "prox" ? "active" : ""}" data-aba="prox">Próximos 7 dias <span class="n">${prox.length}</span></button>
                <button type="button" class="ag-subtab ${UI.aba === "pend" ? "active" : ""}" data-aba="pend" id="abaPend">Pendências <span class="n">${pend.length}</span></button>
            </div>${corpo}
            <p class="ag-nota">Os lembretes aparecem enquanto o sistema estiver aberto. Para ver o mês, use <b>Calendário</b> no menu do seu nome.</p>`;
    }
    function pendHtml(p) {
        const b = (acao, txt, extra) => `<button type="button" class="soft-btn soft-btn-secondary ag-btn-sm" data-pend="${acao}" data-id="${p.it ? p.it.id : p.ref}" ${extra || ""}>${txt}</button>`;
        let acoes = "";
        if (p.tipo === "chegada") acoes = b("recebida", "Marcar como recebida");
        if (p.tipo === "resultado") acoes = b("resultado", "Registrar resultado");
        if (p.tipo === "reavaliacao") acoes = b("reavaliar", "Registrar reavaliação");
        if (p.tipo === "ausencia") acoes = (p.it.dono === V.id || V.perfil === "adm") ? b("ausOk", "Confirmar") + b("ausNao", "Não procede") : "";
        if (p.tipo === "chamada") acoes = b("chamada", "Fazer chamada");
        if (p.tipo === "fechada") acoes = b("cancelarAula", "Cancelar esta aula");
        if (p.tipo === "encaminhamento") acoes = b("agendarEnc", "Agendar");
        if (p.tipo === "rede") acoes = b("rede", "Registrar retorno");
        if (p.tipo === "revisar") acoes = b("assumir", "Assumir na minha agenda") + b("remarcar", "Remarcar");
        return `<div class="ag-pend">${esc(p.txt)}${p.nota ? `<div class="nota">${esc(p.nota)}</div>` : ""}${acoes ? `<div class="acoes">${acoes}</div>` : ""}</div>`;
    }

    // ---------------- coluna de trabalho por perfil ----------------
    function trabalhoHtml() {
        const P = V.perfil;
        if (P === "recepcao") return `<section class="soft-card"><div class="ag-card-top"><h2 class="soft-card-title">Esperadas hoje</h2><button type="button" class="soft-btn soft-btn-secondary" id="btnComunic">Registrar falta ou atraso de aluna</button></div><div id="esperadas"></div>
            <p class="ag-nota">Aparecem só atendimentos <b>presenciais na unidade</b>, só no dia: nome de identificação, código interno e horário. Área, motivo, visitas, acolhimento e local protegido nunca aparecem. Só aparece quem a profissional marcou “Avisar a Recepção” (vem ligado em casos comuns e desligado em casos restritos; se ela desligar, a assistida não aparece aqui).</p></section>`;
        if (P === "professora") return `<section class="soft-card"><h2 class="soft-card-title">Minhas aulas</h2><div id="aulasProf"></div><p class="ag-nota">Comunicações de falta ou atraso aparecem ao lado do nome na chamada, mas <b>não marcam nada</b>: a chamada registra o que de fato aconteceu.</p></section>`;
        if (P === "adm") return `<section class="soft-card"><h2 class="soft-card-title">Configuração da agenda</h2><div id="admCfg"></div></section>`;
        return `<section class="soft-card"><h2 class="soft-card-title">${{ psicologia: "Agendar sessão", juridico: "Agendar atendimento", as_social: "Agendar visita ou atendimento" }[P]}</h2>${formAgendarHtml()}</section>`;
    }
    function origensDoViewer() {
        return Object.keys(AG.estado.origens).filter(ref => AG.acessoOrigem(V, ref) && AG.estado.origens[ref].area === { psicologia: "psi", juridico: "jur", as_social: "soc" }[V.perfil]);
    }
    function formAgendarHtml() {
        const P = V.perfil, refs = origensDoViewer();
        const pre = { juridico: { ref: "CJ-2026-000031", d: "2026-11-17", h: "14:00", dur: 60, obs: "Trazer documentos do processo e comprovante de residência." }, psicologia: { ref: "PSI-2026-000020", d: "2026-11-17", h: "14:00", dur: 50, obs: "" }, as_social: { ref: "SOC-2026-000010", d: "2026-11-18", h: "09:00", dur: 120, obs: "" } }[P];
        const defRef = refs.includes(pre.ref) ? pre.ref : refs[0];
        const tipos = { psicologia: [["sessao", "Sessão"], ["primeiro", "Primeiro atendimento"]], juridico: [["atendimento", "Atendimento"], ["retorno", "Retorno"], ["primeiro", "Primeiro atendimento"]], as_social: [["visita", "Visita domiciliar"], ["atendimento_soc", "Atendimento social (na unidade)"], ["visita_inst", "Visita institucional"]] }[P];
        return `<form id="formAg" class="ag-form" autocomplete="off">
            <div class="full"><label for="fRef">${P === "juridico" ? "Caso" : "Prontuário"}</label><select id="fRef" class="soft-input">${refs.map(r => `<option value="${r}" ${r === defRef ? "selected" : ""}>${esc(AG.identAssistida(AG.estado.origens[r].assistida))} · ${r}${AG.estado.origens[r].restrito ? " · acesso restrito" : ""}</option>`).join("")}</select></div>
            <div><label for="fTipo">Tipo</label><select id="fTipo" class="soft-input">${tipos.map(t => `<option value="${t[0]}">${t[1]}</option>`).join("")}</select></div>
            <div><label for="fDur">Duração (min)</label><input id="fDur" type="number" class="soft-input" value="${pre.dur}" min="10" step="5"><div class="ajuda">Sugestão inicial, ajustável.${P === "psicologia" ? " Intervalo de 10 min depois." : ""}</div></div>
            <div><label for="fData">Data</label><input id="fData" type="date" class="soft-input" value="${pre.d}"></div>
            <div><label for="fHora">Hora</label><input id="fHora" type="time" class="soft-input" value="${pre.h}" step="900"></div>
            ${P === "as_social" ? `<div><label for="fDesl">Deslocamento (min, ida e volta)</label><input id="fDesl" type="number" class="soft-input" value="30" min="0" step="5"></div><div></div>` : ""}
            <div class="full"><label class="linha-check"><input type="checkbox" id="fPres" ${P === "as_social" ? "" : "checked"}> Presencial na unidade</label>
                <label class="linha-check" style="margin-top:6px"><input type="checkbox" id="fRec"> Avisar a Recepção no dia (nome, código e horário, sem área nem motivo)</label><div class="ajuda" id="fRecAjuda"></div></div>
            <div class="full"><label for="fObs">Observação operacional</label><textarea id="fObs" class="soft-input" placeholder="Ex.: trazer documentos. Não escreva relato aqui.">${esc(pre.obs)}</textarea></div>
            <div class="full ag-acoes" style="justify-content:space-between"><button type="button" class="soft-btn soft-btn-secondary" id="btnDisp">🗓 Ver disponibilidade</button><button type="submit" class="soft-btn soft-btn-primary">Agendar</button></div>
            <div class="full ag-nota" id="fResultado" style="margin:0"></div>
        </form>`;
    }
    function ajustarAvisoRecepcao() {
        const ref = $("#fRef").value, o = AG.estado.origens[ref], rec = $("#fRec"), pres = $("#fPres");
        rec.disabled = !pres.checked;
        if (!pres.checked) rec.checked = false;
        $("#fRecAjuda").textContent = !pres.checked ? "Atendimento fora da unidade nunca aparece para a Recepção." : (o.restrito ? "Caso com acesso restrito: desligado por padrão. " : "Ligado por padrão para atendimentos presenciais. ") + (rec.checked ? "A Recepção verá nome, código e horário no dia." : "Desligado: a Recepção NÃO verá este atendimento.");
    }
    function lerForm() {
        const ref = $("#fRef").value, o = AG.estado.origens[ref];
        const ini = lerData($("#fData").value, $("#fHora").value), dur = +$("#fDur").value || 50;
        const desl = $("#fDesl") ? +$("#fDesl").value || 0 : 0;
        const tipoSel = $("#fTipo");
        return { ref, o, ini, fim: new Date(+ini + dur * 60000), dur, desl, tipo: tipoSel.value, tipoTxt: tipoSel.options[tipoSel.selectedIndex].text, pres: $("#fPres").checked, rec: $("#fRec").checked, obs: $("#fObs").value };
    }

    function renderTrabalho() {
        if ($("#esperadas")) {
            const lista = AG.todos().filter(it => AG.mesmoDia(it.ini, HOJE) && AG.revelar(it, V) === "recepcao").sort((a, b) => a.ini - b.ini);
            $("#esperadas").innerHTML = lista.length ? `<div style="display:flex;flex-direction:column;gap:8px">${lista.map(it => {
                const st = it.chegada.estado;
                const fl = `<div class="ag-fluxo"><span class="on">Esperada</span>›<span class="${st !== "esperada" ? "on" : ""}">Chegou${it.chegada.chegouEm ? " " + AG.hm(it.chegada.chegouEm) : ""}</span>›<span class="${st === "recebida" ? "on" : ""}">Recebida pela equipe${it.chegada.recebidaEm ? " " + AG.hm(it.chegada.recebidaEm) : ""}</span></div>`;
                const bt = st === "esperada" ? `<button type="button" class="soft-btn soft-btn-primary ag-btn-sm" data-chegou="${it.id}">Chegou</button>` : st === "chegou" ? `<span class="ag-tag" style="--bg:#FFF4D1;--cor:#6B4F17">aguardando a equipe</span>` : `<span class="ag-tag" style="--bg:#E1F3EC;--cor:#24805F">recebida</span>`;
                return `<div class="ag-esperada" data-esperada="${it.id}"><span class="h">${AG.hm(it.ini)}</span><div><div class="t">${esc(AG.identAssistida(it.assistida))}</div><div class="s">Atendimento com a equipe técnica</div>${fl}</div>${bt}</div>`;
            }).join("")}</div>` : `<div class="ag-vazio">Ninguém esperado hoje.</div>`;
        }
        if ($("#aulasProf")) {
            const minhas = AG.todos().filter(it => it.fonte === "curso" && it.dono === V.id && it.ini >= AG.somaDias(HOJE, -7) && it.ini < AG.somaDias(HOJE, 21));
            $("#aulasProf").innerHTML = `<ul class="ag-lista">${minhas.map(it => {
                const com = comunicacoesDaAula(it).length, passada = it.fim < D.AGORA;
                const casa = D.CASA.find(c => AG.mesmoDia(c.ini, it.ini) && c.tipo !== "evento");
                return `<li class="ag-linha k-aula ${it.cancelada ? "riscado" : ""}" style="cursor:default" data-aula="${it.id}"><span class="h">${AG.diaSemana(it.ini)} ${AG.dm(it.ini)}</span><span><span class="t">${esc(AG.curso(it.curso).nome)} · ${AG.hm(it.ini)}–${AG.hm(it.fim)}</span><span class="s" style="display:block">${it.cancelada ? "Cancelada: " + esc(it.cancelada.motivo) : (passada ? (it.chamada ? "Chamada feita" : "Chamada pendente") : "Prevista")}${com ? " · " + com + " comunicação(ões) de falta/atraso" : ""}${casa && !it.cancelada ? " · " + esc(casa.titulo) : ""}</span></span>
                    <span style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end">${it.cancelada ? "" : `<button type="button" class="soft-btn soft-btn-secondary ag-btn-sm" data-chamada="${it.id}">${passada ? (it.chamada ? "Ver chamada" : "Fazer chamada") : "Prévia da chamada"}</button>${passada ? "" : `<button type="button" class="soft-btn soft-btn-warning ag-btn-sm" data-cancaula="${it.id}">Cancelar…</button>`}`}</span></li>`;
            }).join("")}</ul>`;
        }
        if ($("#admCfg")) {
            const aus = AG.estado.itens.filter(i => i.tipo === "ausencia" && i.ausencia === "informada");
            $("#admCfg").innerHTML = `<dl class="ag-det">
                <dt>Limite de aviso</dt><dd>${D.CONFIG.limiteCompromissos} compromissos ou ${D.CONFIG.limiteHoras} h por dia (só o que ocupa horário). Configurado diferente: Ana Beatriz Lima = 4.</dd>
                <dt>Durações sugeridas</dt><dd>Sessão 50 min + 10 de intervalo · Atendimento jurídico 1 h · Visita 2 h + 30 min de deslocamento</dd>
                <dt>Expediente</dt><dd>08h–17h (cada pessoa pode ter o seu)</dd>
                <dt>Feriados</dt><dd>${D.CASA.filter(c => c.tipo === "feriado").map(c => `${AG.dm(c.ini)} ${esc(c.titulo.replace("Feriado: ", "").replace("Feriado nacional: ", ""))}${c.nota ? " (" + esc(c.nota.split(".")[0]) + ")" : ""}`).join("<br>")}<br><span class="ag-nota">Feriado sozinho não fecha a Casa: só avisa.</span></dd>
                <dt>Unidade fechada</dt><dd>${D.CASA.filter(c => c.fechada).map(c => `${AG.dm(c.ini)} ${esc(c.titulo)} ${AG.estado.reaberta[c.id] ? `<span class="ag-tag" style="--bg:#E1F3EC;--cor:#24805F">reaberta para todos</span>` : `<button type="button" class="soft-btn soft-btn-warning ag-btn-sm" data-reabrir="${c.id}">Reabrir a unidade para todos…</button>`}`).join("<br>")}<br><span class="ag-nota">Bloqueia agendamentos. Exceção para UM compromisso: a ADM autoriza na hora de salvar aquele compromisso (vale só para ele, o horário e as pessoas dele). Reabrir para todos é outra ação, explícita.</span>
                ${(() => { const ex = AG.estado.itens.filter(i => i.excecao); return ex.length ? `<div style="margin-top:6px"><b>Exceções autorizadas:</b><br>${ex.map(i => `${AG.dm(i.ini)} ${AG.hm(i.ini)}–${AG.hm(i.fim)} · ${esc(i.titulo)} · ${[i.dono].concat(i.participantes || []).map(x => esc(AG.pessoa(x).curto)).join(", ")} (${esc(i.excecao.motivo)})`).join("<br>")}</div>` : ""; })()}</dd>
                <dt>Ausências informadas</dt><dd>${aus.length ? aus.map(a => `${esc(AG.pessoa(a.dono).curto)}: ${AG.diaSemana(a.ini)} ${AG.dm(a.ini)} ${a.diaInteiro ? "dia inteiro" : AG.hcurto(a.ini) + "–" + AG.hcurto(a.fim)} (por ${esc(AG.pessoa(a.registradoPor).curto)})`).join("<br>") + `<br><span class="ag-nota">Confirme em Agenda › Pendências.</span>` : "Nenhuma aguardando confirmação."}</dd>
            </dl>
            <h3 style="color:#8B586F;font-size:1rem;margin:18px 0 6px">Passar responsabilidades (simulação)</h3>
            <p class="ag-nota" style="margin-top:0">No sistema isto fica em Funcionários. A sucessora recebe acesso ao caso e uma lista dos compromissos futuros para revisar; nada vai sozinho para a agenda dela, e os registros passados mantêm a autoria.</p>
            ${AG.estado.revisar.some(r => r.ref === "CJ-2026-000041") ? `<div class="ag-nota">✓ CJ-2026-000041 passado de Fernanda para Paula.</div>` : `<button type="button" class="soft-btn soft-btn-secondary ag-btn-sm" data-passar="CJ-2026-000041">Passar o caso CJ-2026-000041 (Maria Souza) da Fernanda para a Paula</button>`}
            <h3 style="color:#8B586F;font-size:1rem;margin:18px 0 6px">Histórico de ações (protótipo)</h3>
            <div class="ag-aud">${AG.estado.auditoria.length ? AG.estado.auditoria.slice(0, 8).map(esc).join("<br>") : "Nada registrado nesta demonstração ainda."}</div>`;
        }
    }

    function atualizar() {
        renderAgenda();
        renderTrabalho();
        if (UI.cal.aberto) renderCal();
        if (!$("#mini").classList.contains("hidden")) renderMini();
    }

    // ---------------- ligações da página ----------------
    function ligarPagina() {
        $("#verComo").addEventListener("change", e => { V = AG.pessoa(e.target.value); UI.aba = "hoje"; UI.cal.filtros = null; UI.cal.pessoas = new Set(); render(); });
        $("#demoSel").addEventListener("change", e => { if (e.target.value === "") return; iniciarDemo(+e.target.value); });
        $("#btnReiniciar").addEventListener("click", () => { AG.reiniciar(); render(); toast("Dados fictícios reiniciados."); });
        const dx = $("#demoX"); if (dx) dx.addEventListener("click", () => { UI.demo = null; $("#demoBox").remove(); $("#demoSel").value = ""; });
        if (!UI.ligado) { UI.ligado = true; document.body.addEventListener("click", cliqueGeral); }
        ligarMenu();
        const f = $("#formAg");
        if (f) {
            ["#fRef", "#fPres", "#fRec"].forEach(s => $(s).addEventListener("change", ajustarAvisoRecepcao));
            $("#fRec").checked = !AG.estado.origens[$("#fRef").value].restrito && $("#fPres").checked;
            $("#fRef").addEventListener("change", () => { $("#fRec").checked = !AG.estado.origens[$("#fRef").value].restrito && $("#fPres").checked; ajustarAvisoRecepcao(); });
            $("#fTipo").addEventListener("change", () => { const t = $("#fTipo").value; $("#fPres").checked = t !== "visita" && t !== "visita_inst"; if ($("#fDesl")) $("#fDesl").value = t === "atendimento_soc" ? 0 : 30; $("#fDur").value = t === "atendimento_soc" ? 50 : $("#fDur").value; ajustarAvisoRecepcao(); });
            ajustarAvisoRecepcao();
            $("#btnDisp").addEventListener("click", () => {
                const x = lerForm();
                abrirCal({ visao: "semana", data: x.ini, escolha: { pessoas: [V.id], assistida: x.o.assistida, dur: x.dur, desl: x.desl, rotulo: $(".soft-card-title", f.parentNode).textContent + " · " + AG.identAssistida(x.o.assistida), atual: x, aoEscolher: dt => { $("#fData").value = ymd(dt); $("#fHora").value = AG.hm(dt); toast(`Horário escolhido: ${AG.diaSemana(dt)} ${AG.dm(dt)} às ${AG.hm(dt)}. Confira e clique em Agendar.`); } } });
            });
            f.addEventListener("submit", e => { e.preventDefault(); agendarDoForm(); });
        }
    }

    function cliqueGeral(e) {
        const t = e.target;
        const toastBtn = t.closest("[data-toast]"); if (toastBtn) return toast(toastBtn.dataset.toast);
        const aba = t.closest("[data-aba]"); if (aba) { UI.aba = aba.dataset.aba; renderAgenda(); return; }
        if (t.closest("#btnNovo")) return abrirNovo({});
        if (t.closest("#btnComunic")) return abrirNovo({ tipo: "comunicacao" });
        const li = t.closest("[data-item]"); if (li && !t.closest(".ag-ov")) return abrirDetalhe(li.dataset.item);
        const pend = t.closest("[data-pend]"); if (pend) return acaoPendencia(pend.dataset.pend, pend.dataset.id);
        const ch = t.closest("[data-chegou]"); if (ch) return marcarChegada(item(ch.dataset.chegou));
        const cha = t.closest("[data-chamada]"); if (cha) return abrirChamada(cha.dataset.chamada);
        const ca = t.closest("[data-cancaula]"); if (ca) return abrirCancelarAula(ca.dataset.cancaula);
        const rb = t.closest("[data-reabrir]"); if (rb) return reabrirUnidade(rb.dataset.reabrir);
        const ps = t.closest("[data-passar]"); if (ps) { AG.passarResponsabilidade(ps.dataset.passar, "jur1", "jur2", V); toast("Caso passado. A Paula recebe a lista de compromissos futuros para revisar; a Fernanda perde o acesso aos detalhes."); return atualizar(); }
    }
    const item = id => AG.todos().find(i => i.id === id);
    function marcarChegada(it) {
        // Só um horário que a Recepção ainda vê como esperado (remarcado ou cancelado não recebe chegada)
        if (!it || AG.revelar(it, V) !== "recepcao" || !it.chegada || it.chegada.estado !== "esperada") { toast("Este horário não está mais na lista de esperadas."); return atualizar(); }
        it.chegada = { estado: "chegou", chegouEm: D.AGORA };
        AG.auditar(`${V.curto} (Recepção) marcou chegada de ${AG.identAssistida(it.assistida)}`);
        toast("Chegada registrada. A profissional responsável vê isso na Agenda dela."); atualizar();
    }

    // ---------------- menu do usuário + mini calendário ----------------
    function ligarMenu() {
        const card = $("#sessionCard"), btn = $("#btnCal"), mini = $("#mini"), item = $("#calItem");
        const abrirMini = fixo => { mini.classList.remove("hidden"); btn.setAttribute("aria-expanded", "true"); if (fixo) { UI.mini.fixo = true; card.classList.add("open"); } renderMini(); };
        const fecharMini = () => { mini.classList.add("hidden"); btn.setAttribute("aria-expanded", "false"); UI.mini.fixo = false; card.classList.remove("open"); };
        UI.fecharMini = fecharMini;
        item.addEventListener("mouseenter", () => { clearTimeout(UI.mini.timer); UI.mini.timer = setTimeout(() => abrirMini(false), 300); });
        item.addEventListener("mouseleave", () => { clearTimeout(UI.mini.timer); if (!UI.mini.fixo) UI.mini.timer = setTimeout(() => mini.classList.add("hidden"), 250); });
        btn.addEventListener("click", () => { if (window.matchMedia("(max-width: 720px)").matches) { abrirCal({ visao: "dia", data: HOJE }); return; } if (mini.classList.contains("hidden") || !UI.mini.fixo) { abrirMini(true); const f = $(".ag-mini-dia.hoje", mini); if (f) f.focus(); } else fecharMini(); });
        $("#sessionTrigger").addEventListener("click", () => card.classList.toggle("open"));
        if (!UI.menuLigado) { UI.menuLigado = true; document.addEventListener("mousedown", e => { const c = $("#sessionCard"); if (c && !c.contains(e.target) && !e.target.closest(".ag-ov") && !e.target.closest(".ag-modal")) { UI.fecharMini(); c.classList.remove("open"); } }); }
        card.addEventListener("keydown", e => { if (e.key === "Escape") { fecharMini(); card.classList.remove("open"); btn.focus(); } });
        mini.addEventListener("click", e => {
            const nav = e.target.closest("[data-mes]");
            if (nav) { UI.mini.ref = new Date(UI.mini.ref.getFullYear(), UI.mini.ref.getMonth() + (+nav.dataset.mes), 1); renderMini(); return; }
            const dia = e.target.closest("[data-dia]");
            if (dia) { abrirCal({ visao: "dia", data: lerData(dia.dataset.dia) }); return; }
            if (e.target.closest("#miniAbrir")) abrirCal({ visao: "semana", data: HOJE });
        });
        mini.addEventListener("mouseover", e => { const dia = e.target.closest("[data-dia]"); if (dia) dica(dia.dataset.dia); });
        mini.addEventListener("focusin", e => { const dia = e.target.closest("[data-dia]"); if (dia) dica(dia.dataset.dia); });
        mini.addEventListener("keydown", e => {
            const dia = e.target.closest("[data-dia]"); if (!dia) return;
            const passo = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 }[e.key];
            if (!passo) return;
            e.preventDefault();
            const nd = AG.somaDias(lerData(dia.dataset.dia), passo);
            if (nd.getMonth() !== UI.mini.ref.getMonth()) { UI.mini.ref = new Date(nd.getFullYear(), nd.getMonth(), 1); renderMini(); }
            const alvo = $(`[data-dia="${ymd(nd)}"]`, mini); if (alvo) alvo.focus();
        });
    }
    function itensDoDiaMini(dt) {
        return AG.visiveis(V, dt, AG.somaDias(dt, 1), new Set(AG.filtrosPadrao(V)));
    }
    function renderMini() {
        const mini = $("#mini"), ref = UI.mini.ref;
        const primeiro = new Date(ref.getFullYear(), ref.getMonth(), 1);
        const ini = AG.somaDias(primeiro, -((primeiro.getDay() + 6) % 7));
        let cel = ["seg", "ter", "qua", "qui", "sex", "sáb", "dom"].map(s => `<div class="sem">${s}</div>`).join("");
        for (let i = 0; i < 42; i++) {
            const dt = AG.somaDias(ini, i);
            const its = itensDoDiaMini(dt);
            const casa = D.CASA.find(c => AG.mesmoDia(c.ini, dt) && c.tipo !== "evento");
            const cores = [];
            its.forEach(x => { const k = classe(x.it, x.nivel); if (!cores.includes(k)) cores.push(k); });
            const pts = cores.slice(0, 3).map(k => `<i class="pt ${k}"></i>`).join("") + (its.length > 3 ? `<span class="mais">+${its.length - 3}</span>` : "");
            cel += `<button type="button" class="ag-mini-dia ${dt.getMonth() !== ref.getMonth() ? "fora" : ""} ${AG.mesmoDia(dt, HOJE) ? "hoje" : ""} ${casa ? (casa.fechada ? "fec" : "fer") : ""}" data-dia="${ymd(dt)}" tabindex="${AG.mesmoDia(dt, HOJE) ? 0 : -1}" aria-label="${AG.diaLongo(dt)} ${AG.dm(dt)}: ${its.length} item(ns)">${dt.getDate()}<span class="pts">${pts}</span></button>`;
        }
        mini.innerHTML = `<div class="ag-mini-top"><button type="button" data-mes="-1" aria-label="Mês anterior">‹</button><span>${AG.MESES[ref.getMonth()]} ${ref.getFullYear()}</span><button type="button" data-mes="1" aria-label="Próximo mês">›</button></div>
            <div class="ag-mini-grade">${cel}</div><div class="ag-mini-dica" id="miniDica" aria-live="polite">Toque, passe o mouse ou use as setas num dia para ver o que tem nele.</div>
            <div class="ag-mini-rodape"><span>Clique num dia para abrir</span><button type="button" class="soft-btn soft-btn-primary ag-btn-sm" id="miniAbrir">Abrir completo</button></div>`;
    }
    function dica(diaStr) {
        const dt = lerData(diaStr), its = itensDoDiaMini(dt);
        const linhas = its.slice(0, 6).map(x => { const tx = textos(x.it, x.nivel); return `<li class="${classe(x.it, x.nivel)}"><i></i><span><b>${horaTxt(x.it)}</b> ${esc(tx.t)}</span></li>`; }).join("");
        const cnt = V.perfil === "adm" ? (() => { const c = AG.contagens(V, dt); const n = c.jur + c.psi + c.soc; return n ? `<li class="k-neu"><i></i><span>${n} atendimento(s) técnico(s) (só números)</span></li>` : ""; })() : "";
        $("#miniDica").innerHTML = `<b>${AG.diaLongo(dt)}, ${AG.dm(dt)}</b>${linhas || cnt ? `<ul>${cnt}${linhas}</ul>` : "<div>Nada neste dia.</div>"}${its.length > 6 ? `<div>…e mais ${its.length - 6}. Clique para ver tudo.</div>` : ""}`;
    }

    // ---------------- Calendário completo (sobreposição) ----------------
    let ov = null, fechandoPorVoltar = false;
    function abrirCal(o) {
        if (!ov || !document.body.contains(ov)) {
            ov = document.createElement("div");
            ov.className = "ag-ov hidden";
            ov.setAttribute("role", "dialog"); ov.setAttribute("aria-modal", "true"); ov.setAttribute("aria-label", "Calendário");
            document.body.appendChild(ov);
            ov.addEventListener("mousedown", e => { if (e.target === ov) fecharCal(); });
            ov.addEventListener("click", cliqueCal);
            ov.addEventListener("change", e => {
                const f = e.target.closest("[data-filtro]"); if (f) { f.checked ? UI.cal.filtros.add(f.dataset.filtro) : UI.cal.filtros.delete(f.dataset.filtro); renderCal(); }
                const p = e.target.closest("[data-pessoa]"); if (p) { p.checked ? UI.cal.pessoas.add(p.dataset.pessoa) : UI.cal.pessoas.delete(p.dataset.pessoa); renderCal(); }
                const l = e.target.closest("[data-lista]"); if (l && l.value) { UI.cal.lista[l.dataset.lista] = lerData(l.value); renderCal(); }
            });
        }
        if (!UI.cal.aberto) UI.cal.opener = document.activeElement;
        if (!UI.cal.filtros) UI.cal.filtros = new Set(AG.filtrosPadrao(V));
        UI.cal.visao = o.visao || "semana";
        UI.cal.ref = AG.inicioDia(o.data || HOJE);
        if (o.acimaDeModal) {
            // aberto por cima de um formulário: ao escolher ou fechar, volta ao formulário (e ao calendário, se ele já estava aberto)
            UI.cal.acima = true;
            UI.cal.anterior = UI.cal.aberto ? { visao: UI.cal.visao, ref: UI.cal.ref, escolha: UI.cal.escolha } : null;
            if (UI.cal.aberto) history.pushState({ calendario: true, escolhaSobre: true }, "", "#calendario");
            UI.cal.visao = o.visao || "semana"; UI.cal.ref = AG.inicioDia(o.data || HOJE);
        }
        UI.cal.escolha = o.escolha || null;
        ov.style.zIndex = o.acimaDeModal ? 1600 : "";
        if (!UI.cal.aberto) { history.pushState({ calendario: true }, "", "#calendario"); }
        UI.cal.aberto = true;
        if (UI.fecharMini) UI.fecharMini();
        $("#sessionCard").classList.remove("open");
        ov.classList.remove("hidden");
        renderCal();
        $(".ag-ov-x", ov).focus();
    }
    function fecharCal() {
        if (UI.ignorarVoltar) { UI.ignorarVoltar = false; return; }
        if (!UI.cal.aberto) return;
        if (UI.cal.acima) {
            const ant = UI.cal.anterior;
            UI.cal.acima = false; UI.cal.anterior = null; ov.style.zIndex = "";
            if (ant) {
                Object.assign(UI.cal, ant);
                if (!fechandoPorVoltar && history.state && history.state.escolhaSobre) { UI.ignorarVoltar = true; history.back(); }
                renderCal();
                const mm = $$(".ag-modal").pop(); if (mm) { const f0 = mm.querySelector("input, select"); if (f0) f0.focus(); }
                return;
            }
        }
        UI.cal.aberto = false;
        ov.classList.add("hidden");
        if (!fechandoPorVoltar && history.state && history.state.calendario) history.back();
        const o = UI.cal.opener;
        if (o && document.contains(o) && o.focus) o.focus();
    }
    UI.fecharCal = fecharCal;
    function periodoTxt() {
        const r = UI.cal.ref;
        if (UI.cal.visao === "dia") return `${AG.diaLongo(r)}, ${AG.dm(r)}/${r.getFullYear()}`;
        if (UI.cal.visao === "semana") { const s = inicioSemana(r), f = AG.somaDias(s, 6); return `${AG.dm(s)} a ${AG.dm(f)}/${f.getFullYear()}`; }
        if (UI.cal.visao === "mes") return `${AG.MESES[r.getMonth()]} ${r.getFullYear()}`;
        return "Lista";
    }
    const inicioSemana = dt => AG.somaDias(AG.inicioDia(dt), -((dt.getDay() + 6) % 7));
    function renderCal() {
        const C = UI.cal, esc0 = C.escolha;
        const visoes = esc0 ? [["dia", "Dia"], ["semana", "Semana"]] : [["dia", "Dia"], ["semana", "Semana"], ["mes", "Mês"], ["lista", "Lista"]];
        const disp = AG.filtrosDisponiveis(V);
        const leg = [["k-psi", "Psicologia"], ["k-jur", "Jurídico"], ["k-soc", "Serviço Social"], ["k-aula", "Aulas e comunicações"], ["k-man", "Compromissos e lembretes"], ["k-aus", "Ausências (tracejado = informada)"], ["k-equipe", "Esperada na unidade (Recepção)"], ["k-neu", "Indisponível / sem acesso / só número (cinza igual para todas as áreas)"], ["k-fer", "Feriado"], ["k-fec", "Unidade fechada"]];
        ov.innerHTML = `<div class="ag-ov-painel">
            <div class="ag-ov-top">
                <h2>Calendário</h2>
                <button type="button" class="ag-nav" data-nav="-1" aria-label="Anterior">‹</button><button type="button" class="ag-nav" data-nav="0">Hoje</button><button type="button" class="ag-nav" data-nav="1" aria-label="Próximo">›</button>
                <span class="per">${periodoTxt()}</span>
                <span class="ag-seg">${visoes.map(v => `<button type="button" data-visao="${v[0]}" class="${C.visao === v[0] ? "on" : ""}">${v[1]}</button>`).join("")}</span>
                ${esc0 ? "" : `<button type="button" class="soft-btn soft-btn-primary ag-btn-sm" data-novo-cal>+ Novo compromisso</button>`}
                <button type="button" class="ag-ov-x" aria-label="Fechar calendário e voltar para onde eu estava" title="Fechar (Esc)">×</button>
            </div>
            ${esc0 ? `<div class="ag-escolha-faixa"><b>Escolhendo horário para:</b> ${esc(esc0.rotulo)} (${esc0.dur} min${esc0.desl ? " + " + esc0.desl + " min de deslocamento" : ""}). Clique num horário livre para preencher o formulário. Cinza = indisponível (o motivo só aparece se você puder vê-lo). Amarelo = ausência só informada: o horário pode ser escolhido, com aviso.</div>` : ""}
            <div class="ag-ov-corpo">
                <aside class="ag-ov-lado">
                    ${esc0 ? `<h4>Agendas consideradas</h4><div>${esc0.pessoas.map(pid => pid === V.id ? "Você" : esc(AG.pessoa(pid).curto)).join(", ")}${esc0.assistida ? " e a assistida <b>" + esc(AG.identAssistida(esc0.assistida)) + "</b>" : ""}.</div><p class="ag-nota">Só aparecem as pessoas deste agendamento: consultar a disponibilidade de alguém exige um agendamento com ela.</p><p class="ag-nota">A conferência usa também o que você não pode ver: oculto não quer dizer livre.</p>` : `
                    <h4>Mostrar</h4>${disp.map(f => `<label><input type="checkbox" data-filtro="${f}" ${C.filtros.has(f) ? "checked" : ""}> ${AG.FILTROS[f]}</label>`).join("")}
                    <h4>Pessoas (lado a lado no Dia)</h4>${D.PESSOAS.filter(p => p.id !== V.id).map(p => `<label><input type="checkbox" data-pessoa="${p.id}" ${C.pessoas.has(p.id) ? "checked" : ""}> ${esc(p.curto)} <span style="color:#B79AAA;font-size:.75rem">(${esc(p.area)})</span></label>`).join("")}
                    <p class="ag-nota">Aqui aparece só o que você já pode ver dessas pessoas (avisos, reuniões, casos da sua área). Atendimentos técnicos não aparecem nem como “Ocupado”: a disponibilidade de uma colega só é consultada ao agendar algo com ela (“Ver disponibilidade”).</p><p class="ag-nota">Avisos de colegas (ausências, atrasos) ficam na faixa de cima, separados da sua agenda.</p>`}
                    <h4>Legenda</h4><div class="leg">${leg.map(l => `<i class="${l[0]}"></i><span>${l[1]}</span>`).join("")}</div>
                </aside>
                <div class="ag-ov-area" id="calArea">${C.visao === "mes" ? mesHtml() : C.visao === "lista" ? listaHtml() : gradeHtml()}</div>
            </div>
            <div class="ag-ov-rodape"><span>Fechar com ×, Esc ou Voltar do navegador mantém a tela de baixo exatamente como estava.</span><span>Sessão expirada ou navegador fechado perdem o que não foi salvo.</span><span>Os lembretes aparecem enquanto o sistema estiver aberto.</span></div>
        </div>`;
        const area = $("#calArea", ov);
        if (C.visao === "semana" || C.visao === "dia") area.scrollTop = 44 * 1;
    }
    const H0 = 7, H1 = 20, PX = 44;
    const topo = dt => ((dt.getHours() + dt.getMinutes() / 60) - H0) * PX;
    function lanes(evs) {
        evs.sort((a, b) => a.ini - b.ini);
        let grupo = [], fimG = 0;
        const fechar = () => { const fins = []; grupo.forEach(e => { let i = fins.findIndex(f => f <= e.ini); if (i < 0) { i = fins.length; fins.push(0); } fins[i] = e.fim; e.lane = i; }); grupo.forEach(e => e.nl = fins.length); grupo = []; fimG = 0; };
        evs.forEach(e => { if (grupo.length && e.ini >= fimG) fechar(); grupo.push(e); fimG = Math.max(fimG, +e.fim); });
        if (grupo.length) fechar();
        return evs;
    }
    function evHtml(x, extra) {
        const { it, nivel } = x, tx = textos(it, nivel);
        const j = AG.janela(it);
        const t0 = Math.max(topo(it.ini), 0), h = Math.max(topo(it.fim) - topo(it.ini), 20);
        const riscado = it.cancelada || it.situacao === "cancelado" || it.ausencia === "recusada";
        const desloc = it.deslocamento && nivel === "detalhe" ? `<div class="ag-faixa" style="top:${topo(j.ini)}px;height:${topo(it.ini) - topo(j.ini)}px;left:${x.lane / x.nl * 100}%;width:calc(${100 / x.nl}% - 4px);opacity:.7">desloc.</div><div class="ag-faixa" style="top:${topo(it.fim)}px;height:${topo(j.fim) - topo(it.fim)}px;left:${x.lane / x.nl * 100}%;width:calc(${100 / x.nl}% - 4px);opacity:.7">desloc.</div>` : "";
        // Altura define quantas linhas cabem: nada fica cortado no meio (o resto aparece ao passar o mouse e no detalhe).
        const linhas = h < 32 ? 1 : h < 58 ? 2 : 3;
        const conteudo = linhas === 1 ? `<span class="l1"><b>${AG.hm(it.ini)}</b> ${esc(tx.t)}${extra || ""}</span>`
            : linhas === 2 ? `<span class="l1"><b>${AG.hm(it.ini)}</b> ${esc(tx.t)}${extra || ""}</span><span class="l2">${esc(tx.c || "")}</span>`
            : `<span class="l1"><b>${AG.hm(it.ini)}–${AG.hm(it.fim)}</b>${extra || ""}</span><span class="l1">${esc(tx.t)}</span><span class="l2">${esc(tx.c || "")}</span>`;
        return desloc + `<button type="button" class="ag-ev ${classe(it, nivel)} ${riscado ? "riscado" : ""} ${it.ausencia === "informada" ? "informada" : ""}" style="top:${t0}px;height:${h - 2}px;left:calc(${x.lane / x.nl * 100}% + 2px);width:calc(${100 / x.nl}% - 4px)" data-item="${it.id}" data-nivel="${nivel}" title="${esc(tx.t + (tx.c ? " · " + tx.c : "") + " — " + tx.s)}">${conteudo}</button>`;
    }
    function chipHtml(x) {
        const tx = textos(x.it, x.nivel);
        const aviso = equipeAlheio(x);
        const hora = x.it.diaInteiro ? "" : AG.hm(x.it.ini) + (aviso && x.it.fim ? "–" + AG.hm(x.it.fim) : "") + " ";
        return `<button type="button" class="ag-chip ${classe(x.it, x.nivel)} ${x.it.cancelada ? "riscado" : ""}" data-item="${x.it.id}" data-nivel="${x.nivel}" title="${esc(tx.t + " — " + tx.s)}">${aviso ? "Aviso · " + esc(AG.pessoa(x.it.dono).curto) + " " : ""}${hora}${esc(tx.t)}</button>`;
    }
    function gradeHtml() {
        const C = UI.cal, E = C.escolha;
        let dias, colunas;
        if (C.visao === "dia") {
            dias = [C.ref];
            colunas = [{ dia: C.ref, pessoa: V.id, nome: "Você" }].concat(E ? [] : Array.from(C.pessoas).map(pid => ({ dia: C.ref, pessoa: pid, nome: AG.pessoa(pid).curto })));
        } else {
            const s = inicioSemana(C.ref);
            dias = [0, 1, 2, 3, 4, 5, 6].map(i => AG.somaDias(s, i));
            colunas = dias.map(dt => ({ dia: dt, pessoa: null }));
        }
        const larg = colunas.map(c => C.visao === "semana" && [0, 6].includes(c.dia.getDay()) ? "0.55fr" : "1fr").join(" ");
        let cab = `<div class="cab"></div>`, todo = `<div class="todo" style="font-size:.68rem;color:#B79AAA;justify-content:center">dia todo</div>`, cols = "";
        colunas.forEach(c => {
            const dt = c.dia, hoje = AG.mesmoDia(dt, HOJE);
            const casa = D.CASA.find(x => AG.mesmoDia(x.ini, dt) && x.fechada && !AG.estado.reaberta[x.id]);
            cab += `<div class="cab ${hoje && !c.pessoa ? "hoje" : ""}">${c.pessoa ? esc(c.nome) : AG.dm(dt)}<small>${c.pessoa ? AG.diaSemana(dt) + " " + AG.dm(dt) : AG.diaSemana(dt)}</small></div>`;
            let todos = [], timed = [];
            if (E) {
                const fx = AG.faixas(V, E.pessoas, E.assistida, dt);
                D.CASA.filter(x => AG.mesmoDia(x.ini, dt)).forEach(x => todos.push({ it: Object.assign({ fonte: "casa" }, x), nivel: "detalhe" }));
                const lim = v => Math.min(Math.max(v, 0), (H1 - H0) * PX);
                let html = fx.map(f => `<div class="ag-faixa ${f.aviso ? "inf" : f.revelado ? "rev " + classe(f.it, f.it.fonte === "curso" ? "curso" : f.n) : ""}" style="top:${lim(topo(f.ini))}px;height:${Math.max(lim(topo(f.fim)) - lim(topo(f.ini)), 16)}px">${f.it.diaInteiro ? "Dia inteiro" : AG.hm(f.ini)} ${esc(f.rot)}${E.pessoas.length > 1 && f.it.dono !== V.id ? " · " + esc(AG.pessoa(f.it.dono).curto) : ""}</div>`).join("");
                if (!casa && ![0, 6].includes(dt.getDay())) {
                    for (let m = 8 * 60; m + E.dur <= 17 * 60; m += 30) {
                        const ini = new Date(dt.getFullYear(), dt.getMonth(), dt.getDate(), Math.floor(m / 60), m % 60);
                        const jan = { ini: new Date(+ini - E.desl * 60000), fim: new Date(+ini + (E.dur + E.desl) * 60000) };
                        if (ini < D.AGORA) continue;
                        if (fx.some(f => !f.aviso && f.ini < jan.fim && jan.ini < f.fim)) continue;
                        const comAviso = fx.some(f => f.aviso && f.ini < jan.fim && jan.ini < f.fim);
                        html += `<div class="ag-livre ${comAviso ? "aviso" : ""}" tabindex="0" role="button" data-livre="${ini.toISOString()}" data-h="${AG.hm(ini)} livre${comAviso ? " · com aviso" : ""}" style="top:${topo(ini) + 1}px;height:${Math.min(E.dur, 30) / 60 * PX - 2}px" aria-label="Escolher ${AG.diaSemana(ini)} ${AG.dm(ini)} às ${AG.hm(ini)}"></div>`;
                    }
                }
                if (E.atual && AG.mesmoDia(E.atual.ini, dt)) html += `<div class="ag-faixa novo" style="top:${topo(E.atual.ini)}px;height:${Math.max(topo(E.atual.fim) - topo(E.atual.ini), 16)}px;left:40%">horário no formulário</div>`;
                todo += `<div class="todo">${todos.map(chipHtml).join("")}</div>`;
                cols += `<div class="col ${casa ? "fec" : ""}" style="height:${(H1 - H0) * PX}px">${foraExp()}${html}${linhaAgora(dt)}</div>`;
                return;
            }
            let xs;
            if (!c.pessoa || c.pessoa === V.id) xs = AG.visiveis(V, AG.inicioDia(dt), AG.somaDias(AG.inicioDia(dt), 1), C.filtros, C.visao === "dia" ? new Set() : C.pessoas).filter(x => x.nivel !== "contagem");
            else xs = AG.todos().filter(it => AG.mesmoDia(it.ini, dt) && it.fonte !== "casa" && AG.envolve(it, c.pessoa) && AG.revelar(it, V) === "detalhe").map(it => ({ it, nivel: "detalhe", g: it.tipo === "ausencia" ? "equipe" : "meus" }));
            xs.forEach(x => { if (x.it.diaInteiro || !x.it.fim || (equipeAlheio(x) && !c.pessoa) || (equipeAlheio(x) && c.pessoa === V.id)) todos.push(x); else timed.push({ it: x.it, nivel: x.nivel, g: x.g, ini: AG.janela(x.it).ini, fim: AG.janela(x.it).fim }); });
            if (V.perfil === "adm" && C.filtros.has("contagem") && !c.pessoa) { const k = AG.contagens(V, dt), n = k.jur + k.psi + k.soc; if (n) todo += ""; if (n) todos.unshift({ it: { id: "cnt", diaInteiro: true, titulo: `${n} atendimento(s) técnico(s)`, fonte: "casa", tipo: "x" }, nivel: "contagem", cnt: `J ${k.jur} · P ${k.psi} · S ${k.soc}` }); }
            lanes(timed);
            todo += `<div class="todo">${todos.map(x => x.cnt ? `<span class="ag-chip k-neu" title="Só números">${x.it.titulo}: ${x.cnt}</span>` : chipHtml(x)).join("")}</div>`;
            cols += `<div class="col ${casa ? "fec" : ""}" style="height:${(H1 - H0) * PX}px">${foraExp()}${timed.map(x => evHtml(x, x.it.dono !== V.id && !AG.envolve(x.it, V.id) && C.visao === "semana" ? " · " + AG.pessoa(x.it.dono).curto : "")).join("")}${linhaAgora(dt)}</div>`;
        });
        let horas = `<div class="horas" style="height:${(H1 - H0) * PX}px">`;
        for (let h = H0; h < H1; h++) horas += `<div class="hl" style="top:${(h - H0) * PX}px">${h}h</div>`;
        horas += "</div>";
        return `<div class="ag-grade" style="grid-template-columns:52px ${larg};min-width:${C.visao === "semana" ? 720 : colunas.length > 1 ? colunas.length * 200 : 0}px">${cab}${todo}${horas}${cols}</div>`;
    }
    const foraExp = () => `<div class="fora" style="top:0;height:${(8 - H0) * PX}px"></div><div class="fora" style="top:${(17 - H0) * PX}px;height:${(H1 - 17) * PX}px"></div>`;
    const linhaAgora = dt => AG.mesmoDia(dt, HOJE) ? `<div class="ag-agora" style="top:${topo(D.AGORA)}px"></div>` : "";
    function mesHtml() {
        const r = UI.cal.ref, primeiro = new Date(r.getFullYear(), r.getMonth(), 1);
        const ini = AG.somaDias(primeiro, -((primeiro.getDay() + 6) % 7));
        let h = ["seg", "ter", "qua", "qui", "sex", "sáb", "dom"].map(s => `<div class="sem">${s}</div>`).join("");
        for (let i = 0; i < 42; i++) {
            const dt = AG.somaDias(ini, i);
            const xs = AG.visiveis(V, dt, AG.somaDias(dt, 1), UI.cal.filtros, UI.cal.pessoas).filter(x => x.nivel !== "contagem");
            const casa = D.CASA.find(c => AG.mesmoDia(c.ini, dt) && c.tipo !== "evento");
            let extra = "";
            if (V.perfil === "adm" && UI.cal.filtros.has("contagem")) { const k = AG.contagens(V, dt), n = k.jur + k.psi + k.soc; if (n) extra = `<span class="ag-chip k-neu">${n} atend. técnicos</span>`; }
            h += `<div class="d ${dt.getMonth() !== r.getMonth() ? "fora" : ""} ${AG.mesmoDia(dt, HOJE) ? "hoje" : ""} ${casa ? (casa.fechada ? "fec" : "fer") : ""}"><span class="n" data-irdia="${ymd(dt)}">${dt.getDate()}</span>${extra}${xs.slice(0, 4).map(chipHtml).join("")}${xs.length > 4 ? `<span class="ag-chip" data-irdia="${ymd(dt)}" style="--bg:#fff;--cor:#8F7181">+${xs.length - 4} mais</span>` : ""}</div>`;
        }
        return `<div class="ag-mes">${h}</div>`;
    }
    function listaHtml() {
        const L = UI.cal.lista;
        const xs = AG.visiveis(V, L.de, L.ate, UI.cal.filtros, UI.cal.pessoas).filter(x => x.nivel !== "contagem");
        const por = {};
        xs.forEach(x => { const k = ymd(x.it.ini); (por[k] = por[k] || []).push(x); });
        return `<div class="ag-lv"><div class="ag-form" style="max-width:420px"><div><label>De</label><input type="date" class="soft-input" data-lista="de" value="${ymd(L.de)}"></div><div><label>Até</label><input type="date" class="soft-input" data-lista="ate" value="${ymd(L.ate)}"></div></div>
            <p class="ag-nota">A lista abre nos últimos 90 dias e nos próximos 30. Datas anteriores: mude o “De”. O tempo de exibição não define quando os registros são apagados.</p>
            ${Object.keys(por).sort().map(k => { const dt = lerData(k); return `<h3>${AG.diaLongo(dt)}, ${AG.dm(dt)}</h3><ul class="ag-lista">${por[k].map(linhaHtml).join("")}</ul>`; }).join("") || `<div class="ag-vazio">Nada no período.</div>`}</div>`;
    }
    function cliqueCal(e) {
        const t = e.target, C = UI.cal;
        if (t.closest(".ag-ov-x")) return fecharCal();
        const nav = t.closest("[data-nav]");
        if (nav) { const n = +nav.dataset.nav; if (!n) C.ref = HOJE; else C.ref = C.visao === "mes" ? new Date(C.ref.getFullYear(), C.ref.getMonth() + n, 1) : AG.somaDias(C.ref, n * (C.visao === "dia" ? 1 : 7)); return renderCal(); }
        const vis = t.closest("[data-visao]"); if (vis) { C.visao = vis.dataset.visao; return renderCal(); }
        const ir = t.closest("[data-irdia]"); if (ir) { C.ref = lerData(ir.dataset.irdia); C.visao = "dia"; return renderCal(); }
        if (t.closest("[data-novo-cal]")) return abrirNovo({ data: C.ref });
        const livre = t.closest("[data-livre]"); if (livre) { const dt = new Date(livre.dataset.livre); const cb = C.escolha.aoEscolher; fecharCal(); cb(dt); return; }
        const ev = t.closest("[data-item]"); if (ev) return abrirDetalhe(ev.dataset.item, ev.dataset.nivel);
    }
    document.addEventListener("keydown", e => { if (e.key === "Escape" && UI.cal.aberto && (UI.cal.acima || !document.querySelector(".ag-modal"))) fecharCal(); });
    window.addEventListener("popstate", () => {
        if (UI.ignorarVoltar) { UI.ignorarVoltar = false; return; }
        if (!UI.cal.aberto) return;
        if (UI.cal.acima) { fechandoPorVoltar = true; fecharCal(); fechandoPorVoltar = false; return; }
        const mods = $$(".ag-modal").filter(m => m.tentarFechar);
        if (mods.length) {
            // Voltar com uma edição aberta: mesmo tratamento do X e do Esc (pergunta antes de descartar)
            history.pushState({ calendario: true }, "", "#calendario");
            mods[mods.length - 1].tentarFechar(); // igual ao X e ao Esc: fecha só a edição; o calendário continua aberto
            return;
        }
        fechandoPorVoltar = true; fecharCal(); fechandoPorVoltar = false;
    });
    document.addEventListener("keydown", e => { if ((e.key === "Enter" || e.key === " ") && e.target.matches && e.target.matches("[data-livre]")) { e.preventDefault(); e.target.click(); } });

    // ---------------- detalhe de um item ----------------
    function abrirDetalhe(id, nivelForcado) {
        const it = item(id); if (!it) return;
        let nivel = AG.revelar(it, V);
        if (nivel === "oculto" || nivel === "contagem") { toast("Este compromisso não está disponível para você."); return; }
        if (nivelForcado === "ocupado" && nivel === "detalhe" && it.dono !== V.id) nivel = "detalhe";
        const tx = textos(it, nivel);
        const linhas = [];
        const quando = it.diaInteiro ? `${AG.diaLongo(it.ini)}, ${AG.dm(it.ini)} (dia todo)` : `${AG.diaLongo(it.ini)}, ${AG.dm(it.ini)}, ${AG.hm(it.ini)}${it.fim ? "–" + AG.hm(it.fim) : ""}`;
        let acoes = "", nota = "";
        if (nivel === "ocupado") {
            linhas.push(["Quando", quando], ["Agenda de", AG.pessoa(it.dono).nome], ["O quê", "Indisponível"]);
            nota = "Você não tem permissão para ver os detalhes. O horário continua contando na conferência de conflitos.";
        } else if (nivel === "semacesso") {
            linhas.push(["Quando", quando], ["O quê", "Compromisso de um caso que você não acessa mais"]);
            nota = "Você criou ou participa deste compromisso, mas não tem mais permissão no caso/prontuário de origem. Por isso não aparecem assistida, título nem observação. O horário continua na sua agenda; se precisar, fale com quem é responsável agora.";
        } else if (nivel === "recepcao") {
            linhas.push(["Quando", quando], ["Assistida", AG.identAssistida(it.assistida)], ["O quê", "Atendimento com a equipe técnica"], ["Situação", textoChegada(it.chegada, true)]);
            if (it.chegada && it.chegada.estado === "esperada") acoes += `<button type="button" class="soft-btn soft-btn-primary" data-acao="chegou">Chegou</button>`;
            nota = "A Recepção não vê com qual área é o atendimento, nem o motivo.";
        } else if (nivel === "curso") {
            const c = AG.curso(it.curso);
            linhas.push(["Quando", quando], ["Turma", c.nome], ["Professora", AG.pessoa(c.prof).nome], ["Sala", c.local]);
            if (it.cancelada) linhas.push(["Situação", "Cancelada: " + it.cancelada.motivo]);
            nota = "Aula de outra turma: só dia, horário, sala e professora. Lista de alunas e observações não aparecem.";
        } else {
            linhas.push(["Quando", quando]);
            if (it.fonte === "curso") {
                const c = AG.curso(it.curso), com = comunicacoesDaAula(it);
                linhas.push(["Turma", c.nome], ["Sala", c.local], ["Alunas", c.alunas.length + ""], ["Chamada", it.cancelada ? "não se aplica (aula cancelada)" : it.chamada ? "feita" : it.fim < D.AGORA ? "pendente" : "ainda não é o dia"]);
                if (com.length) linhas.push(["Comunicações", com.map(x => `${AG.identAssistida(x.assistida)}: ${x.titulo.toLowerCase()} (registrado por ${AG.pessoa(x.registradoPor).curto})`).join("<br>")]);
                if (it.cancelada) linhas.push(["Situação", "Cancelada: " + esc(it.cancelada.motivo)]);
                if (it.dono === V.id || V.perfil === "adm") {
                    if (!it.cancelada) acoes += `<button type="button" class="soft-btn soft-btn-secondary" data-acao="chamada">${it.fim < D.AGORA ? "Fazer chamada" : "Prévia da chamada"}</button><button type="button" class="soft-btn soft-btn-warning" data-acao="cancelarAula">Cancelar aula…</button>`;
                    else acoes += `<button type="button" class="soft-btn soft-btn-secondary" data-acao="desfazerAula">Desfazer cancelamento</button>`;
                }
            } else if (it.fonte === "casa") {
                linhas.push(["O quê", it.titulo]); if (it.nota) linhas.push(["Observação", it.nota]);
            } else {
                linhas.push(["O quê", it.titulo]);
                linhas.push(["Responsável", AG.pessoa(it.dono).nome]);
                if (it.registradoPor && it.registradoPor !== it.dono) linhas.push(["Registrado por", AG.pessoa(it.registradoPor).nome + " (em nome de " + AG.pessoa(it.dono).curto + ")"]);
                if (it.assistida) linhas.push(["Assistida", AG.identAssistida(it.assistida)]);
                if (it.ref) linhas.push(["Origem", it.ref + (AG.origem(it.ref) && AG.origem(it.ref).restrito ? " · acesso restrito" : "")]);
                if (it.local) linhas.push(["Local", it.local + (it.fonte === "manual" ? " <span class='ag-nota'>(informar a sala não reserva a sala)</span>" : "")]);
                if (it.deslocamento) linhas.push(["Deslocamento", it.deslocamento + " min antes e depois (ocupa a agenda)"]);
                if (it.presencial != null && it.fonte !== "manual") linhas.push(["Presencial", it.presencial ? "sim" + (it.avisarRecepcao === false ? " · Recepção não avisada" : it.avisarRecepcao ? " · Recepção avisada no dia" : "") : "não"]);
                if (it.situacao) linhas.push(["Situação", it.situacao]);
                if (it.chegada && it.situacao !== "remarcado" && it.situacao !== "cancelado") linhas.push(["Chegada", textoChegada(it.chegada)]);
                if (it.tipo === "ausencia") linhas.push(["Ausência", it.ausencia === "informada" ? "INFORMADA (não cancela nada e não bloqueia até ser confirmada)" : it.ausencia]);
                if (it.participantes && it.participantes.length) linhas.push(["Participantes", it.participantes.map(x => esc(AG.pessoa(x).curto)).join(", ") + " <span class='ag-nota'>(ocupa a agenda delas)</span>"]);
                if (it.vis) linhas.push(["Quem pode ver", { eu: "Só quem participa", area: "Minha área", pessoas: "Pessoas escolhidas" + ((it.verPessoas || []).length ? ": " + it.verPessoas.map(x => esc(AG.pessoa(x).curto)).join(", ") : ""), equipe: "Toda a equipe" }[it.vis] + " <span class='ag-nota'>(só ver não ocupa a agenda)</span>"]);
                if ((it.verPessoas || []).includes(V.id) && !AG.envolve(it, V.id)) nota = "Compartilhado com você só para ver: não ocupa a sua agenda e não entra na conferência dos seus horários.";
                if (it.excecao) linhas.push(["Exceção", "Unidade fechada nesse dia: exceção autorizada por " + esc(AG.pessoa(it.excecao.por).curto) + " só para este compromisso (" + esc(it.excecao.motivo) + ")"]);
                if (it.serie) linhas.push(["Repete", "toda semana"]);
                if (it.obs) linhas.push(["Observação", esc(it.obs)]);
                if (it.justificativa) linhas.push(["Justificativa", esc(it.justificativa)]);
                if (it.historico) linhas.push(["Histórico", it.historico.map(esc).join("<br>")]);
                if (it.tipo === "comunicacao") nota = "É só uma comunicação: não marca nada na chamada. O motivo pessoal não é registrado aqui.";
                if (it.fonte !== "manual") acoes += `<button type="button" class="soft-btn soft-btn-secondary" data-acao="origem">Ir para a origem</button>`;
                if (it.chegada && it.chegada.estado === "chegou" && it.dono === V.id) acoes += `<button type="button" class="soft-btn soft-btn-primary" data-acao="recebida">Marcar como recebida</button>`;
                if (it.situacao === "agendado" && it.ini > D.AGORA && it.dono === V.id && it.fonte !== "manual" && $("#fRef")) acoes += `<button type="button" class="soft-btn soft-btn-secondary" data-acao="remarcar">Remarcar</button>`;
                if (it.situacao === "agendado" && it.fim < D.AGORA && it.dono === V.id) acoes += `<button type="button" class="soft-btn soft-btn-primary" data-acao="resultado">Registrar resultado</button>`;
                if (it.tipo === "ausencia" && it.ausencia === "informada" && (it.dono === V.id || V.perfil === "adm")) acoes += `<button type="button" class="soft-btn soft-btn-primary" data-acao="ausOk">Confirmar ausência</button><button type="button" class="soft-btn soft-btn-secondary" data-acao="ausNao">Não procede</button>`;
                if (it.fonte === "manual" && (it.dono === V.id || it.registradoPor === V.id) && it.situacao !== "cancelado" && it.tipo !== "ausencia") acoes += `<button type="button" class="soft-btn soft-btn-warning" data-acao="cancelarManual">Cancelar…</button>`;
                if (it.assistida) nota = (nota ? nota + " " : "") + "Abrir este detalhe fica registrado no histórico de ações. Relatos e evoluções nunca aparecem na agenda.";
            }
        }
        const { m, fechar } = modal(`<h3><span class="${classe(it, nivel)}" style="color:var(--cor)">${esc(tx.t)}</span><button type="button" data-fechar aria-label="Fechar">×</button></h3>
            <dl class="ag-det">${linhas.map(l => `<dt>${l[0]}</dt><dd>${l[1]}</dd>`).join("")}</dl>${nota ? `<p class="ag-nota">${nota}</p>` : ""}${acoes ? `<div class="ag-acoes">${acoes}</div>` : ""}`);
        if (it.assistida && nivel === "detalhe") AG.auditar(`${V.curto} abriu o detalhe de um compromisso de ${AG.identAssistida(it.assistida)}`);
        m.addEventListener("click", e => {
            const a = e.target.closest("[data-acao]"); if (!a) return;
            const ac = a.dataset.acao;
            fechar();
            if (ac === "chegou") marcarChegada(it);
            if (ac === "origem") toast(`No sistema real, abriria ${it.ref}.`);
            if (ac === "recebida" || ac === "ausOk" || ac === "ausNao" || ac === "resultado" || ac === "remarcar") acaoPendencia(ac, it.id);
            if (ac === "chamada") abrirChamada(it.id);
            if (ac === "cancelarAula") abrirCancelarAula(it.id);
            if (ac === "desfazerAula") { delete AG.estado.aulaExc[it.curso + "|" + it.dia]; const s = AG.estado.serieAte[it.curso]; if (s && it.dia >= s.dia) delete AG.estado.serieAte[it.curso]; toast("Cancelamento desfeito."); atualizar(); }
            if (ac === "cancelarManual") cancelarManual(it);
        });
    }

    // ---------------- ações de pendência ----------------
    function acaoPendencia(acao, id) {
        const it = AG.estado.itens.find(i => i.id === id) || item(id);
        const deItem = ["recebida", "resultado", "assumir", "remarcar", "rede"].includes(acao);
        if ((deItem && !AG.podeAgirNoItem(V, it)) || (["reavaliar", "agendarEnc", "verReav"].includes(acao) && !AG.acessoOrigem(V, id))) { toast("Você não tem mais permissão neste caso/prontuário. Nada foi alterado."); return atualizar(); }
        if (acao === "recebida") { it.chegada.estado = "recebida"; it.chegada.recebidaEm = new Date(+D.AGORA + 4 * 60000); AG.auditar(`${V.curto} marcou ${AG.identAssistida(it.assistida)} como recebida`); toast("Marcada como recebida. A Recepção vê “Recebida pela equipe”."); return atualizar(); }
        if (acao === "ausOk" || acao === "ausNao") {
            it.ausencia = acao === "ausOk" ? "confirmada" : "recusada"; it.confirmadoPor = V.id;
            AG.auditar(`${V.curto} ${acao === "ausOk" ? "confirmou" : "marcou como não procede"} a ausência de ${AG.pessoa(it.dono).curto} registrada por ${AG.pessoa(it.registradoPor).curto}`);
            toast(acao === "ausOk" ? "Ausência confirmada. Agora ela pede confirmação ao agendar por cima. Os compromissos existentes continuam lá: remarque se precisar." : "Aviso marcado como não procede.");
            return atualizar();
        }
        if (acao === "resultado") {
            const { m, fechar } = modal(`<h3>Registrar resultado<button type="button" data-fechar>×</button></h3><p>${esc(it.titulo)} de ${esc(AG.identAssistida(it.assistida))}, ${AG.diaSemana(it.ini)} ${AG.dm(it.ini)} ${AG.hm(it.ini)}</p>
                <div class="ag-form"><div class="full"><label>O que aconteceu</label><select class="soft-input" id="rRes"><option value="">Escolha…</option><option value="realizado">Realizado (registrar o atendimento na origem)</option><option value="falta registrada">Falta registrada</option><option value="cancelado">Cancelado</option><option value="remarcado">Remarcado</option></select></div></div>
                <p class="ag-nota">Nada é marcado sozinho: horário passado sem registro não quer dizer falta.</p><div class="ag-acoes"><button type="button" class="soft-btn soft-btn-secondary" data-fechar>Voltar</button><button type="button" class="soft-btn soft-btn-primary" id="rOk">Salvar</button></div>`);
            $("#rOk", m).addEventListener("click", () => { const v = $("#rRes", m).value; if (!v) return toast("Escolha o que aconteceu."); it.situacao = v; (it.historico = it.historico || []).push(`${v} (registrado em ${AG.dm(D.AGORA)})`); AG.auditar(`${V.curto} registrou resultado “${v}” de ${it.titulo}`); fechar(); atualizar(); });
            return;
        }
        if (acao === "reavaliar") {
            const r = AG.estado.reavaliacao[id], o = AG.origem(id);
            const { m, fechar } = modal(`<h3>Registrar reavaliação de risco<button type="button" data-fechar>×</button></h3><p>${esc(AG.identAssistida(o.assistida))} · ${id}</p>
                <div class="ag-form"><div><label>Classificação agora</label><select class="soft-input" id="rvC"><option ${r.riscoAtual === "alto" ? "selected" : ""}>alto</option><option>iminente</option><option>moderado</option><option>baixo</option></select></div><div></div>
                <div class="full"><label>Próxima ação (obrigatória)</label><textarea class="soft-input" id="rvA" placeholder="Ex.: sessão semanal mantida; contato com a rede combinado."></textarea></div></div>
                <p class="ag-nota">A pendência some quando a reavaliação é registrada, <b>mesmo que o risco continue igual</b>. A situação de risco continua visível para quem tem autorização. Urgência segue o fluxo da Casa (CAPS, SAMU 192, CVV 188).</p>
                <div class="ag-acoes"><button type="button" class="soft-btn soft-btn-secondary" data-fechar>Voltar</button><button type="button" class="soft-btn soft-btn-primary" id="rvOk">Registrar reavaliação</button></div>`);
            $("#rvOk", m).addEventListener("click", () => {
                const a = $("#rvA", m).value.trim(); if (!a) return toast("Escreva a próxima ação.");
                const reg = { em: new Date(+D.AGORA), por: V.id, classificacao: $("#rvC", m).value, proximaAcao: a };
                (r.registros = r.registros || []).push(reg);
                r.pendente = false; r.riscoAtual = reg.classificacao;
                AG.auditar(`${V.curto} registrou reavaliação de risco (${r.riscoAtual}) em ${id}`);
                fechar(); toast(`Reavaliação registrada. Situação de risco: ${r.riscoAtual}. A pendência foi resolvida.`); atualizar();
            });
            return;
        }
        if (acao === "assumir") {
            const j = AG.janela(it);
            return conferirSerie({ viewer: V, dono: V.id, assistida: it.assistida, ignorar: it.id }, [{ ini: j.ini, fim: j.fim }], res => {
                const de = it.dono; it.dono = V.id;
                if (res[0].justificativa) it.justificativa = res[0].justificativa;
                (it.historico = it.historico || []).push(`Transferido de ${AG.pessoa(de).curto} para ${V.curto} em ${AG.dm(D.AGORA)} (disponibilidade conferida)`);
                AG.tirarDaRevisao(it.id);
                AG.auditar(`${V.curto} assumiu ${it.titulo.toLowerCase()} de ${AG.dm(it.ini)} (${it.ref})${res[0].justificativa ? " · confirmou por cima de conflito: “" + res[0].justificativa + "”" : ""}`);
                toast("Compromisso assumido: agora está na sua agenda."); atualizar();
            });
        }
        if (acao === "remarcar") {
            UI.remarcando = it.id;
            const s = $("#fRef"); if (s) { s.value = it.ref; s.dispatchEvent(new Event("change")); $("#fData").value = ymd(it.ini); $("#fHora").value = AG.hm(it.ini); $("#fResultado").textContent = `Remarcando ${it.titulo.toLowerCase()} de ${AG.dm(it.ini)} ${AG.hm(it.ini)}. Escolha o novo horário e clique em Agendar: o anterior fica como “remarcado” no histórico.`; s.scrollIntoView({ behavior: "smooth", block: "center" }); }
            return;
        }
        if (acao === "verReav") {
            const r = AG.estado.reavaliacao[id], o = AG.origem(id);
            modal(`<h3>Reavaliações de risco<button type="button" data-fechar>×</button></h3><p>${esc(AG.identAssistida(o.assistida))} · ${id}</p>
                ${r.registros.slice().reverse().map(g => `<dl class="ag-det"><dt>Data</dt><dd>${AG.dm(g.em)} às ${AG.hm(g.em)}</dd><dt>Profissional</dt><dd>${esc(AG.pessoa(g.por).nome)}</dd><dt>Classificação</dt><dd>${esc(g.classificacao)}</dd><dt>Próxima ação</dt><dd>${esc(g.proximaAcao)}</dd></dl>`).join("<hr style='border:0;border-top:1px solid #F6E3EC'>")}
                <p class="ag-nota">No sistema real este registro fica no prontuário, visível só para quem tem permissão nele.</p><div class="ag-acoes"><button type="button" class="soft-btn soft-btn-secondary" data-fechar>Fechar</button></div>`);
            return;
        }
        if (acao === "chamada") return abrirChamada(id);
        if (acao === "cancelarAula") return abrirCancelarAula(id);
        if (acao === "agendarEnc") { const s = $("#fRef"); if (s) { s.value = id; s.dispatchEvent(new Event("change")); s.scrollIntoView({ behavior: "smooth", block: "center" }); s.focus(); } return; }
        if (acao === "rede") { it.pendente = false; AG.auditar(`${V.curto} registrou retorno da rede (${it.ref})`); toast("Retorno registrado."); return atualizar(); }
    }

    // ---------------- chamada (prévia) ----------------
    function abrirChamada(id) {
        const it = item(id), c = AG.curso(it.curso), com = comunicacoesDaAula(it), passada = it.fim < D.AGORA;
        const { m, fechar } = modal(`<h3>Chamada · ${esc(c.nome)} · ${AG.diaSemana(it.ini)} ${AG.dm(it.ini)}<button type="button" data-fechar>×</button></h3>
            <table class="ag-chamada">${c.alunas.map(a => { const cm = com.find(x => x.assistida === a); return `<tr><td><b>${esc(AG.identAssistida(a))}</b>${cm ? `<br><span class="ag-tag k-aula">${esc(cm.titulo.toLowerCase())} · registrado por ${esc(AG.pessoa(cm.registradoPor).curto)}</span>` : ""}</td><td>${["Presente", "Falta", "Falta justificada"].map(o => `<label><input type="radio" name="ch_${a}" value="${o}" ${!passada ? "disabled" : ""}> ${o}</label>`).join("")}</td></tr>`; }).join("")}</table>
            <p class="ag-nota">${com.length ? "O aviso aparece ao lado do nome, mas <b>não marca nada</b>. " : ""}A chamada registra o que de fato aconteceu.${passada ? "" : " Esta é só uma prévia: a chamada é feita no dia da aula."}</p>
            <div class="ag-acoes"><button type="button" class="soft-btn soft-btn-secondary" data-fechar>Fechar</button>${passada && !it.chamada ? `<button type="button" class="soft-btn soft-btn-primary" id="chOk">Salvar chamada</button>` : ""}</div>`);
        const ok = $("#chOk", m);
        if (ok) ok.addEventListener("click", () => {
            if (c.alunas.some(a => !$(`input[name="ch_${a}"]:checked`, m))) return toast("Marque todas as alunas.");
            AG.estado.chamadas.add(it.curso + "|" + it.dia); AG.auditar(`${V.curto} fez a chamada de ${c.nome} (${AG.dm(it.ini)})`); fechar(); toast("Chamada salva."); atualizar();
        });
    }

    // ---------------- cancelar aula recorrente ----------------
    function abrirCancelarAula(id) {
        const it = item(id), c = AG.curso(it.curso);
        const feriado = D.CASA.find(x => AG.mesmoDia(x.ini, it.ini) && x.tipo !== "evento");
        const { m, fechar } = modal(`<h3>Cancelar aula de ${esc(c.nome)}<button type="button" data-fechar>×</button></h3>
            <p>${AG.diaLongo(it.ini)}, ${AG.dm(it.ini)}, ${AG.hm(it.ini)}–${AG.hm(it.fim)}. Esta aula se repete toda semana.</p>
            <div class="ag-form"><div class="full"><label>O que cancelar</label>
                <label class="linha-check"><input type="radio" name="esc" value="esta" checked> Somente esta ocorrência (${AG.dm(it.ini)})</label>
                <label class="linha-check"><input type="radio" name="esc" value="seguintes"> Esta e as próximas ocorrências futuras</label>
                <div class="ajuda">Cancelar aulas <b>não encerra a turma</b>: turma e matrículas continuam (encerrar a turma é outra ação, em Cursos). Aulas já realizadas ou que já têm chamada não mudam.</div></div>
            <div class="full"><label>Motivo</label><select class="soft-input" id="caM"><option ${feriado && !feriado.fechada ? "selected" : ""}>Feriado</option><option ${feriado && feriado.fechada ? "selected" : ""}>Unidade fechada</option><option>Professora ausente</option><option>Outro</option></select></div></div>
            <p class="ag-nota">Aula cancelada <b>não gera chamada pendente</b>. A Recepção e o Serviço Social veem “aula cancelada” para avisar as alunas.</p>
            <div class="ag-acoes"><button type="button" class="soft-btn soft-btn-secondary" data-fechar>Voltar</button><button type="button" class="soft-btn soft-btn-danger" id="caOk">Cancelar aula</button></div>`);
        $("#caOk", m).addEventListener("click", () => {
            const escopo = $("input[name=esc]:checked", m).value, motivo = $("#caM", m).value;
            if (escopo === "esta") AG.estado.aulaExc[it.curso + "|" + it.dia] = { motivo: motivo + " (só esta)" };
            else AG.estado.serieAte[it.curso] = { dia: it.dia, motivo: motivo + " (desta em diante)" };
            AG.auditar(`${V.curto} cancelou ${escopo === "esta" ? "a aula de " + AG.dm(it.ini) : "as aulas a partir de " + AG.dm(it.ini)} de ${c.nome}: ${motivo}`);
            fechar(); toast(escopo === "esta" ? `Aula de ${AG.dm(it.ini)} cancelada. As outras semanas continuam.` : `Aulas futuras canceladas a partir de ${AG.dm(it.ini)}. A turma continua ativa e o histórico não mudou.`); atualizar();
        });
    }
    function reabrirUnidade(cid) {
        const c = D.CASA.find(x => x.id === cid);
        const { m, fechar } = modal(`<h3>Reabrir a unidade para todos?<button type="button" data-fechar>×</button></h3><p>${AG.dm(c.ini)}: ${esc(c.titulo)}.</p><p><b>Isto desfaz o fechamento para toda a equipe</b>: qualquer pessoa poderá agendar nesse dia. Para liberar só um atendimento, não use isto: autorize a exceção no próprio compromisso.</p><div class="ag-form"><div class="full"><label>Motivo (obrigatório)</label><textarea class="soft-input" id="exM"></textarea></div></div><div class="ag-acoes"><button type="button" class="soft-btn soft-btn-secondary" data-fechar>Voltar</button><button type="button" class="soft-btn soft-btn-danger" id="exOk">Reabrir para todos</button></div>`);
        $("#exOk", m).addEventListener("click", () => { const mo = $("#exM", m).value.trim(); if (!mo) return toast("Informe o motivo."); AG.estado.reaberta[cid] = mo; AG.auditar(`${V.curto} REABRIU a unidade para todos em ${AG.dm(c.ini)}: ${mo}`); fechar(); atualizar(); });
    }
    function cancelarManual(it) {
        const serie = it.serie;
        const { m, fechar } = modal(`<h3>Cancelar “${esc(it.titulo)}”<button type="button" data-fechar>×</button></h3>
            ${serie ? `<div class="ag-form"><div class="full"><label class="linha-check"><input type="radio" name="esc" value="esta" checked> Somente esta ocorrência (${AG.dm(it.ini)})</label><label class="linha-check"><input type="radio" name="esc" value="seguintes"> Esta e as próximas</label><label class="linha-check"><input type="radio" name="esc" value="todas"> Todas as que ainda não aconteceram</label><div class="ajuda">Ocorrências que já passaram nunca são alteradas.</div></div></div>` : "<p>O compromisso fica riscado e continua no histórico.</p>"}
            <div class="ag-acoes"><button type="button" class="soft-btn soft-btn-secondary" data-fechar>Voltar</button><button type="button" class="soft-btn soft-btn-danger" id="cmOk">Cancelar compromisso</button></div>`);
        $("#cmOk", m).addEventListener("click", () => {
            const e = serie ? $("input[name=esc]:checked", m).value : "esta";
            AG.estado.itens.filter(x => x === it || (serie && x.serie === serie && x.ini > D.AGORA && (e === "todas" || (e === "seguintes" && x.ini >= it.ini)))).forEach(x => { x.situacao = "cancelado"; x.cancelada = { motivo: "cancelado" }; });
            AG.auditar(`${V.curto} cancelou “${it.titulo}” (${e})`); fechar(); atualizar();
        });
    }

    // ---------------- conferência + salvar ----------------
    /* Confere CADA ocorrência separadamente. Justificativa e exceção da ADM valem só para a data em que foram dadas. */
    function conferirSerie(base, ocs, aoSalvar) {
        const rows = ocs.map(o => ({ o, cf: AG.conflitos(Object.assign({}, base, { ini: o.ini, fim: o.fim })) }));
        if (rows.every(x => !x.cf.length)) return aoSalvar(ocs.map(o => ({ o })));
        const serie = ocs.length > 1, adm = V.perfil === "adm";
        const titulos = { bloqueio: "Bloqueado", confirmar: "Precisa de confirmação", aviso: "Aviso" };
        const lista = cf => `<ul class="ag-conf">${cf.map(c => `<li class="${c.nivel}"><b>${titulos[c.nivel]}</b>${esc(c.msg)}</li>`).join("")}</ul>`;
        const tem = (x, n) => x.cf.some(c => c.nivel === n);
        const ctrl = (x, i) => {
            let h = "";
            if (tem(x, "bloqueio")) {
                if (adm && x.cf.some(c => c.casa)) h += `<label class="linha-check"><input type="checkbox" data-exc="${i}"> Autorizar exceção só para este compromisso${serie ? " nesta data" : ""}</label><input type="text" class="soft-input" data-excm="${i}" placeholder="Motivo da exceção (obrigatório)"><div class="ajuda">Vale só para ${base.participantes && base.participantes.length ? "as pessoas deste compromisso" : "este compromisso"}. A unidade continua fechada para as demais. Para reabrir para todos, use Configuração da agenda.</div>`;
                else h += `<p class="ag-nota" style="margin:4px 0">${serie ? "Esta data não será criada." : "Escolha outro dia."} Só a ADM pode autorizar uma exceção, e ela vale só para o compromisso autorizado.</p>`;
            }
            if (tem(x, "confirmar")) h += `<input type="text" class="soft-input" data-just="${i}" placeholder="Justificativa curta ${serie ? "para esta data" : "para confirmar"} (obrigatória)">`;
            return h;
        };
        const corpo = serie
            ? `<p>Conferi as <b>${ocs.length} datas</b>, uma por uma. Cada data é decidida separadamente: a justificativa ou autorização de uma data não vale para as outras.</p>
               <table class="ag-serie">${rows.map((x, i) => `<tr><td><label class="linha-check"><input type="checkbox" data-inc="${i}" ${tem(x, "bloqueio") ? "disabled" : "checked"}> ${AG.diaSemana(x.o.ini)} ${AG.dm(x.o.ini)}</label></td><td>${x.cf.length ? lista(x.cf) + ctrl(x, i) : `<span class="ok">Sem conflito</span>`}</td></tr>`).join("")}</table>`
            : lista(rows[0].cf) + ctrl(rows[0], 0) + (tem(rows[0], "confirmar") ? `<p class="ag-nota">A confirmação e a justificativa ficam no histórico de ações.</p>` : "");
        const { m, fechar } = modal(`<h3>Antes de salvar<button type="button" data-fechar>×</button></h3>${corpo}
            <div class="ag-acoes"><button type="button" class="soft-btn soft-btn-secondary" data-fechar>Voltar e escolher outro horário</button><button type="button" class="soft-btn soft-btn-primary" id="cfOk"></button></div>`);
        const ok = $("#cfOk", m);
        const incluida = i => serie ? $(`[data-inc="${i}"]`, m).checked : (!tem(rows[0], "bloqueio") || !!($(`[data-exc="0"]`, m) || {}).checked);
        const atualizarBotao = () => {
            rows.forEach((x, i) => { const ex = $(`[data-exc="${i}"]`, m), inc = $(`[data-inc="${i}"]`, m); if (inc && tem(x, "bloqueio")) { inc.disabled = !(ex && ex.checked); if (inc.disabled) inc.checked = false; } });
            const n = rows.filter((x, i) => incluida(i)).length;
            ok.disabled = !n; ok.style.display = !serie && !n ? "none" : "";
            ok.textContent = serie ? `Salvar ${n} de ${ocs.length} datas` : tem(rows[0], "confirmar") || tem(rows[0], "bloqueio") ? "Confirmar mesmo assim" : "Salvar";
        };
        m.addEventListener("change", e => { const ex = e.target.closest("[data-exc]"); if (ex && serie) $(`[data-inc="${ex.dataset.exc}"]`, m).checked = ex.checked; atualizarBotao(); });
        atualizarBotao();
        const primeiro = $("input:not([disabled])", m) || (ok.style.display === "none" ? $(".ag-acoes [data-fechar]", m) : ok); primeiro.focus();
        ok.addEventListener("click", () => {
            const res = [];
            for (let i = 0; i < rows.length; i++) {
                if (!incluida(i)) continue;
                const x = rows[i], r0 = { o: x.o };
                if (tem(x, "confirmar")) { const j = $(`[data-just="${i}"]`, m); r0.justificativa = j.value.trim(); if (!r0.justificativa) { j.focus(); return toast(`Escreva a justificativa${serie ? " de " + AG.dm(x.o.ini) : ""}.`); } }
                const ex = $(`[data-exc="${i}"]`, m);
                if (ex && ex.checked) { const mo = $(`[data-excm="${i}"]`, m); if (!mo.value.trim()) { mo.focus(); return toast("Informe o motivo da exceção."); } r0.excecao = { motivo: mo.value.trim(), por: V.id }; }
                res.push(r0);
            }
            fechar(); aoSalvar(res);
        });
    }
    function agendarDoForm() {
        const x = lerForm();
        const fonte = { psicologia: "psi", juridico: "jur", as_social: "soc" }[V.perfil];
        const ctx = { viewer: V, dono: V.id, assistida: x.o.assistida, ignorar: UI.remarcando };
        conferirSerie(ctx, [{ ini: new Date(+x.ini - x.desl * 60000), fim: new Date(+x.fim + x.desl * 60000) }], res => {
            const j = res[0].justificativa;
            const novo = { id: AG.novoId(), fonte, tipo: x.tipo === "visita_inst" ? "visita" : x.tipo, titulo: x.tipoTxt.replace(" (na unidade)", ""), ref: x.ref, assistida: x.o.assistida, dono: V.id, ini: x.ini, fim: x.fim, presencial: x.pres, avisarRecepcao: x.rec, situacao: "agendado", deslocamento: x.desl || undefined, obs: x.obs || undefined, justificativa: j || undefined, excecao: res[0].excecao, historico: [`Agendado por ${V.curto} em ${AG.dm(D.AGORA)}`] };
            if (x.pres) novo.chegada = { estado: "esperada" };
            const antigo = UI.remarcando && item(UI.remarcando); UI.remarcando = null;
            if (antigo && antigo.ref === x.ref) { antigo.situacao = "remarcado"; if (antigo.chegada && antigo.chegada.estado === "esperada") delete antigo.chegada; (antigo.historico = antigo.historico || []).push(`Remarcado por ${V.curto} para ${AG.dm(x.ini)} ${AG.hm(x.ini)}`); novo.historico.unshift(`Remarcação de ${AG.dm(antigo.ini)} ${AG.hm(antigo.ini)}`); AG.tirarDaRevisao(antigo.id); }
            AG.estado.itens.push(novo);
            AG.auditar(`${V.curto} agendou ${novo.titulo.toLowerCase()} (${x.ref}) para ${AG.dm(x.ini)} ${AG.hm(x.ini)}${j ? " · confirmou por cima de conflito: “" + j + "”" : ""}`);
            $("#fResultado").innerHTML = `✓ Agendado: ${AG.diaSemana(x.ini)} ${AG.dm(x.ini)} às ${AG.hm(x.ini)}. Aparece na sua Agenda${x.rec ? " e, no dia, para a Recepção como “Atendimento com a equipe técnica”" : ""}.`;
            atualizar();
        });
    }

    // ---------------- novo compromisso ----------------
    function tiposManuais() {
        const t = [["lembrete", "Lembrete"], ["prazo", "Prazo"], ["reuniao", "Reunião interna"], ["ausencia", "Ausência ou atraso (meu ou de colega)"]];
        if (V.perfil === "juridico") t.push(["audiencia", "Audiência"]);
        if (V.perfil === "as_social") t.push(["visita", "Visita / saída externa"]);
        if (["recepcao", "as_social", "professora"].includes(V.perfil)) t.push(["comunicacao", "Comunicação de falta/atraso de aluna"]);
        if (V.perfil === "adm") t.push(["evento", "Evento da Casa"]);
        return t;
    }
    function alunasDoViewer() {
        const ids = new Set();
        D.CURSOS.forEach(c => c.alunas.forEach(a => { if (V.perfil === "recepcao" || c.prof === V.id || (V.perfil === "as_social" && AG.veCursoDaAssistida(V, a))) ids.add(a); }));
        return Array.from(ids);
    }
    function abrirNovo(pre) {
        const tipos = tiposManuais();
        const refs = Object.keys(AG.estado.origens).filter(r => AG.acessoOrigem(V, r));
        const dt = pre.data && pre.data > HOJE ? pre.data : AG.somaDias(HOJE, 1);
        const outras = D.PESSOAS.filter(p => p.id !== V.id);
        const html = `<h3>Novo compromisso<button type="button" data-fechar>×</button></h3>
        <form class="ag-form" id="nF" autocomplete="off">
            <div class="full"><label for="nTipo">Tipo</label><select id="nTipo" class="soft-input">${tipos.map(t => `<option value="${t[0]}" ${pre.tipo === t[0] ? "selected" : ""}>${t[1]}</option>`).join("")}</select></div>
            <div class="full" data-so="comunicacao"><label for="nAluna">Aluna</label><select id="nAluna" class="soft-input">${alunasDoViewer().map(a => `<option value="${a}">${esc(AG.identAssistida(a))}</option>`).join("")}</select></div>
            <div class="full" data-so="comunicacao"><label for="nAula">Aula</label><select id="nAula" class="soft-input"></select></div>
            <div class="full" data-so="comunicacao"><label for="nCom">O que ela comunicou</label><select id="nCom" class="soft-input"><option value="falta">Vai faltar</option><option value="atraso">Vai chegar atrasada</option></select><div class="ajuda">O motivo pessoal não é registrado aqui. A professora vê só quem, qual aula e o fato. Não marca a chamada.</div></div>
            <div class="full" data-nao="comunicacao"><label for="nTit">Título</label><input id="nTit" class="soft-input" placeholder="Ex.: Volto às 15h"></div>
            <div class="full" data-so="ausencia"><label for="nNome">Em nome de</label><select id="nNome" class="soft-input"><option value="${V.id}">Eu mesma</option>${outras.map(p => `<option value="${p.id}">${esc(p.nome)} (${esc(p.area)})</option>`).join("")}</select><div class="ajuda">Aviso de colega fica como <b>informado</b> até ela (ou a ADM) confirmar. Não cancela compromissos nem bloqueia a agenda dela.</div></div>
            <div data-nao="comunicacao"><label for="nData">Data</label><input id="nData" type="date" class="soft-input" value="${ymd(dt)}"></div>
            <div data-nao="comunicacao"><label class="linha-check" style="margin-top:24px"><input type="checkbox" id="nTodo"> Dia inteiro</label><div class="ajuda" id="nTodoAj"></div></div>
            <div data-nao="comunicacao" data-hora><label for="nIni">Início</label><input id="nIni" type="time" class="soft-input" value="09:00" step="900"></div>
            <div data-nao="comunicacao" data-hora><label for="nFim">Fim</label><input id="nFim" type="time" class="soft-input" value="10:00" step="900"></div>
            <div class="full" data-nao="comunicacao"><label for="nLocal">Local (opcional)</label><input id="nLocal" class="soft-input"><div class="ajuda">Informar a sala não reserva a sala.</div></div>
            <div class="full" data-nao="comunicacao ausencia"><label for="nRef">Assistida vinculada (opcional)</label><select id="nRef" class="soft-input"><option value="">Nenhuma</option>${refs.map(r => `<option value="${r}">${esc(AG.identAssistida(AG.estado.origens[r].assistida))} · ${r}</option>`).join("")}</select><div class="ajuda">Só aparecem casos e prontuários em que você tem permissão. Quem perder a permissão no caso deixa de ver o detalhe, mesmo tendo criado o compromisso.</div></div>
            <div class="full ag-bloco" data-nao="comunicacao ausencia lembrete prazo"><label>Participantes</label><div style="display:flex;flex-wrap:wrap;gap:4px 14px">${outras.map(p => `<label class="linha-check"><input type="checkbox" data-npart="${p.id}"> ${esc(p.curto)}</label>`).join("")}</div>
                <div class="ajuda"><b>Participar ocupa a agenda</b>: o sistema confere a disponibilidade de você e de cada participante.</div>
                <button type="button" class="soft-btn soft-btn-secondary ag-btn-sm" id="nDisp" style="margin-top:6px">🗓 Ver disponibilidade</button></div>
            <div class="full"><label for="nVis">Quem pode ver</label><select id="nVis" class="soft-input"><option value="eu">Só quem participa</option><option value="area">Minha área</option><option value="pessoas">Pessoas escolhidas</option><option value="equipe">Toda a equipe</option></select><div class="ajuda">Só ver <b>não ocupa</b> a agenda de ninguém e não entra na conferência de horários dela.</div></div>
            <div class="full" data-pessoas><label>Pessoas que podem ver</label><div style="display:flex;flex-wrap:wrap;gap:4px 14px">${outras.map(p => `<label class="linha-check"><input type="checkbox" data-np="${p.id}"> ${esc(p.curto)}</label>`).join("")}</div></div>
            <div data-nao="comunicacao ausencia"><label for="nRep">Repetir</label><select id="nRep" class="soft-input"><option value="">Não repete</option><option value="4">Toda semana, 4 vezes</option><option value="8">Toda semana, 8 vezes</option></select><div class="ajuda">Cada data é conferida separadamente antes de salvar.</div></div>
            <div data-nao="comunicacao"><label for="nLem">Lembrete na tela</label><select id="nLem" class="soft-input"><option>Sem lembrete</option><option>5 min antes</option><option selected>30 min antes</option><option>1 dia antes</option></select><div class="ajuda">Aparece enquanto o sistema estiver aberto.</div></div>
            <div class="full ag-nota" id="nAviso" style="margin:0"></div>
            <div class="full ag-acoes"><button type="button" class="soft-btn soft-btn-secondary" data-fechar>Cancelar</button><button type="submit" class="soft-btn soft-btn-primary">Salvar</button></div>
        </form>`;
        let sujo = false;
        const { m, fechar } = modal(html, { sujo: () => sujo });
        const f = $("#nF", m);
        f.addEventListener("input", () => { sujo = true; });
        const tipoAtual = () => $("#nTipo", m).value;
        const ocupaTipo = (tipo, todo) => !["lembrete", "prazo", "comunicacao"].includes(tipo) && (!todo || tipo === "ausencia" || tipo === "reuniao" || tipo === "visita" || tipo === "audiencia" || tipo === "evento");
        const ajustar = () => {
            const tipo = tipoAtual(), vis = $("#nVis", m).value, ref = $("#nRef", m).value, emNome = $("#nNome", m).value !== V.id && tipo === "ausencia", todo = $("#nTodo", m).checked;
            $$("[data-so]", m).forEach(e => e.style.display = e.dataset.so === tipo ? "" : "none");
            $$("[data-nao]", m).forEach(e => e.style.display = e.dataset.nao.split(" ").includes(tipo) ? "none" : "");
            $$("[data-hora]", m).forEach(e => { if (tipo !== "comunicacao") e.style.display = todo ? "none" : ""; });
            $("#nVis", m).parentNode.style.display = tipo === "comunicacao" ? "none" : "";
            $("[data-pessoas]", m).style.display = vis === "pessoas" && tipo !== "comunicacao" ? "" : "none";
            $("#nTodoAj", m).textContent = !todo ? "" : ocupaTipo(tipo, true) ? "Ocupa o dia inteiro na agenda." : "Fica como marco do dia (não ocupa horário).";
            const eq = $("#nVis option[value=equipe]", m);
            eq.disabled = !!ref && tipo !== "ausencia";
            if (eq.disabled && vis === "equipe") $("#nVis", m).value = "pessoas";
            $("#nAviso", m).textContent = ref && tipo !== "ausencia" ? "Com assistida vinculada, “Toda a equipe” fica indisponível e só vê o detalhe quem tem permissão no caso/prontuário." : emNome ? "Vai aparecer como “Ausência informada para " + AG.pessoa($("#nNome", m).value).curto + " — registrado por " + V.curto + "”." : "";
            if (tipo === "ausencia" && !$("#nTit", m).value) $("#nTit", m).placeholder = "Ex.: Volto às 15h / Consulta médica pela manhã / Folga";
            if (tipo === "ausencia" && !sujo) $("#nVis", m).value = "equipe";
            if (tipo === "comunicacao") preencherAulas();
        };
        const preencherAulas = () => {
            const a = $("#nAluna", m).value;
            const aulas = AG.todos().filter(it => it.fonte === "curso" && AG.curso(it.curso).alunas.includes(a) && it.ini > D.AGORA && !it.cancelada && (V.perfil !== "professora" || it.dono === V.id)).slice(0, 6);
            $("#nAula", m).innerHTML = aulas.map(it => `<option value="${it.id}">${esc(AG.curso(it.curso).nome)} · ${AG.diaSemana(it.ini)} ${AG.dm(it.ini)} ${AG.hm(it.ini)}</option>`).join("");
        };
        ["#nTipo", "#nVis", "#nRef", "#nTodo", "#nNome"].forEach(q => $(q, m).addEventListener("change", ajustar));
        $("#nAluna", m).addEventListener("change", preencherAulas);
        ajustar();
        const participantes = () => $$("[data-npart]:checked", m).map(x => x.dataset.npart);
        $("#nDisp", m).addEventListener("click", () => {
            const data = $("#nData", m).value, ini = lerData(data, $("#nIni", m).value), fim = lerData(data, $("#nFim", m).value);
            const dur = Math.max(15, Math.round((fim - ini) / 60000)) || 60, ref = $("#nRef", m).value;
            const ps = [V.id].concat(participantes());
            abrirCal({ visao: "semana", data: ini, acimaDeModal: true, escolha: { pessoas: ps, assistida: ref ? AG.estado.origens[ref].assistida : null, dur, desl: 0, rotulo: ($("#nTit", m).value.trim() || "Novo compromisso") + " · " + ps.map(x => AG.pessoa(x).curto).join(", "), atual: fim > ini ? { ini, fim } : null,
                aoEscolher: d0 => { $("#nData", m).value = ymd(d0); $("#nIni", m).value = AG.hm(d0); $("#nFim", m).value = AG.hm(new Date(+d0 + dur * 60000)); $("#nTodo", m).checked = false; sujo = true; ajustar(); toast(`Horário escolhido: ${AG.diaSemana(d0)} ${AG.dm(d0)} às ${AG.hm(d0)}. Confira e clique em Salvar.`); } } });
        });
        f.addEventListener("submit", e => {
            e.preventDefault();
            const tipo = tipoAtual();
            if (tipo === "comunicacao") {
                const aula = item($("#nAula", m).value); if (!aula) return toast("Escolha a aula.");
                const com = $("#nCom", m).value;
                AG.estado.itens.push({ id: AG.novoId(), fonte: "manual", tipo: "comunicacao", titulo: com === "falta" ? "Avisou que vai faltar" : "Avisou que vai chegar atrasada", dono: aula.dono, registradoPor: V.id, assistida: $("#nAluna", m).value, curso: aula.curso, ini: aula.ini, vis: "pessoas", verPessoas: [aula.dono], ocupa: false, comunicacao: com });
                AG.auditar(`${V.curto} registrou comunicação de ${com} de ${AG.identAssistida($("#nAluna", m).value)} (${AG.curso(aula.curso).nome} ${AG.dm(aula.ini)})`);
                fechar(); toast("Comunicação registrada. A professora vê ao lado do nome na chamada."); return atualizar();
            }
            const todo = $("#nTodo", m).checked, data = $("#nData", m).value;
            const ini = lerData(data, todo ? "00:00" : $("#nIni", m).value), fim = todo ? null : lerData(data, $("#nFim", m).value);
            if (fim && fim <= ini) return toast("O fim precisa ser depois do início.");
            const titulo = $("#nTit", m).value.trim() || tipos.find(t => t[0] === tipo)[1];
            const dono = tipo === "ausencia" ? $("#nNome", m).value : V.id;
            const ref = tipo === "ausencia" ? "" : $("#nRef", m).value;
            const vis = $("#nVis", m).value;
            const verPessoas = vis === "pessoas" ? $$("[data-np]:checked", m).map(x => x.dataset.np) : [];
            const parts = ["ausencia", "lembrete", "prazo"].includes(tipo) ? [] : participantes();
            const ocupa = ocupaTipo(tipo, todo);
            const rep = ["ausencia"].includes(tipo) ? 1 : (+$("#nRep", m).value || 1);
            const base = { fonte: "manual", tipo: tipo === "audiencia" || tipo === "visita" || tipo === "evento" ? "reuniao" : tipo, titulo, dono, registradoPor: V.id, ref: ref || undefined, assistida: ref ? AG.estado.origens[ref].assistida : undefined, vis, verPessoas: verPessoas.length ? verPessoas : undefined, participantes: parts.length ? parts : undefined, local: $("#nLocal", m).value || undefined, diaInteiro: todo || undefined, ocupa: ocupa ? undefined : false };
            if (tipo === "ausencia") base.ausencia = dono === V.id ? "confirmada" : "informada";
            const ocs = []; for (let i = 0; i < rep; i++) ocs.push({ ini: AG.somaDias(ini, 7 * i), fim: fim ? AG.somaDias(fim, 7 * i) : null });
            const salvar = res => {
                const serie = rep > 1 ? "s" + AG.novoId() : undefined;
                res.forEach(x => AG.estado.itens.push(Object.assign({}, base, { id: AG.novoId(), ini: x.o.ini, fim: x.o.fim || undefined, serie, justificativa: x.justificativa, excecao: x.excecao })));
                const pul = rep - res.length;
                AG.auditar(`${V.curto} criou “${titulo}”${dono !== V.id ? " em nome de " + AG.pessoa(dono).curto : ""}${rep > 1 ? ` (${res.length} de ${rep} datas)` : ""}${res.some(x => x.justificativa) ? " · confirmou por cima de conflito: " + res.filter(x => x.justificativa).map(x => AG.dm(x.o.ini) + " “" + x.justificativa + "”").join("; ") : ""}${res.some(x => x.excecao) ? " · exceção de unidade fechada só para este compromisso: " + res.filter(x => x.excecao).map(x => AG.dm(x.o.ini) + " (" + x.excecao.motivo + ")").join("; ") : ""}`);
                fechar(); toast(dono !== V.id ? `Ausência informada para ${AG.pessoa(dono).curto}. Ela confirma ou corrige na Agenda dela.` : rep > 1 ? `${res.length} de ${rep} datas salvas${pul ? `; ${pul} não ${pul > 1 ? "foram criadas" : "foi criada"}` : ""}.` : "Compromisso salvo."); atualizar();
            };
            if (!ocupa || tipo === "ausencia") return salvar(ocs.map(o => ({ o })));
            conferirSerie({ viewer: V, dono, participantes: parts, assistida: base.assistida, diaInteiro: todo }, ocs.map(o => ({ ini: o.ini, fim: o.fim || AG.somaDias(o.ini, 1) })), salvar);
        });
    }

    // ---------------- demonstrações guiadas ----------------
    const DEMOS = [
        { nome: "Chegada na Recepção", ver: "rec", passos: ["Em <b>Esperadas hoje</b>, veja que aparecem nome de identificação, código e hora, com “Atendimento com a equipe técnica”. Repare nas duas “Maria S.”: o código evita confusão.", "Clique em <b>Chegou</b> na Joana Lima (14:00).", "No topo, troque <b>Ver como</b> para <b>Ana Beatriz Lima (Psicologia)</b>: a Agenda dela mostra “chegou” e, em Pendências, o botão <b>Marcar como recebida</b>.", "Volte para a Recepção: o fluxo fica <b>Esperada › Chegou › Recebida pela equipe</b>.", "Note que o atendimento jurídico restrito da Maria Souza (15:00) não aparece para a Recepção."] },
        { nome: "Ausência registrada por colega", ver: "psi2", passos: ["Você é a Bruna. Clique em <b>+ Novo compromisso</b>, tipo <b>Ausência ou atraso</b>, <b>Em nome de</b> uma colega. Já existe um exemplo: a ausência da Ana na quarta, 9h–12h, registrada por Bruna.", "Troque para <b>Sônia Ribeiro (ADM)</b> e crie uma <b>Reunião interna</b> na quarta 11/11, 10:30–11:00, com <b>Pessoas escolhidas</b> = Ana. Veja o aviso “ausência informada, ainda não confirmada” e “indisponibilidade na agenda de Ana” (a sessão dela, sem detalhes).", "Troque para <b>Ana</b>: em Pendências, <b>Confirmar</b> ou <b>Não procede</b>. A sessão das 10h continua lá: o aviso não cancelou nada.", "Depois de confirmada, agendar por cima pede confirmação e justificativa."] },
        { nome: "Conflito com compromisso sigiloso", ver: "jur1", passos: ["Você é a Dra. Fernanda. O formulário já está com Joana Lima, terça 17/11, 14:00.", "Clique em <b>Agendar</b>: aparece só “Há uma indisponibilidade da assistida nesse horário” (é uma sessão de Psicologia, que a Fernanda não pode ver).", "Mude para quarta 11/11, 09:00: agora aparece “A assistida tem aula de Informática Básica” (o Jurídico já vê curso e situação das fichas que atende).", "Clique em <b>Ver disponibilidade</b>: as faixas cinza não dizem o motivo nem usam a cor da Psicologia."] },
        { nome: "Cancelar uma aula recorrente", ver: "prof2", passos: ["Você é a Prof.ª Marta (Empreendedorismo, sextas 9h).", "Em <b>Minhas aulas</b>, veja a sexta 20/11 (feriado com plantão) e clique em <b>Cancelar…</b>.", "Escolha <b>Somente esta ocorrência</b> e o motivo <b>Feriado</b>. As outras sextas continuam.", "A sexta 27/11 (unidade fechada) aparece em Pendências para cancelar ou remarcar.", "Aula cancelada não gera chamada pendente. A de 06/11, que não foi cancelada nem teve chamada, continua pendente."] },
        { nome: "Comunicação de falta não preenche a chamada", ver: "prof1", passos: ["Você é a Prof.ª Luciana. A Recepção registrou que Joana vai faltar na quarta 11/11.", "Em <b>Minhas aulas</b>, abra a <b>Prévia da chamada</b> de 11/11: o aviso aparece ao lado do nome, mas nenhuma opção vem marcada.", "Para registrar uma comunicação nova, troque para a <b>Recepção</b> e use <b>Registrar falta ou atraso de aluna</b> (sem campo de motivo)."] },
        { nome: "Reavaliação de risco", ver: "psi1", passos: ["Você é a Ana. Em <b>Pendências</b>: “Reavaliação de risco pendente” da Cláudia Ferreira.", "Clique em <b>Registrar reavaliação</b>, mantenha <b>alto</b> e escreva a próxima ação.", "A pendência some mesmo com o risco igual. A situação de risco continua para quem tem autorização."] },
        { nome: "Calendário no meio de um formulário", ver: "jur1", passos: ["Escreva algo na <b>Observação</b> do formulário.", "Passe o mouse no relógio (canto superior direito) e em <b>Calendário</b>: abre o mini calendário. Passe o mouse nos dias.", "Clique em <b>Abrir completo</b>. Navegue, troque de visão.", "Feche com <b>×</b>, <b>Esc</b> ou o <b>Voltar</b> do navegador: o formulário continua igual, com o texto que você escreveu."] },
        { nome: "Ausência confirmada de dia inteiro gera conflito", ver: "jur1", passos: ["Você é a Dra. Fernanda. A Dra. Paula confirmou uma <b>folga de dia inteiro</b> na quinta 19/11.", "Clique em <b>+ Novo compromisso</b>, tipo <b>Reunião interna</b>, data 19/11, 10:00–11:00, e marque a <b>Paula</b> em <b>Participantes</b>.", "Clique em <b>Salvar</b>: aparece “Paula está ausente nesse horário (dia inteiro)”, que pede confirmação e justificativa.", "Feriado e prazo continuam só como marcos do dia: não ocupam horário."] },
        { nome: "Compromisso semanal: conflito só na 2ª semana", ver: "psi1", passos: ["Você é a Ana. Clique em <b>+ Novo compromisso</b>, tipo <b>Reunião interna</b>, título “Grupo de apoio”, terça 17/11, 16:00–17:00, <b>Repetir: toda semana, 4 vezes</b>.", "Clique em <b>Salvar</b>: o sistema confere as 4 datas, uma por uma. Só a terça <b>24/11</b> tem conflito (sessão já marcada às 16h).", "Para 24/11 você pode desmarcar a data ou escrever uma justificativa só dela. As outras datas são salvas sem conflito.", "A justificativa de uma data não vale para as outras."] },
        { nome: "Exceção em dia de unidade fechada", ver: "adm", passos: ["Você é a Sônia (ADM). Clique em <b>+ Novo compromisso</b>, tipo <b>Reunião interna</b>, título “Vistoria do imóvel”, sexta 27/11 (unidade fechada), 10:00–11:00, participante <b>Renata</b>.", "Clique em <b>Salvar</b>: aparece <b>Bloqueado</b>. Marque <b>Autorizar exceção só para este compromisso</b> e escreva o motivo.", "Em <b>Configuração da agenda</b>, a exceção aparece ligada a esse compromisso, ao horário e às pessoas.", "Troque para a <b>Ana</b> e tente agendar uma sessão em 27/11: continua <b>bloqueado</b>. Reabrir a unidade para todos é outra ação, separada e explícita."] },
        { nome: "Professora não vê agenda técnica", ver: "prof1", passos: ["Você é a Prof.ª Luciana. Abra o <b>Calendário completo</b>.", "Em <b>Pessoas</b>, marque a <b>Ana</b> (Psicologia) e vá para quinta 12/11 na visão <b>Dia</b>.", "A coluna da Ana não mostra as sessões, nem como “Ocupado”: disponibilidade técnica só aparece para quem está agendando algo com ela.", "Os filtros também não têm “Ocupado”: só o que a professora pode ver (as turmas dela, os dias e horários das outras turmas, avisos da equipe)."] },
        { nome: "Autora perde o detalhe ao perder o caso", ver: "adm", passos: ["Você é a Sônia (ADM). Em <b>Configuração da agenda</b>, clique em <b>Passar responsabilidades (simulação)</b>: o caso CJ-2026-000041 passa da Fernanda para a Paula.", "Troque para a <b>Dra. Fernanda</b>: o lembrete que ela mesma criou nesse caso agora aparece como “Compromisso de um caso que você não acessa mais”, sem assistida nem título.", "Troque para a <b>Dra. Paula</b>: em Pendências chegam os compromissos futuros do caso <b>para revisar</b>. Nada entrou sozinho na agenda dela.", "Clique em <b>Assumir na minha agenda</b> na audiência de 12/11: o sistema confere a disponibilidade e mostra o conflito com o atendimento das 13:30."] },
        { nome: "Ausência informada não tira horário livre", ver: "psi1", passos: ["Você é a Ana. A Bruna informou uma ausência em nome da Ana na quarta 11/11, 9h–12h, que a Ana ainda não confirmou.", "No formulário <b>Agendar sessão</b>, clique em <b>Ver disponibilidade</b>.", "Na quarta 11/11 de manhã, a faixa aparece em <b>amarelo</b> (“ausência informada”), mas os horários continuam selecionáveis. Clique num deles.", "Ao agendar, aparece só um aviso. Depois de confirmada, a ausência passa a pedir confirmação."] },
        { nome: "Compartilhar não ocupa a agenda", ver: "jur1", passos: ["Você é a Dra. Fernanda. Crie uma <b>Reunião interna</b> em 12/11, 10:00–11:00, <b>sem participantes</b>, com <b>Quem pode ver = Pessoas escolhidas: Paula</b>.", "Troque para a <b>Dra. Paula</b>: a reunião aparece em “Compartilhados comigo (só ver)”.", "Agende um atendimento para a Paula em 12/11 às 10:00: <b>não há conflito</b>, porque só ver não ocupa a agenda.", "Se a Paula estivesse em <b>Participantes</b>, o horário dela ficaria ocupado."] }
    ];
    function iniciarDemo(i) {
        UI.demo = i; V = AG.pessoa(DEMOS[i].ver); UI.aba = [3, 5].includes(i) ? "pend" : "hoje"; UI.remarcando = null; UI.cal.filtros = null; UI.cal.pessoas = new Set();
        render();
    }
    window.AG_UI = { abrirCal, fecharCal, iniciarDemo, abrirDetalhe, acaoPendencia, setViewer: id => { V = AG.pessoa(id); UI.cal.filtros = null; UI.cal.pessoas = new Set(); render(); }, UI };

    render();
})();
