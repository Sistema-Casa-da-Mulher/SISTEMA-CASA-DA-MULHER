/* Regras do protótipo: o que cada pessoa pode ver, pendências e conflitos.
   No sistema real tudo isto roda NO SERVIDOR; aqui roda no navegador só para a demonstração. */
(function () {
    "use strict";
    const D = window.AG_DADOS;
    const AG = window.AG = {};
    const MIN = 60000;

    // ---------- utilidades ----------
    AG.pessoa = id => D.PESSOAS.find(p => p.id === id);
    AG.assistida = id => D.ASSISTIDAS.find(a => a.id === id);
    AG.curso = id => D.CURSOS.find(c => c.id === id);
    AG.origem = ref => AG.estado.origens[ref];
    AG.mesmoDia = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
    AG.hm = dt => String(dt.getHours()).padStart(2, "0") + ":" + String(dt.getMinutes()).padStart(2, "0");
    AG.hcurto = dt => dt.getMinutes() ? AG.hm(dt).replace(":", "h") : dt.getHours() + "h";
    const DIAS = ["dom", "seg", "ter", "qua", "qui", "sex", "sáb"];
    const DIAS_LONGOS = ["domingo", "segunda", "terça", "quarta", "quinta", "sexta", "sábado"];
    AG.DIAS = DIAS;
    AG.MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];
    AG.dm = dt => String(dt.getDate()).padStart(2, "0") + "/" + String(dt.getMonth() + 1).padStart(2, "0");
    AG.diaSemana = dt => DIAS[dt.getDay()];
    AG.diaLongo = dt => DIAS_LONGOS[dt.getDay()];
    AG.inicioDia = dt => new Date(dt.getFullYear(), dt.getMonth(), dt.getDate());
    AG.somaDias = (dt, n) => new Date(dt.getFullYear(), dt.getMonth(), dt.getDate() + n, dt.getHours(), dt.getMinutes());
    AG.esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
    AG.identAssistida = id => { const a = AG.assistida(id); return a ? `${a.nome} (${a.codigo})` : ""; };
    AG.agora = () => D.AGORA;


    // ---------- estado (memória do protótipo) ----------
    const reviver = (k, v) => (typeof v === "string" && /^\d{4}-\d\d-\d\dT/.test(v)) ? new Date(v) : v;
    AG.reiniciar = function () {
        AG.estado = {
            itens: JSON.parse(JSON.stringify(D.ITENS), reviver),
            origens: JSON.parse(JSON.stringify(D.ORIGENS), reviver),
            chamadas: new Set(D.CHAMADAS_FEITAS),
            aulaExc: {},
            serieAte: {},
            reaberta: {},          // "Reabrir a unidade para todos" (ação explícita da ADM)
            revisar: [],           // compromissos recebidos em "Passar responsabilidades", aguardando revisão
            reavaliacao: { "PSI-2026-000009": { pendente: true, riscoAtual: "alto", registros: [] } },
            auditoria: [],
            seq: 1
        };
        AG.estado.itens.forEach(it => {
            if (["psi", "jur", "soc"].includes(it.fonte) && it.presencial) {
                // "Avisar a Recepção": se não foi informado, liga para casos comuns e desliga para casos restritos
                if (it.avisarRecepcao === undefined) it.avisarRecepcao = !(AG.origem(it.ref) || {}).restrito;
                if (!it.chegada) it.chegada = it.situacao === "realizado" ? { estado: "recebida", chegouEm: new Date(it.ini - 6 * MIN), recebidaEm: new Date(+it.ini) } : { estado: "esperada" };
            }
        });
    };
    AG.reiniciar();
    AG.auditar = txt => AG.estado.auditoria.unshift(AG.dm(D.AGORA) + " " + AG.hm(D.AGORA) + " · " + txt);

    // Aulas geradas pelo horário semanal da turma (recorrência)
    function aulas() {
        const out = [];
        D.CURSOS.forEach(c => {
            for (let dia = 1; dia <= 30; dia++) {
                const dt = new Date(2026, 10, dia);
                if (!c.dias.includes(dt.getDay())) continue;
                const [hi, mi] = c.ini.split(":").map(Number), [hf, mf] = c.fim.split(":").map(Number);
                const k = c.id + "|" + dia;
                const ini = new Date(2026, 10, dia, hi, mi);
                const chamada = AG.estado.chamadas.has(k);
                const exc = AG.estado.aulaExc[k];
                const ate = AG.estado.serieAte[c.id];
                // "Esta e as próximas" só atinge aulas FUTURAS e sem chamada: o histórico nunca muda
                const cancelada = exc ? exc : (ate && dia >= ate.dia && ini > D.AGORA && !chamada ? ate : null);
                out.push({ id: "aula-" + k, fonte: "curso", tipo: "aula", curso: c.id, dono: c.prof, titulo: "Aula: " + c.nome, ini, fim: new Date(2026, 10, dia, hf, mf), local: c.local, serie: c.id, dia, cancelada, chamada });
            }
        });
        return out;
    }
    AG.todos = function () {
        const casa = D.CASA.map(c => Object.assign({ fonte: "casa", ocupa: false }, c));
        return AG.estado.itens.concat(aulas(), casa);
    };
    // "Dia inteiro" e "ocupa horário" são coisas separadas: ausência de dia inteiro ocupa; feriado e prazo são marcos.
    AG.ocupa = it => it.ocupa !== false && (!!it.fim || !!it.diaInteiro) && !it.cancelada && it.situacao !== "cancelado" && it.situacao !== "remarcado" && it.ausencia !== "recusada";
    AG.janela = function (it) {
        if (it.diaInteiro) { const i = AG.inicioDia(it.ini); return { ini: i, fim: AG.somaDias(i, 1) }; }
        return { ini: new Date(it.ini - (it.deslocamento || 0) * MIN), fim: new Date(+(it.fim || it.ini) + (it.deslocamento || 0) * MIN) };
    };
    const sobrepoe = (a, b) => a.ini < b.fim && b.ini < a.fim;
    // Quem PARTICIPA (ocupa a agenda) é diferente de quem só PODE VER
    AG.envolve = (it, pid) => it.dono === pid || !!it.participantesTodos || (it.participantes || []).includes(pid);

    // ---------- permissão na ORIGEM (cadastro não basta) ----------
    AG.acessoOrigem = function (v, ref) {
        const o = AG.origem(ref);
        if (!o) return false;
        if (o.responsaveis.includes(v.id) || o.autorizados.includes(v.id)) return true;
        if (o.area === "jur" && v.perfil === "juridico" && o.visibilidade === "equipe" && !o.restrito) return true;
        return false;
    };
    AG.veCursoDaAssistida = function (v, aid) {
        if (v.perfil === "adm" || v.perfil === "recepcao") return true;
        if (D.CURSOS.some(c => c.prof === v.id && c.alunas.includes(aid))) return true;
        return Object.keys(AG.estado.origens).some(ref => AG.estado.origens[ref].assistida === aid && AG.acessoOrigem(v, ref));
    };

    /* Nível de revelação de um item para quem está olhando:
       detalhe   = detalhes operacionais autorizados (nunca relato/evolução)
       recepcao  = "Atendimento com a equipe técnica" + identificação + hora (presencial, no dia, com "Avisar a Recepção" ligado)
       curso     = aula de outra turma: dia, horário e professora, sem alunas
       contagem  = só entra como número (ADM)
       semacesso = compromisso da própria pessoa ligado a um caso em que ela perdeu a permissão: só o horário
       ocupado   = só existe na consulta de disponibilidade ("Indisponível"); não aparece em filtros
       oculto    = não aparece (mas CONTINUA contando no conflito) */
    AG.revelar = function (it, v) {
        if (it.fonte === "casa") return "detalhe";
        if (it.fonte === "curso") return (it.dono === v.id || v.perfil === "adm") ? "detalhe" : "curso";
        if (it.fonte === "manual") {
            const minha = it.dono === v.id || it.registradoPor === v.id || (it.participantes || []).includes(v.id);
            // 1º a origem: ter criado o item não mantém acesso a um caso que a pessoa não acessa mais
            if (it.ref && !AG.acessoOrigem(v, it.ref)) return minha ? "semacesso" : (AG.ocupa(it) ? "ocupado" : "oculto");
            if (minha) return "detalhe";
            if (it.tipo === "ausencia" && v.perfil === "adm") return "detalhe";
            const dono = AG.pessoa(it.dono);
            const inclui = it.vis === "equipe" || it.participantesTodos || (it.vis === "area" && dono.perfil === v.perfil) || (it.verPessoas || []).includes(v.id);
            if (inclui) return "detalhe";
            return AG.ocupa(it) ? "ocupado" : "oculto";
        }
        const o = AG.origem(it.ref) || {};
        if (AG.acessoOrigem(v, it.ref)) return "detalhe";
        if (v.perfil === "adm") return AG.ocupa(it) ? "contagem" : "oculto";
        if (v.perfil === "recepcao" && it.presencial && it.avisarRecepcao === true && AG.mesmoDia(it.ini, D.AGORA) && it.situacao !== "cancelado" && it.situacao !== "remarcado") return "recepcao";
        if (AG.ocupa(it)) return "ocupado";
        return "oculto";
    };

    // Grupo do filtro em que o item entra. "ocupado" nunca entra em filtro: disponibilidade só ao agendar.
    AG.grupo = function (it, v, nivel) {
        if (nivel === "oculto" || nivel === "ocupado") return null;
        if (it.fonte === "casa") return "casa";
        if (it.fonte === "curso") return it.dono === v.id ? "turmas" : "outrasTurmas";
        if (nivel === "recepcao") return "esperadas";
        if (nivel === "contagem") return "contagem";
        if (nivel === "semacesso") return "meus";
        if (it.dono === v.id || it.registradoPor === v.id || (it.participantes || []).includes(v.id) || it.participantesTodos) return "meus";
        if (it.fonte === "manual" && (it.vis === "equipe" || it.tipo === "ausencia")) return "equipe";
        if ((it.verPessoas || []).includes(v.id)) return "compartilhados";
        return "area";
    };

    AG.FILTROS = {
        meus: "Meus compromissos", area: "Minha área (casos da equipe)", esperadas: "Esperadas na unidade",
        equipe: "Avisos da equipe e reuniões gerais", compartilhados: "Compartilhados comigo (só ver)", turmas: "Minhas turmas", outrasTurmas: "Cursos: dia e horário das turmas",
        casa: "Feriados e unidade fechada", contagem: "Atendimentos técnicos (só números)"
    };
    AG.filtrosPadrao = function (v) {
        return ({
            recepcao: ["esperadas", "meus", "equipe", "compartilhados", "casa"],
            juridico: ["meus", "area", "equipe", "compartilhados", "casa"],
            psicologia: ["meus", "equipe", "compartilhados", "casa"],
            as_social: ["meus", "equipe", "compartilhados", "casa"],
            professora: ["turmas", "meus", "equipe", "compartilhados", "casa"],
            adm: ["meus", "equipe", "compartilhados", "outrasTurmas", "casa", "contagem"]
        })[v.perfil];
    };
    AG.filtrosDisponiveis = function (v) {
        const extra = { recepcao: ["outrasTurmas"], juridico: ["outrasTurmas"], psicologia: ["outrasTurmas"], as_social: ["outrasTurmas"], professora: ["outrasTurmas"], adm: [] }[v.perfil];
        return AG.filtrosPadrao(v).concat(extra);
    };

    /* Itens visíveis entre duas datas, conforme filtros (Set) e pessoas escolhidas (Set).
       Pessoas escolhidas mostram só o que a pessoa JÁ pode ver em detalhe da colega. */
    AG.visiveis = function (v, de, ate, filtros, pessoas) {
        const out = [];
        AG.todos().forEach(it => {
            const fimIt = it.fim || it.ini;
            if (!(it.ini < ate && fimIt >= de)) return;
            const nivel = AG.revelar(it, v);
            const g = AG.grupo(it, v, nivel);
            if (!g) return;
            let mostra = filtros.has(g);
            if (!mostra && pessoas && pessoas.size && nivel === "detalhe" && it.fonte !== "casa" && Array.from(pessoas).some(pid => AG.envolve(it, pid))) mostra = true;
            if (!mostra) return;
            if (it.tipo === "comunicacao" && nivel !== "detalhe") return;
            out.push({ it, nivel, g });
        });
        return out.sort((a, b) => a.it.ini - b.it.ini);
    };

    AG.contagens = function (v, dia) {
        const r = { psi: 0, jur: 0, soc: 0 };
        AG.todos().forEach(it => { if (AG.mesmoDia(it.ini, dia) && AG.revelar(it, v) === "contagem") r[it.fonte]++; });
        return r;
    };

    // ---------- pendências ----------
    AG.pendencias = function (v) {
        const P = [];
        const agora = D.AGORA;
        // Autorização ATUAL na origem antes de montar qualquer pendência ligada a um caso/prontuário
        const pode = it => !it.ref || AG.acessoOrigem(v, it.ref);
        AG.todos().forEach(it => {
            if (["psi", "jur", "soc"].includes(it.fonte) && it.dono === v.id && it.situacao === "agendado" && it.fim && it.fim < agora && AG.acessoOrigem(v, it.ref))
                P.push({ tipo: "resultado", it, txt: `Resultado pendente de registro: ${it.titulo} de ${AG.identAssistida(it.assistida)} (${AG.diaSemana(it.ini)} ${AG.dm(it.ini)} ${AG.hm(it.ini)})`, nota: "Horário passado sem registro não significa falta." });
            if (it.chegada && it.chegada.estado === "chegou" && it.dono === v.id && pode(it) && it.situacao !== "remarcado" && it.situacao !== "cancelado")
                P.unshift({ tipo: "chegada", it, txt: `${AG.identAssistida(it.assistida)} chegou às ${AG.hm(it.chegada.chegouEm)} para ${it.titulo.toLowerCase()} das ${AG.hm(it.ini)}` });
            if (it.tipo === "retornoRede" && it.pendente && it.dono === v.id && it.ini < agora && pode(it))
                P.push({ tipo: "rede", it, txt: `${it.titulo} venceu em ${AG.dm(it.ini)}: ${AG.identAssistida(it.assistida)}` });
            if (it.tipo === "ausencia" && it.ausencia === "informada" && ((it.dono === v.id && it.registradoPor !== v.id) || v.perfil === "adm"))
                P.push({ tipo: "ausencia", it, txt: `${AG.pessoa(it.registradoPor).curto} informou uma ausência ${it.dono === v.id ? "sua" : "de " + AG.pessoa(it.dono).curto}: ${AG.diaSemana(it.ini)} ${AG.dm(it.ini)}, ${it.diaInteiro ? "dia inteiro" : AG.hcurto(it.ini) + "–" + AG.hcurto(it.fim)}` });
            if (it.fonte === "curso" && it.dono === v.id && !it.cancelada) {
                if (it.fim < agora && !it.chamada) P.push({ tipo: "chamada", it, txt: `Chamada pendente: ${AG.curso(it.curso).nome}, ${AG.diaSemana(it.ini)} ${AG.dm(it.ini)}` });
                const casa = D.CASA.find(c => c.fechada && AG.mesmoDia(c.ini, it.ini) && !AG.estado.reaberta[c.id]);
                if (casa && it.ini > agora) P.push({ tipo: "fechada", it, txt: `Aula em dia de unidade fechada (${AG.dm(it.ini)}): cancelar ou remarcar ${AG.curso(it.curso).nome}` });
            }
        });
        AG.estado.revisar.filter(r => r.para === v.id).forEach(r => r.itens.forEach(id => {
            const it = AG.estado.itens.find(x => x.id === id);
            if (it && pode(it)) P.unshift({ tipo: "revisar", it, txt: `Compromisso recebido de ${AG.pessoa(r.de).curto} para revisar: ${it.titulo} de ${AG.identAssistida(it.assistida)}, ${AG.diaSemana(it.ini)} ${AG.dm(it.ini)} ${it.diaInteiro ? "(dia inteiro)" : AG.hm(it.ini)}`, nota: "Ainda não está na sua agenda. Assuma (o sistema confere sua disponibilidade) ou remarque." });
        }));
        Object.keys(AG.estado.reavaliacao).forEach(ref => {
            const r = AG.estado.reavaliacao[ref], o = AG.origem(ref);
            if (r.pendente && o.responsaveis.includes(v.id) && AG.acessoOrigem(v, ref)) P.unshift({ tipo: "reavaliacao", ref, txt: `Reavaliação de risco pendente: ${AG.identAssistida(o.assistida)} (risco ${r.riscoAtual} registrado em ${AG.dm(o.riscoEm)})`, nota: "Situações urgentes seguem o fluxo de atendimento da Casa (CAPS, SAMU 192, CVV 188)." });
        });
        if (v.perfil === "juridico") Object.keys(AG.estado.origens).forEach(ref => {
            const o = AG.estado.origens[ref];
            if (o.area === "jur" && o.aguardandoAgendamento && AG.acessoOrigem(v, ref)) P.push({ tipo: "encaminhamento", ref, txt: `Encaminhamento recebido sem agendamento: ${AG.identAssistida(o.assistida)} (desde ${AG.dm(o.recebidoEm)})` });
        });
        return P;
    };

    // ---------- conflitos (usa TODOS os itens, inclusive os que a pessoa não vê) ----------
    /* ctx: { viewer, dono, participantes[], assistida, ini, fim, diaInteiro, ignorar, excecao }
       excecao = exceção da ADM ligada a ESTE compromisso (não reabre a unidade para os outros) */
    AG.conflitos = function (ctx) {
        const v = ctx.viewer, out = [], vistos = new Set();
        const janela = ctx.diaInteiro ? { ini: AG.inicioDia(ctx.ini), fim: AG.somaDias(AG.inicioDia(ctx.ini), 1) } : { ini: ctx.ini, fim: ctx.fim };
        const add = (nivel, msg, k, extra) => { if (k && vistos.has(k)) return; if (k) vistos.add(k); if (!out.some(o => o.msg === msg)) out.push(Object.assign({ nivel, msg }, extra || {})); };
        const todos = AG.todos().filter(it => it.id !== ctx.ignorar);
        D.CASA.forEach(c => {
            if (!AG.mesmoDia(c.ini, ctx.ini)) return;
            if (c.fechada && !AG.estado.reaberta[c.id]) {
                if (ctx.excecao) add("aviso", `${c.titulo}. Exceção autorizada só para este compromisso (${ctx.excecao.motivo}).`);
                else add("bloqueio", `${c.titulo}. Só a ADM pode autorizar uma exceção, ligada a este compromisso.`, null, { casa: c.id });
            } else if (c.tipo === "feriado") add("aviso", `${c.titulo}. ${c.nota || ""}`.trim());
        });
        if (ctx.ini < D.AGORA) add("aviso", "Esse horário já passou.");
        const pessoas = [ctx.dono].concat(ctx.participantes || []).filter((x, i, a) => x && a.indexOf(x) === i);
        pessoas.forEach(pid => {
            const p = AG.pessoa(pid), eu = pid === v.id;
            const dela = todos.filter(it => AG.envolve(it, pid) && AG.ocupa(it));
            dela.forEach(it => {
                if (!sobrepoe(AG.janela(it), janela)) return;
                if (it.tipo === "ausencia") {
                    const quando = it.diaInteiro ? " (dia inteiro)" : "";
                    if (it.ausencia === "informada") add("aviso", `Há uma ausência informada para ${eu ? "você" : p.curto} nesse horário${quando}, ainda não confirmada. Nada foi cancelado por causa dela.`, it.id);
                    else add("confirmar", `${eu ? "Você está" : p.curto + " está"} ausente ${it.diaInteiro ? "o dia inteiro" : "nesse horário"} (ausência confirmada).`, it.id);
                    return;
                }
                const n = AG.revelar(it, v);
                if (n === "detalhe") add("confirmar", `${eu ? "Você já tem" : p.curto + " já tem"} ${it.titulo.toLowerCase()} ${it.diaInteiro ? "(dia inteiro)" : "das " + AG.hm(it.ini) + " às " + AG.hm(it.fim)}${it.deslocamento ? " (com deslocamento)" : ""}.`, it.id);
                else add("confirmar", `Há uma indisponibilidade ${eu ? "na sua agenda" : "na agenda de " + p.curto} nesse horário.`, it.id);
            });
            if (!ctx.diaInteiro) {
                const doDia = dela.filter(it => AG.mesmoDia(it.ini, ctx.ini) && !it.diaInteiro);
                const horas = doDia.reduce((s, it) => s + (AG.janela(it).fim - AG.janela(it).ini) / 3600000, 0) + (ctx.fim - ctx.ini) / 3600000;
                const lim = p.limiteDia || D.CONFIG.limiteCompromissos;
                if (doDia.length + 1 > lim || horas > D.CONFIG.limiteHoras)
                    add("aviso", `${eu ? "Seu dia" : "O dia de " + p.curto} ficaria com ${doDia.length + 1} compromissos e ${horas.toFixed(1).replace(".", ",")} h ocupadas (aviso a partir de ${lim} compromissos ou ${D.CONFIG.limiteHoras} h${p.limiteDia ? ", limite configurado para " + p.curto : ""}).`);
                if (pid === ctx.dono) {
                    const colado = dela.find(it => { if (it.diaInteiro) return false; const j = AG.janela(it); return !sobrepoe(j, janela) && (Math.abs(j.fim - janela.ini) < 10 * MIN || Math.abs(janela.fim - j.ini) < 10 * MIN); });
                    if (colado) add("aviso", `Fica sem intervalo ${colado.fim <= ctx.ini ? "depois" : "antes"} de outro compromisso${AG.revelar(colado, v) === "detalhe" ? " (" + colado.titulo.toLowerCase() + " das " + AG.hm(colado.ini) + ")" : ""}.`);
                    const [ei, ef] = D.CONFIG.expediente;
                    if (AG.hm(ctx.ini) < ei || AG.hm(ctx.fim) > ef || [0, 6].includes(ctx.ini.getDay())) add("aviso", `Fora do expediente${eu ? " (" + ei.replace(":00", "h") + "–" + ef.replace(":00", "h") + ")" : " de " + p.curto}.`);
                }
            }
        });
        if (ctx.assistida) {
            todos.forEach(it => {
                if (vistos.has(it.id) || !AG.ocupa(it) || it.tipo === "comunicacao" || it.tipo === "ausencia") return;
                const daAssistida = it.assistida === ctx.assistida || (it.fonte === "curso" && AG.curso(it.curso).alunas.includes(ctx.assistida));
                if (!daAssistida || !sobrepoe(AG.janela(it), janela)) return;
                if (it.fonte === "curso") {
                    if (AG.veCursoDaAssistida(v, ctx.assistida)) add("confirmar", `A assistida tem aula de ${AG.curso(it.curso).nome} das ${AG.hm(it.ini)} às ${AG.hm(it.fim)}.`, it.id);
                    else add("confirmar", "Há uma indisponibilidade da assistida nesse horário.", it.id);
                } else if (AG.revelar(it, v) === "detalhe") add("confirmar", `A assistida já tem ${it.titulo.toLowerCase()} das ${AG.hm(it.ini)} às ${AG.hm(it.fim)}.`, it.id);
                else add("confirmar", "Há uma indisponibilidade da assistida nesse horário.", it.id);
            });
        }
        const ordem = { bloqueio: 0, confirmar: 1, aviso: 2 };
        return out.sort((a, b) => ordem[a.nivel] - ordem[b.nivel]);
    };

    /* Faixas para o modo de escolha. aviso = ausência só informada: aparece, mas NÃO impede escolher o horário. */
    AG.faixas = function (v, pessoas, assistida, dia) {
        const out = [];
        AG.todos().forEach(it => {
            if (!AG.ocupa(it) || it.tipo === "comunicacao") return;
            const j = AG.janela(it);
            if (!(j.ini < AG.somaDias(AG.inicioDia(dia), 1) && AG.inicioDia(dia) < j.fim)) return;
            const daPessoa = pessoas.some(pid => AG.envolve(it, pid));
            const daAssistida = assistida && it.tipo !== "ausencia" && (it.assistida === assistida || (it.fonte === "curso" && AG.curso(it.curso).alunas.includes(assistida)));
            if (!daPessoa && !daAssistida) return;
            const n = AG.revelar(it, v);
            const aviso = it.tipo === "ausencia" && it.ausencia === "informada";
            let rot = "Indisponível";
            if (aviso) rot = "Ausência informada (aviso)";
            else if (n === "detalhe" && daPessoa) rot = it.titulo;
            else if (it.fonte === "curso" && daAssistida && AG.veCursoDaAssistida(v, assistida)) rot = "Aula da assistida";
            const ini = j.ini < AG.inicioDia(dia) ? AG.inicioDia(dia) : j.ini, fim = j.fim > AG.somaDias(AG.inicioDia(dia), 1) ? AG.somaDias(AG.inicioDia(dia), 1) : j.fim;
            out.push({ ini, fim, rot, revelado: rot !== "Indisponível" && !aviso, aviso, it, n });
        });
        return out;
    };

    // ---------- Passar responsabilidades ----------
    /* A sucessora ganha acesso ao caso. Os compromissos FUTUROS não mudam de agenda sozinhos:
       entram numa lista para ela revisar (assumir conferindo a disponibilidade, ou remarcar).
       Registros passados mantêm a autoria original. */
    AG.passarResponsabilidade = function (ref, de, para, porQuem) {
        const o = AG.origem(ref);
        o.responsaveis = o.responsaveis.filter(x => x !== de).concat([para]);
        const futuros = AG.estado.itens.filter(it => it.ref === ref && it.fonte !== "manual" && it.dono === de && it.ini > D.AGORA && (it.situacao === "agendado" || it.ocupa === false)).map(it => it.id);
        AG.estado.revisar.push({ ref, de, para, itens: futuros });
        AG.auditar(`${porQuem.curto} passou ${ref} de ${AG.pessoa(de).curto} para ${AG.pessoa(para).curto} (${futuros.length} compromisso(s) futuro(s) para revisar)`);
        return futuros;
    };
    /* Mesma regra das pendências para EXECUTAR a ação: sem permissão atual na origem, nada é feito. */
    AG.podeAgirNoItem = function (v, it) {
        if (!it) return false;
        if (it.ref && !AG.acessoOrigem(v, it.ref)) return false;
        return true;
    };
    AG.tirarDaRevisao = function (id) { AG.estado.revisar.forEach(r => { r.itens = r.itens.filter(x => x !== id); }); };

    AG.novoId = () => "n" + (AG.estado.seq++);
})();
