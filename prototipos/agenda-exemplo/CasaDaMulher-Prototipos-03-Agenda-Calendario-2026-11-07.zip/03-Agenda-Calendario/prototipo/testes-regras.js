/* Teste automático das regras do protótipo (sem navegador).
   Como rodar:  node testes-regras.js   (precisa do Node.js instalado) */
"use strict";
global.window = {};
require("./dados-ficticios.js");
require("./regras.js");
const AG = window.AG, D = window.AG_DADOS || window.DADOS || window.D;
let ok = 0, falhas = 0;
function t(nome, cond) { if (cond) { ok++; console.log("  ok    " + nome); } else { falhas++; console.log("  FALHA " + nome); } }
const P = id => AG.pessoa(id);
const d = (dia, hm, mes) => { const [h, m] = (hm || "00:00").split(":").map(Number); return new Date(2026, (mes || 11) - 1, dia, h, m); };
const niveis = cf => cf.map(c => c.nivel);
const tem = (cf, txt) => cf.some(c => c.msg.includes(txt));

console.log("Regras da Agenda e Calendário (protótipo)\n");

// 1. Ausência confirmada de dia inteiro ocupa a agenda
AG.reiniciar();
let cf = AG.conflitos({ viewer: P("jur1"), dono: "jur1", participantes: ["jur2"], ini: d(19, "10:00"), fim: d(19, "11:00") });
t("Ausência confirmada de dia inteiro gera conflito (confirmar)", cf.some(c => c.nivel === "confirmar" && c.msg.includes("Paula está ausente") && c.msg.includes("dia inteiro")));
t("Feriado não ocupa horário (só aviso)", (() => { const c2 = AG.conflitos({ viewer: P("psi1"), dono: "psi1", ini: d(20, "10:00"), fim: d(20, "10:50") }); return !c2.some(c => c.nivel !== "aviso"); })());
t("Prazo é marco: não ocupa", AG.ocupa(AG.todos().find(i => i.id === "j4")) === false);

// 2. Semanal: cada ocorrência conferida, conflito só na 2ª semana
const ocs = [0, 1, 2, 3].map(i => ({ ini: AG.somaDias(d(17, "16:00"), 7 * i), fim: AG.somaDias(d(17, "17:00"), 7 * i) }));
const porData = ocs.map(o => AG.conflitos({ viewer: P("psi1"), dono: "psi1", ini: o.ini, fim: o.fim }).filter(c => c.nivel !== "aviso"));
t("Série semanal: só 24/11 tem conflito", porData[0].length === 0 && porData[1].length > 0 && porData[2].length === 0 && porData[3].length === 0);

// 3. Exceção da ADM vale só para o compromisso autorizado
cf = AG.conflitos({ viewer: P("adm"), dono: "adm", participantes: ["soc"], ini: d(27, "10:00"), fim: d(27, "11:00") });
t("Unidade fechada bloqueia sem exceção", niveis(cf).includes("bloqueio"));
cf = AG.conflitos({ viewer: P("adm"), dono: "adm", participantes: ["soc"], ini: d(27, "10:00"), fim: d(27, "11:00"), excecao: { motivo: "vistoria", por: "adm" } });
t("Com exceção ligada ao compromisso: vira aviso", !niveis(cf).includes("bloqueio"));
AG.estado.itens.push({ id: "tx1", fonte: "manual", tipo: "reuniao", titulo: "Vistoria", dono: "adm", registradoPor: "adm", participantes: ["soc"], vis: "equipe", ini: d(27, "10:00"), fim: d(27, "11:00"), excecao: { motivo: "vistoria", por: "adm" } });
cf = AG.conflitos({ viewer: P("psi1"), dono: "psi1", ini: d(27, "14:00"), fim: d(27, "14:50") });
t("Outra pessoa no mesmo dia continua bloqueada", niveis(cf).includes("bloqueio"));
t("A exceção não reabriu a unidade", !AG.estado.reaberta.c3);

// 4. Professora não vê agenda técnica fora do agendamento
AG.reiniciar();
const semana = AG.visiveis(P("prof1"), d(9), d(16), new Set(AG.filtrosDisponiveis(P("prof1"))), new Set(["psi1"]));
t("Professora com filtro Pessoas=Ana não vê sessões da Psicologia", !semana.some(x => x.it.fonte === "psi"));
t("Nada aparece como 'Ocupado' nos filtros", !semana.some(x => x.nivel === "ocupado" || x.nivel === "oculto"));

// 5. Autora perde o detalhe ao perder a autorização do caso
t("Antes: Fernanda vê o lembrete do caso", AG.revelar(AG.todos().find(i => i.id === "m4"), P("jur1")) === "detalhe");
AG.passarResponsabilidade("CJ-2026-000041", "jur1", "jur2", P("adm"));
t("Depois: o lembrete que ela criou fica 'sem acesso'", AG.revelar(AG.todos().find(i => i.id === "m4"), P("jur1")) === "semacesso");
const rev = AG.pendencias(P("jur2")).filter(p => p.tipo === "revisar");
t("Sucessora recebe compromissos futuros para revisar", rev.length >= 2 && rev.some(p => p.it.id === "j3"));
t("Nada foi para a agenda da sucessora sem revisão", AG.todos().find(i => i.id === "j3").dono === "jur1");
cf = AG.conflitos({ viewer: P("jur2"), dono: "jur2", assistida: "a2", ignorar: "j3", ini: d(12, "13:00"), fim: d(12, "15:00") });
t("Assumir a audiência de 12/11 mostra conflito com o atendimento das 13:30", cf.some(c => c.nivel === "confirmar" && c.msg.includes("13:30")));
t("Registro passado continua com a autora original", AG.todos().filter(i => i.ref === "CJ-2026-000041" && i.ini < D_AGORA()).every(i => i.dono === "jur1"));

// 6. Ausência informada: aviso, não tira horário livre
AG.reiniciar();
cf = AG.conflitos({ viewer: P("adm"), dono: "adm", participantes: ["psi1"], ini: d(11, "11:00"), fim: d(11, "11:30") });
t("Ausência informada só avisa", tem(cf, "ausência informada") && !cf.some(c => c.nivel === "confirmar" && c.msg.includes("ausência")));
const fx = AG.faixas(P("psi1"), ["psi1"], null, d(11));
t("No modo de escolha a faixa da ausência informada é aviso (não bloqueia)", fx.some(f => f.aviso && f.it.id === "m1"));

// 7. Compartilhar não ocupa
AG.estado.itens.push({ id: "tx2", fonte: "manual", tipo: "reuniao", titulo: "Reunião de alinhamento", dono: "jur1", registradoPor: "jur1", vis: "pessoas", verPessoas: ["jur2"], ini: d(12, "10:00"), fim: d(12, "11:00") });
cf = AG.conflitos({ viewer: P("jur2"), dono: "jur2", ini: d(12, "10:00"), fim: d(12, "11:00") }).filter(c => c.nivel !== "aviso");
t("Quem só vê não fica ocupada", cf.length === 0);
t("Ela vê como 'compartilhado'", AG.revelar(AG.todos().find(i => i.id === "tx2"), P("jur2")) === "detalhe" && AG.grupo(AG.todos().find(i => i.id === "tx2"), P("jur2"), "detalhe") === "compartilhados");
AG.estado.itens.push({ id: "tx3", fonte: "manual", tipo: "reuniao", titulo: "Reunião com participante", dono: "jur1", registradoPor: "jur1", vis: "eu", participantes: ["jur2"], ini: d(12, "10:00"), fim: d(12, "11:00") });
cf = AG.conflitos({ viewer: P("jur2"), dono: "jur2", ini: d(12, "10:00"), fim: d(12, "11:00") }).filter(c => c.nivel !== "aviso");
t("Participante fica ocupada", cf.length > 0);

// 8. Recepção
AG.reiniciar();
const rec = P("rec");
t("Recepção não vê caso restrito (Maria Souza 15h)", AG.revelar(AG.todos().find(i => i.id === "j1"), rec) !== "recepcao");
const itp = AG.todos().find(i => i.id === "j5");
t("Recepção vê caso comum com 'Avisar' ligado", AG.revelar(itp, rec) === "recepcao");
itp.avisarRecepcao = false;
t("Recepção NÃO vê caso comum com 'Avisar' desligado", AG.revelar(itp, rec) !== "recepcao");
t("Item oculto continua contando no conflito", AG.conflitos({ viewer: rec, dono: "jur1", ini: d(10, "15:00"), fim: d(10, "15:30") }).some(c => c.msg.includes("indisponibilidade")));

// 9. Cancelar "esta e as próximas" não mexe no passado
AG.reiniciar();
const curso = AG.todos().find(i => i.fonte === "curso" && i.dono === "prof1" && i.ini < d(10)).curso;
const antes = AG.todos().filter(i => i.fonte === "curso" && i.curso === curso && i.ini < d(10, "13:40"));
AG.estado.chamadas.add(curso + "|" + antes[antes.length - 1].dia);
AG.estado.serieAte[curso] = { dia: antes[0].dia, motivo: "teste (desta em diante)" };
const depois = AG.todos().filter(i => i.fonte === "curso" && i.curso === curso);
t("Aulas passadas não são canceladas", depois.filter(i => i.ini < d(10, "13:40")).every(i => !i.cancelada));
t("Aulas futuras são canceladas", depois.filter(i => i.ini > d(10, "13:40")).every(i => i.cancelada));
t("Aula com chamada continua com chamada", depois.some(i => i.chamada));

// 10. Rodada 4: pendências respeitam a permissão atual; remarcado sai das esperadas
AG.reiniciar();
const j1 = AG.todos().find(i => i.id === "j1");
j1.chegada = { estado: "chegou", chegouEm: d(10, "14:52") };
t("Antes da transferência: Fernanda recebe a pendência de chegada", AG.pendencias(P("jur1")).some(p => p.tipo === "chegada" && p.it.id === "j1"));
AG.passarResponsabilidade("CJ-2026-000041", "jur1", "jur2", P("adm"));
const pendF = AG.pendencias(P("jur1"));
t("Depois: a antiga responsável não recebe pendência de chegada do caso", !pendF.some(p => p.it && p.it.ref === "CJ-2026-000041"));
t("Nenhuma pendência dela mostra a assistida do caso", !pendF.some(p => p.txt.includes("AS-0057") && p.it && p.it.ref === "CJ-2026-000041"));
t("Ela também não pode executar a ação (recebida/assumir)", AG.podeAgirNoItem(P("jur1"), j1) === false);
t("A sucessora pode agir", AG.podeAgirNoItem(P("jur2"), j1) === true);
AG.reiniciar();
const j5 = AG.todos().find(i => i.id === "j5");
t("Atendimento comum aparece nas esperadas da Recepção", AG.revelar(j5, P("rec")) === "recepcao");
j5.situacao = "remarcado";
t("Depois de remarcado, o horário antigo sai das esperadas", AG.revelar(j5, P("rec")) !== "recepcao");
t("E não ocupa mais a agenda", AG.ocupa(j5) === false);

// 11. Registro de reavaliação: só com acesso atual ao prontuário
AG.reiniciar();
AG.estado.reavaliacao["PSI-2026-000009"].registros.push({ em: d(10, "13:40"), por: "psi1", classificacao: "alto", proximaAcao: "teste" });
t("Com acesso: Ana pode abrir o prontuário do registro", AG.acessoOrigem(P("psi1"), "PSI-2026-000009") === true);
AG.origem("PSI-2026-000009").responsaveis = ["psi2"]; AG.origem("PSI-2026-000009").autorizados = [];
t("Sem acesso: Ana não acessa mais o prontuário (o registro não abre)", AG.acessoOrigem(P("psi1"), "PSI-2026-000009") === false);

function D_AGORA() { return d(10, "13:40"); }
console.log(`\n${ok} de ${ok + falhas} verificações passaram.`);
process.exitCode = falhas ? 1 : 0;
